from variation.matrixwithmeta import INDIVIDUALS_IN_ROWS, PLOIDY
from variation.inout.genetic import get_codec_from_genotypes

def create_infile(genotypes, classification, out_fhand):
    pops = classification.groupby(classification).groups
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        geno_indis = genotypes.data.index
        markers = genotypes.data.columns
    else:
        geno_indis = genotypes.data.columns
        markers = genotypes.data.index

    pops_filtered = {}
    for pop, indis in pops.items():
        indis = set(indis).intersection(geno_indis)
        if indis:
            pops_filtered[pop] = indis
    pops = pops_filtered

    fhand = out_fhand
    fhand.write('Genepop file\n')
    fhand.write(' '.join(markers))
    fhand.write('\n')

    codec = get_codec_from_genotypes(genotypes)
    ploidy = genotypes.meta[PLOIDY]
    null_geno = [0] * ploidy
    for pop, indis in pops.items():
        fhand.write('POP')
        #fhand.write(' ' + pop)
        fhand.write('\n')
        for indi in indis:
            fhand.write(indi + ', ')
            if genotypes.meta[INDIVIDUALS_IN_ROWS]:
                geno_indi = genotypes.data.xs(indi)
            else:
                geno_indi = genotypes.data[indi]
            indi_geno = []
            for geno in geno_indi:
                geno = codec.decode_to_ints(geno)
                if geno is None:
                    geno = null_geno
                geno_str = []
                for allele in geno:
                    if allele > 9:
                        msg = 'The allele is larger than 9, fixme'
                        raise RuntimeError(msg)
                    allele = '%02i' % allele
                    geno_str.append(allele)
                geno_str = ''.join(geno_str)
                indi_geno.append(geno_str)
            fhand.write(' '.join(indi_geno))
            fhand.write('\n')
