'''
Created on 08/03/2012

@author: jose
'''
from __future__ import division
from tempfile import NamedTemporaryFile
from subprocess import Popen, PIPE
import os

import numpy
from pandas import Series, DataFrame

from variation.matrixwithmeta import (CODOMINANT, INDIVIDUALS_IN_ROWS,
                                      PLOIDY, ALLELE_CODING, BITS_PER_ALLELE,
                                      MOLECULE_COL, LOCATION_COL,
                                      LINKAGE_GROUP_COL, GENETIC_LOCATION_COL,
                                      CLASSIFICATION_COL, GENDER_COL, FLOAT,
                                      MatrixWithMeta, DEF_SEX_CHROMOSOMES,
                                      SEX_CHROMOSOMES)
from variation.inout.genetic import GenotypeCodec
from variation.utils import get_binary_path

DEFAULT_NUM_PRINCOMPS = 10
UNKNOWN_POP = 'pop_unk'
DEF_OUTLIERS_ITERATIONS = 5
DEF_OUTLIERS_SIGMA = 6.0
X_CHROMOSOME_IN_SMARTPCA = 23
Y_CHROMOSOME_IN_SMARTPCA = 24
XY_CHROMOSOME_IN_SMARTPCA = 91
MT_DNA_IN_SMARTPCA = 90
NOT_VALID_CHROMOSOME_IN_SMARTPCA = 0


def _create_smart_params(geno_fhand, snps_fhand, indi_fhand,
                        num_princomps, outliers_fhand, deleted_snps_fhand,
                        params):
    ' It create the parameters file required to run smartpcas'

    param_fhand = NamedTemporaryFile(suffix='.par')
    # genotype file
    param_fhand.write('genotypename: %s\n' % geno_fhand.name)
    # snp file in any format
    param_fhand.write('snpname: %s\n' % snps_fhand.name)
    # indiv file in any format
    param_fhand.write('indivname: %s\n' % indi_fhand.name)
    param_fhand.write('deletesnpoutname: %s\n' % deleted_snps_fhand.name)
    # number of principal components
    param_fhand.write('numoutevec: %i\n' % num_princomps)
    #output file of principal component
    princomps_fhand = NamedTemporaryFile(suffix='.princomps')
    param_fhand.write('evecoutname: %s\n' % princomps_fhand.name)
    #output file of all eigenvalues
    eigenvals_fhand = NamedTemporaryFile(suffix='.eigvals')
    param_fhand.write('evaloutname: %s\n' % eigenvals_fhand.name)

    #remove outliers
    #(Default is 5) maximum number of outlier removal
    #iterations. To turn off outlier removal, set -m 0.
    param_fhand.write('numoutlieriter: %i\n' % params['outliers_iterations'])
    param_fhand.write('outlieroutname: {:s}\n'.format(outliers_fhand.name))
    # number of standard deviations which an individual must exceed, along one
    # of the top (numoutlierevec) principal components, in order for that
    # individual to be removed as an outlier.
    if 'outliers_sigma' in params:
        string = 'outliersigmathresh: {:f}\n'.format(params['outliers_sigma'])
        param_fhand.write(string)
    # numoutlierevec: number of principal components along which to remove
    # outliers during each outlier removal iteration.  Default is 10.
    string = 'numoutlierevec: %i\n' % params['num_princomps_outlier']
    param_fhand.write(string)

    to_yes_no = lambda x: 'YES' if x else 'NO'
    # human specific
    # noxdata: if set to YES, all SNPs on X chr are excluded from the data set.
    # The smartpca default for this parameter is YES, since different variances
    # for males vs. females on X chr may confound PCA analysis.
    remove_x_markers = to_yes_no(params['remove_x_markers'])
    param_fhand.write('noxdata: {:s}\n'.format(remove_x_markers))

    # nomalexhet: if set to YES, any het genotypes on X chr for males are
    # changed to missing data.  The smartpca default for this parameter is YES.
    no_male_x_het = to_yes_no(params['no_male_x_het'])
    param_fhand.write('nomalexhet: {:s}\n'.format(no_male_x_het))

    # usenorm: Whether to normalize each SNP by a quantity related to allele
    # freq. Default is YES.  (When analyzing microsatellite data, should be
    # set to NO. See Patterson et al. 2006.)
    use_norm = to_yes_no(params['use_norm'])
    param_fhand.write('usenorm: {:s}\n'.format(use_norm))

    param_fhand.write('qtmode: NO\n')
    param_fhand.flush()
    return param_fhand, princomps_fhand, eigenvals_fhand


def _run_smartpca(param_fpath):
    'It runs the smartpca analysis'
    bin_ = get_binary_path('smartpca')
    cmd = [bin_, ' -p', param_fpath]

    # In some cases the shell=Fase version has failed with a "no parameters"
    # error
    # process = Popen(cmd, stdout=PIPE, stderr=PIPE)
    shell_cmd = ' '.join(cmd)
    process = Popen(shell_cmd, stdout=PIPE, stderr=PIPE, shell=True)

    stdout, stderr = process.communicate()
    if process.returncode != 0 or stderr.strip():
        if 'number of samples after outlier removal: 0' in stdout:
            pass
        else:
            msg = 'Problem running smartpca:\n' + stdout
            msg += '\n' + stderr
            raise RuntimeError(msg)


def _read_outliers_file(fhand):
    'It reads the outliers file'
    individuals = []
    sigmas = []
    for line in fhand:
        items = line.split()
        individuals.append(items[2])
        sigmas.append(float(items[-1]))
    return Series(sigmas, index=individuals, name='outlier_sigmas')


def _read_deleted_markers_file(fhand):
    'It reads the deleted file'
    markers = []
    reasons = []
    for line in fhand:
        items = line.split()
        markers.append(items[0])
        reasons.append(items[-1])
    return Series(reasons, index=markers, name='deleted_markers_reasons')


def _prepare_output(princomps_fpath, eigenvals_fpath, outliers_fpath,
                    deleted_markers_fpath):
    'It prepares the output'
    projections = _read_projections_file(open(princomps_fpath))
    n_princomps = projections.shape[1]
    eigenvals = _read_eigenvalues_file(open(eigenvals_fpath))
    tot_eig = float(sum(eigenvals))
    # it might be a different number of principal component than of
    # eigenvals, because if some of the less important components explain
    # zero variance they are discarded.
    # pylint: disable=C0301
    pcnts = Series([eig / tot_eig * 100.0  for i, eig in enumerate(eigenvals) if i < n_princomps])

    fmt = 'pca-{:0' + str(len(str(n_princomps))) + 'd}'
    dim_names = [fmt.format(i) for i in range(1, n_princomps + 1)]
    projections.columns = dim_names
    pcnts.index = dim_names[:]

    projections = MatrixWithMeta(projections)
    projections.kind = FLOAT
    pcnts = MatrixWithMeta(pcnts)
    pcnts.kind = FLOAT

    output = {'projections': projections,
              'var_percentages': pcnts}

    outliers = _read_outliers_file(open(outliers_fpath))
    if len(outliers):
        output['outlier_sigmas'] = outliers

    # smartpca removes the file if there is no deleted markers
    if os.path.exists(deleted_markers_fpath):
        fhand = open(deleted_markers_fpath)
        deleted_markers = _read_deleted_markers_file(fhand)
        if len(deleted_markers):
            output['deleted_markers_reasons'] = deleted_markers

    return output


def prepare_smartpca_outliers(params=None,
                              outliers_iterations=DEF_OUTLIERS_ITERATIONS,
                              outliers_sigma=DEF_OUTLIERS_SIGMA):
    'It prepares the parameters to run smartpca detecting outliers'
    if params is None:
        params = {}
    params['outliers_iterations'] = outliers_iterations
    params['outliers_sigma'] = outliers_sigma
    return params


def prepare_smartpca_sex_chrom(params=None, remove_x_markers=True,
                               no_male_x_het=True,
                               sex_chromosomes=DEF_SEX_CHROMOSOMES):
    'It prepares the parameters to run smartpca with human data'
    if params is None:
        params = {}
    params['remove_x_markers'] = remove_x_markers
    params['no_male_x_het'] = no_male_x_het
    params['sex_chromosomes'] = sex_chromosomes
    return params


def _set_default_params(params):
    'It sets the default parameters for smartpca'
    defaults = {'use_norm': True,
                'outliers_iterations': 0,
                'num_chromosomes': None,
                'num_princomps_outlier': DEFAULT_NUM_PRINCOMPS,
                'remove_x_markers': True,
                'no_male_x_het': True}

    for param, def_val in defaults.viewitems():
        if param not in params:
            params[param] = def_val


def do_smartpca(genotypes, markers_map=None, individuals=None,
                max_princomps=DEFAULT_NUM_PRINCOMPS, params=None):
    'It does an smartpca from the eigenstrat package'
    if params is None:
        params = {}
    _set_default_params(params)
    if genotypes.kind != CODOMINANT:
        msg = 'smartpca is only available for codominant data'
        raise ValueError(msg)

    if individuals is not None:
        if genotypes.meta[INDIVIDUALS_IN_ROWS]:
            indis_genotypes = genotypes.data.index
        else:
            indis_genotypes = genotypes.data.columns
        indis_genotypes = set(indis_genotypes)
        indis_individuals = set(individuals.data.index)
        if not indis_genotypes.issubset(indis_individuals):
            msg = 'Some individuals included in the genotypes are not '
            msg += 'found in the individuals classification, e. g.: '
            missing = indis_genotypes.difference(indis_individuals)
            missing = ', '.join(missing[:3])
            msg += missing
            raise ValueError(msg)
    if markers_map is not None:
        if genotypes.meta[INDIVIDUALS_IN_ROWS]:
            markers_genotypes = genotypes.data.columns
        else:
            markers_genotypes = genotypes.data.index
        markers_genotypes = set(markers_genotypes)
        markers_markers = set(markers_map.data.index)
        if not markers_genotypes.issubset(markers_markers):
            msg = 'Some markers in the genotypes are not found in the markers '
            msg += 'map, e.g.: '
            missing = markers_genotypes.difference(markers_markers)
            missing = ', '.join(missing[:3])
            msg += missing
            raise ValueError(msg)

    if params['num_chromosomes'] is None:
        if markers_map is None:
            msg = 'Please, provide the number of chromosomes or a map to count'
            msg += ' them.'
            raise ValueError(msg)
        else:
            # The number of different molecules found in the map
            map_meta = markers_map.meta
            if LINKAGE_GROUP_COL in map_meta:
                col = map_meta[LINKAGE_GROUP_COL]
            elif MOLECULE_COL in map_meta:
                col = map_meta[MOLECULE_COL]
            else:
                msg = 'Either the linkage_group_col or the molecule_col '
                msg += 'should be defined in the marker map'
                raise ValueError(msg)
            params['num_chromosomes'] = markers_map.data[col].nunique

    geno_fhand = _create_genotype_file(genotypes)
    snps_fhand = _create_marker_file(markers_map, genotypes)
    indi_fhand = _create_indi_file(individuals, genotypes)
    outliers_fhand = NamedTemporaryFile(prefix='smartpca', suffix='.outliers')
    deleted_snps_fhand = NamedTemporaryFile(prefix='smartpca',
                                            suffix='.deleted_markers',
                                            delete=False)
    fhands = _create_smart_params(geno_fhand, snps_fhand, indi_fhand,
                                  max_princomps, outliers_fhand,
                                  deleted_snps_fhand, params)
    param_fhand, princomps_fhand, eigenvals_fhand = fhands

    _run_smartpca(param_fhand.name)
    output = _prepare_output(princomps_fhand.name, eigenvals_fhand.name,
                             outliers_fhand.name, deleted_snps_fhand.name)

    geno_fhand.close()
    snps_fhand.close()
    indi_fhand.close()
    if os.path.exists(deleted_snps_fhand.name):
        os.remove(deleted_snps_fhand.name)
    outliers_fhand.close()
    param_fhand.close()
    princomps_fhand.close()
    param_fhand.close()
    return output


class SmartPCAGenotypeCoder(GenotypeCodec):
    'It codes genotypes as smartpca genotype file codes'
    #to few public methods
    # pylint: disable=R0903
    def __init__(self, *args, **kwargs):
        'It inits the class'
        super(SmartPCAGenotypeCoder, self).__init__(*args, **kwargs)
        if self.ploidy != 2:
            raise RuntimeError('smartpca only works for diploids')
        self._smart_allele_codes = {}  # given_allele:coded_allele

    def code_to_smartpca(self, genotype):
        'It returns the smartpca coded genotype'
        genotype = self.decode_to_ints(genotype)
        if genotype is not None and len(genotype) != 2:
            raise RuntimeError('smartpca only works for diploids')

        if genotype is None:
            return '9'
        codes = self._smart_allele_codes

        if not codes:   # the first allele found will be the reference
            codes['reference'] = genotype[0]
            codes['other_alleles'] = set()
        # how many reference alleles do we have?
        ref_allele = codes['reference']
        other_alleles = codes['other_alleles']
        count = 0
        if genotype[0] == ref_allele:
            count += 1
            other_alleles.add(genotype[0])
        if genotype[1] == ref_allele:
            count += 1
            other_alleles.add(genotype[1])
        if len(other_alleles) > 2:
            msg = 'More than two alleles found in a marker we would lose'
            msg += ' information'
            raise RuntimeError(msg)
        return str(count)

    def initilize_smart_codes(self):
        'It clears the smartcodes from marker to marker'
        self._smart_allele_codes = {}


def _create_genotype_file(genotypes):
    'It writes an eigenstrat genotype file with the given individuals'

    geno_fhand = NamedTemporaryFile(prefix='smartpca', suffix='.genotypes')
    meta = genotypes.meta
    codec = SmartPCAGenotypeCoder(ploidy=meta[PLOIDY],
                                  bits_per_allele=meta[BITS_PER_ALLELE],
                                  alleles_coding=meta[ALLELE_CODING])

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        genotypes_for_marker = genotypes.data.iteritems()
    else:
        genotypes_for_marker = genotypes.data.iterrows()
    smartpca_coder = numpy.vectorize(codec.code_to_smartpca)
    for index, snp_genotype in genotypes_for_marker:
        # pylint: disable=W0612
        codec.initilize_smart_codes()
        str_genotype = ''.join(smartpca_coder(snp_genotype.values))
        geno_fhand.write(str_genotype + '\n')
    geno_fhand.flush()
    return geno_fhand


def _create_marker_file(markers_map, genotypes):
    'It returns an eigenstrat snp file'
    fhand = NamedTemporaryFile(prefix='smartpca', suffix='.markers')

    if markers_map is None and genotypes is None:
        msg = 'Either the markers_map or the genotypes should be given'
        raise ValueError(msg)

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        markers = genotypes.data.columns
    else:
        markers = genotypes.data.index

    if markers_map is None:
        no_markers = True
    else:
        dataf = markers_map.data
        meta = markers_map.meta
        no_markers = False
        mol_col = meta.get(MOLECULE_COL, None)
        loc_col = meta[LOCATION_COL] if mol_col is not None else None
        lg_col = meta.get(LINKAGE_GROUP_COL, None)
        if lg_col is None:
            gen_loc_col = None
        else:
            gen_loc_col = meta[GENETIC_LOCATION_COL]
        sex_chromosomes = meta[SEX_CHROMOSOMES]

    chromosome_numbers = {}
    short_names = set()
    next_molecule_num = 1
    next_phys_loc = 1
    for marker in markers:
        if no_markers:
            phys_mol, phys_loc = None, next_phys_loc
            next_phys_loc += 1
            gen_lg, gen_loc = None, 0.0
        else:
            phys_mol = dataf.get_value(marker, mol_col) if mol_col else None
            phys_loc = dataf.get_value(marker, loc_col) if mol_col else 0
            gen_lg = dataf.get_value(marker, lg_col) if lg_col else None
            gen_loc = dataf.get_value(marker, gen_loc_col) if lg_col else 0.0
        if gen_lg is not None:
            molecule = gen_lg
        elif phys_mol is not None:
            molecule = phys_mol
        else:
            molecule = None
        if molecule in chromosome_numbers:
            molecule_num = chromosome_numbers[molecule]
        else:
            if molecule != 0:
                molecule_num = next_molecule_num
                next_molecule_num += 1
                if next_molecule_num == X_CHROMOSOME_IN_SMARTPCA:
                    next_molecule_num += 1
                if next_molecule_num == Y_CHROMOSOME_IN_SMARTPCA:
                    next_molecule_num += 1
                if next_molecule_num == XY_CHROMOSOME_IN_SMARTPCA:
                    next_molecule_num += 1
                if next_molecule_num == MT_DNA_IN_SMARTPCA:
                    next_molecule_num += 1
            else:
                molecule_num = NOT_VALID_CHROMOSOME_IN_SMARTPCA
            chromosome_numbers[molecule] = molecule_num

        short_name = marker[:20]
        if short_name in short_names:
            msg = 'The snp name % s can not be truncated to 20 characters'
            msg %= short_name
            raise ValueError(msg)
        if not no_markers and molecule == sex_chromosomes[0]:
            molecule_num = X_CHROMOSOME_IN_SMARTPCA
        line = ' % 20s % -9s % .6f % 15i\n' % (short_name, str(molecule_num),
                                               gen_loc, phys_loc)
        fhand.write(line)
    fhand.flush()
    return fhand


def _create_indi_file(individuals, genotypes):
    'It writes an eigenstrat indi file'
    indi_fhand = NamedTemporaryFile(prefix='smartpca', suffix='.indi')

    if individuals is None and genotypes is None:
        msg = 'Either the individuals or the genotypes should be given'
        raise ValueError(msg)

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        indis = genotypes.data.index
    else:
        indis = genotypes.data.columns

    if individuals is None:
        no_individuals = True
    else:
        data = individuals.data
        meta = individuals.meta
        if CLASSIFICATION_COL not in meta:
            msg = 'No classification column selected in the individuals'
            msg += ' metadata'
            raise ValueError(msg)
        class_col = meta[CLASSIFICATION_COL]
        gender_col = meta.get(GENDER_COL, None)
        no_individuals = False

    for individual in indis:
        if no_individuals:
            population = UNKNOWN_POP
            gender = 'U'
        else:
            if class_col:
                population = data.get_value(individual, class_col)
            else:
                population = UNKNOWN_POP
            if gender_col:
                gender = data.get_value(individual, gender_col)
                if gender not in ('M', 'F', 'U'):
                    msg = 'Valid genders are M, F, U, but was: {:s}'
                    msg = msg.format(str(gender))
                    raise RuntimeError(msg)
            else:
                gender = 'U'
        if len(individual) > 29:
            msg = 'Please use names for the individuals with no more than 29'
            msg += ' characters: ' + str(individual)
            raise RuntimeError(msg)
        indi_fhand.write(' % 29s % s % 20s\n' % (individual, gender,
                                                 population))
    indi_fhand.flush()
    return indi_fhand


def _read_eigenvalues_file(eigenvals_fhand):
    'It reads the eigenvalues result file from smartpca'
    eigenvalues = []
    for line in eigenvals_fhand:
        line = line.strip()
        if not line:
            continue
        eigenvalues.append(float(line))
    return eigenvalues


def _read_projections_file(princomps_fhand):
    'It reads the smartpca principal components file'
    projections = []
    indi_names = []
    for line in princomps_fhand:
        line = line.strip()
        if line.startswith('#'):
            continue
        items = line.split()
        items = items[:-1]
        indi_name = items.pop(0)
        indi_names.append(indi_name)
        projections.append([float(number) for number in items])
    projections = DataFrame(projections, index=indi_names)
    return projections
