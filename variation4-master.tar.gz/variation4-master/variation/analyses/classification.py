'''
Created on 04/04/2012

@author: jose
'''

import numpy
from sklearn.mixture import VBGMM
from pandas import DataFrame, Series


def do_gaussian_mixture(matrix, n_classes):
    '''It classifies the rows using a Variational Inference for the Gaussian
    Mixture Model.'''
    model = VBGMM(n_components=n_classes, covariance_type='tied')
    model.fit(matrix.data.values)
    classification = model.predict_proba(matrix.data.values)
    classification = DataFrame(classification, index=matrix.data.index.copy())
    return classification


def select_most_probable_class(classification):
    '''Given a classification with one value per row for every class it returns
    the most probable class for every row.

    e.g. row1  0.1  0.9          row1 1
         row2  0.8  0.1   ---->  row2 0
    The classification should be a DataFrame.
    '''
    index_for_max = lambda x: x.argmax()
    klass = numpy.apply_along_axis(index_for_max, 1, classification.values)
    klass = Series(klass, index=classification.index)
    return klass
