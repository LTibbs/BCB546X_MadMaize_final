from __future__ import division

from math import sqrt
from collections import Counter, defaultdict
import random

import numpy
from pandas import Series, DataFrame

from variation.inout.genetic import get_codec_from_genotypes
from variation.matrixwithmeta import (INDIVIDUALS_IN_ROWS, MatrixWithMeta,
                                      PLOIDY)
from variation.analyses.matrix_tools import transpose_genotypes
from variation.plot import ColorMap

# pylint: disable=C0111


def create_heterozigosity_calculator(genotype_codec):
    def _calc_heterozigosity(genotype_series):
        def recode_genotype(snp_geno):
            '''Given the genotype for a SNP and an individual as an int it
            returns -1 for missing data, 0 for homozygote and 1 for
            heterozygote'''
            geno = genotype_codec.decode_to_ints(snp_geno) if snp_geno else []
            return len(set(geno)) - 1
        counts = genotype_series.map(recode_genotype).value_counts()
        try:
            n_hets = counts[1]
        except KeyError:
            n_hets = 0
        try:
            n_hom = counts[0]
        except KeyError:
            n_hom = 0
        return n_hets / (n_hets + n_hom)
    return _calc_heterozigosity


def _calculate_heterozigosity(genotypes, axis):
    dframe = genotypes.data
    genotype_codec = get_codec_from_genotypes(genotypes)
    calc_het = create_heterozigosity_calculator(genotype_codec)
    return dframe.apply(calc_het, axis=axis)


def calculate_individual_heterozigosity(genotypes):
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        axis = 1
    else:
        axis = 0
    return _calculate_heterozigosity(genotypes, axis)


def calculate_marker_heterozigosity(genotypes):
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        axis = 0
    else:
        axis = 1
    return _calculate_heterozigosity(genotypes, axis)


def _group_genotypes(genotypes, classification):

    populations = classification.groupby(classification.values).groups

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        raise ValueError('Individuals should be in columns')

    for pop in populations.keys():
        yield pop, genotypes.data[populations[pop]]


def calculate_polymorphism(genotypes, threshold):
    '''It returns the ratio of polymorphic markers.

    A marker is polymorphic if its major allele frequency is under the threshold
    '''

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        raise ValueError('Individuals should be in columns')

    codec = get_codec_from_genotypes(genotypes)

    def calc_poly(marker_genotype):
        alelles = (codec.decode_to_ints(indi_geno) for indi_geno in marker_genotype if indi_geno != 0)
        allele_counts = Counter(alelle for a in alelles for alelle in a)
        allele_counts = allele_counts.viewvalues()
        if allele_counts:
            if max(allele_counts) / sum(allele_counts) < threshold:
                return 1
            else:
                return 0
        else:
            pass

    polymorphism = genotypes.data.apply(calc_poly, axis=1).dropna()
    return polymorphism.sum() / len(polymorphism)


def calculate_polymorphism_by_groups(genotypes, classification,
                                     threshold=0.95):

    meta = genotypes.meta
    pops_poly = {}
    for pop, pop_genotypes in _group_genotypes(genotypes, classification):
        poly = calculate_polymorphism(MatrixWithMeta(pop_genotypes, meta),
                                      threshold)
        pops_poly[pop] = poly
    return Series(pops_poly)


def calculate_obs_het(genotypes):
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        raise ValueError('Individuals should be in columns')

    codec = get_codec_from_genotypes(genotypes)

    def calc_obs_het(marker_genotype):
        indi_genotype = (codec.decode_to_ints(indi_geno) for indi_geno in marker_genotype if indi_geno != 0)
        het_alleles = [1 if len(set(alleles)) != 1 else 0 for alleles in indi_genotype]
        if het_alleles:
            het = (sum(het_alleles)) / len(het_alleles)
            return het
        else:
            pass

    obs_het = genotypes.data.apply(calc_obs_het, axis=1).dropna()

    return obs_het.sum() / len(obs_het)


def calculate_obs_het_by_groups(genotypes, classification,
                                min_num_individuals=5):
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        n_indis = len(genotypes.data.index)
    else:
        n_indis = len(genotypes.data.columns)

    meta = genotypes.meta
    pops_obs_het = {}
    for pop, pop_genotypes in _group_genotypes(genotypes, classification):
        if n_indis < min_num_individuals:
            obs_het = float('nan')
        else:
            obs_het = calculate_obs_het(MatrixWithMeta(pop_genotypes, meta))
        pops_obs_het[pop] = obs_het
    return Series(pops_obs_het)


def calculate_exp_het(genotypes):
    '''Unbias expected heterozygosity.

    2n/(2n - 1) * 1 - sum(p**2)
    '''
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        raise ValueError('Individuals should be in columns')

    ploidy = genotypes.meta[PLOIDY]
    codec = get_codec_from_genotypes(genotypes)

    def calc_exp_het(marker_genotype):
        indi_genotype = (codec.decode_to_ints(indi_geno) for indi_geno in marker_genotype if indi_geno != 0)
        alleles = Counter(allele for alleles in indi_genotype for allele in alleles)
        alleles = alleles.viewvalues()
        if alleles:
            num_alleles_obs = sum(alleles)
            alleles = [a / num_alleles_obs for a in alleles]
            het = 1 - sum(map(lambda x: pow(x, ploidy), alleles))
            nindis = num_alleles_obs / ploidy
            het = (2 * nindis) / (2 * nindis - 1) * het
            return het
        else:
            pass

    exp_het = genotypes.data.apply(calc_exp_het, axis=1).dropna()
    num_loci = len(exp_het)
    mean_exp_het = exp_het.sum() / num_loci
    var_exp_het = sum([pow((het - mean_exp_het), 2) for het in exp_het])
    var_exp_het = var_exp_het / (num_loci * (num_loci - 1))
    return mean_exp_het, sqrt(var_exp_het)


def calculate_exp_het_by_groups(genotypes, classification,
                                min_num_individuals=5):
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        n_indis = len(genotypes.data.index)
    else:
        n_indis = len(genotypes.data.columns)

    meta = genotypes.meta
    pops_exp_het = {}
    pops_std_exp_het = {}
    for pop, pop_genotypes in _group_genotypes(genotypes, classification):
        if n_indis < min_num_individuals:
            exp_het = float('nan')
        else:
            genos = MatrixWithMeta(pop_genotypes, meta)
            exp_het, std_exp_het = calculate_exp_het(genos)
        pops_exp_het[pop] = exp_het
        pops_std_exp_het[pop] = std_exp_het
    return Series(pops_exp_het), Series(pops_std_exp_het)


def calculate_basic_stats(genotypes, classification, min_num_individuals=10):
    '''It calculates observed homozygosity, unbiased expected heterozygosity,
    standard deviation of expected heterozygosity, 0.95 and 0.99 polimorphism,
    fixation index (F = [He -Ho]/He) and outcross rate (t = [1-F]/[1+F])
    '''
    stats = {}
    meta = genotypes.meta
    for pop, pop_genotypes in _group_genotypes(genotypes, classification):
        pop_genotypes = MatrixWithMeta(pop_genotypes, meta)
        if genotypes.meta[INDIVIDUALS_IN_ROWS]:
            n_indis = len(pop_genotypes.data.index)
        else:
            n_indis = len(pop_genotypes.data.columns)
        if n_indis < min_num_individuals:
            obs_het, exp_het, std_exp_het, P095, P099, fix_index, outcross_rate = [float('nan')] * 7
        else:
            obs_het = calculate_obs_het(pop_genotypes)
            exp_het, std_exp_het = calculate_exp_het(pop_genotypes)
            P095 = calculate_polymorphism(pop_genotypes, threshold=0.95)
            P099 = calculate_polymorphism(pop_genotypes, threshold=0.99)
            fix_index = (exp_het - obs_het) / exp_het
            outcross_rate = (1 - fix_index) / (1 + fix_index)
        pop_stats = Series([obs_het, exp_het, std_exp_het, P095, P099,
                            fix_index, outcross_rate, n_indis],
                       index=('obs_het', 'exp_het', 'std_exp_het', 'P095',
                              'P099', 'fix_index', 'outcross_rate', 'Nindis'))
        stats[pop] = pop_stats
    return DataFrame(stats)


class _PopCounts(object):
    def __init__(self, genotypes=None, classification=None,
                 min_num_individuals_per_pop=0):
        self._cache = {}
        self._min_num_individuals_per_pop = min_num_individuals_per_pop

        if genotypes is None:
            return

        if not genotypes.meta[INDIVIDUALS_IN_ROWS]:
            genotypes = transpose_genotypes(genotypes)

        self._markers = genotypes.data.columns
        self._num_accs, self._num_markers = genotypes.data.shape

        self._genotypes_per_pop = self._calc_genotypes_per_pop(genotypes.data,
                                                               classification)
        self._codec = get_codec_from_genotypes(genotypes)
        self._genotypes_meta = genotypes.meta
        self._num_pops = len(self._genotypes_per_pop)

    def _init_with_numpy(self, genotypes_per_pop, codec, genotypes_meta):
        self._num_accs = sum(geno.shape[0] for geno in genotypes_per_pop.viewvalues())
        one_pop = list(genotypes_per_pop.viewkeys())[0]
        self._num_markers = genotypes_per_pop[one_pop].shape[1]
        self._genotypes_per_pop = genotypes_per_pop
        self._codec = codec
        self._genotypes_meta = genotypes_meta
        self._num_pops = len(self._genotypes_per_pop)

    def _calc_genotypes_per_pop(self, genotypes_dframe, classification):

        # we store the classification as a dict with lists of indexes
        acc_indexes_by_pop = defaultdict(list)
        for index, acc in enumerate(genotypes_dframe.index):
            try:
                pop = classification[acc]
            except KeyError:
                msg = 'There is an individual with genotype not found in '
                msg += 'the classication: ' + acc
                raise ValueError(msg)
            acc_indexes_by_pop[pop].append(index)

        min_num_individuals_per_pop = self._min_num_individuals_per_pop
        genotypes_np = genotypes_dframe.as_matrix()
        genos_per_pop = {}
        small_pops = []
        for pop, acc_indexes in acc_indexes_by_pop.viewitems():
            if len(acc_indexes) < min_num_individuals_per_pop:
                small_pops.append(pop)
            genos_per_pop[pop] = genotypes_np[acc_indexes]

        if small_pops:
            msg = 'There are some small populations: ' + ','.join(small_pops)
            raise ValueError(msg)
        return genos_per_pop

    @staticmethod
    def _count_genotypes_for_marker(genotypes_for_marker, codec, ploidy):
        geno_counts = Counter(codec.decode_to_ints(geno) for geno in genotypes_for_marker)
        n_hom = 0   # num homozygotes
        n_genotypes = 0
        allele_counts = defaultdict(int)
        for genotype, counts in geno_counts.viewitems():
            if genotype is None:
                continue
            if len(set(genotype)) == 1:
                n_hom += 1 * counts
            for allele in genotype:
                allele_counts[allele] += counts
            n_genotypes += counts
        n_chroms = n_genotypes * ploidy
        allele_freqs = {ale: count / n_chroms for ale, count in allele_counts.viewitems()}
        return allele_freqs, n_hom, n_genotypes

    @property
    def _genotypic_counts(self):
        if self._cache.get('geno_counts', None) is not None:
            return self._cache['geno_counts']
        codec = self._codec

        ploidy = self._genotypes_meta[PLOIDY]

        # pops are in rows, markers are in columns
        n_homs = []
        n_genotypes = []
        num_pops = self._num_pops
        num_markers = self._num_markers
        allele_freqs = defaultdict(lambda: numpy.zeros((num_pops,
                                                        num_markers)))
        pops = []
        for pop_index, (pop, genotypes) in enumerate(self._genotypes_per_pop.viewitems()):
            pops.append(pop)
            n_homs_per_pop = []
            n_genotypes_per_pop = []
            for mar in xrange(genotypes.shape[1]):
                mark_genos = genotypes[:, mar]
                counts = self._count_genotypes_for_marker(mark_genos, codec,
                                                          ploidy)
                all_freqs, n_hom, n_genos = counts
                n_homs_per_pop.append(n_hom)
                n_genotypes_per_pop.append(n_genos)
                for allele, freq in all_freqs.viewitems():
                    allele_freqs[allele][pop_index, mar] += freq
            n_homs.append(n_homs_per_pop)
            n_genotypes.append(n_genotypes_per_pop)

        n_homs = numpy.array(n_homs)
        n_genotypes = numpy.array(n_genotypes, dtype=numpy.float)

        geno_counts = {'n_homs': n_homs, 'n_genotypes': n_genotypes,
                       'allele_freqs': allele_freqs, 'pop_order': pops}
        self._cache['geno_counts'] = geno_counts
        return self._cache['geno_counts']

    def _jackknife_indis_within_pop(self, jackknife_sample_percent=None,
                                    n_indis_to_sample=None):
        genotypes_per_pop = self._genotypes_per_pop

        genotypes = {}
        for pop, pop_genotypes in genotypes_per_pop.viewitems():

            n_indis = pop_genotypes.shape[0]
            if jackknife_sample_percent is not None:
                sampled_n_indis = int(n_indis * jackknife_sample_percent / 100)
            else:
                sampled_n_indis = n_indis_to_sample
            indis_index = list(range(n_indis))
            try:
                boot_index = random.sample(indis_index, sampled_n_indis)
            except ValueError:
                boot_index = None
            if boot_index is not None:
                genotypes[pop] = pop_genotypes[boot_index, :]
        return genotypes


class PopPolymorphism(_PopCounts):
    def __init__(self, genotypes=None, classification=None,
                 polymorphism_threshold=100, num_repeats=100, confidence=95):
        self._cache = {}
        self.polymorphism_threshold = polymorphism_threshold
        self.num_repeats = num_repeats
        self._confidence = confidence

        if genotypes is None:
            return
        super(PopPolymorphism, self).__init__(genotypes, classification)

    def _init_with_numpy(self, genotypes_per_pop, codec, genotypes_meta,
                         num_repeats=0):
        self.num_repeats = num_repeats
        super(PopPolymorphism, self)._init_with_numpy(codec=codec,
                                           genotypes_per_pop=genotypes_per_pop,
                                           genotypes_meta=genotypes_meta)

    def _polymorphism(self):
        threshold = self.polymorphism_threshold
        counts = self._genotypic_counts
        allele_freqs = counts['allele_freqs'].viewvalues()
        pop_order = counts['pop_order']
        max_freqs = None
        for allele_freq in allele_freqs:
            if max_freqs is None:
                max_freqs = allele_freq
            else:
                max_freqs = numpy.maximum(max_freqs, allele_freq)
        threshold /= 100

        num_markers_per_pop = numpy.sum(max_freqs != 0, axis=1)
        marker_is_polymorphic = numpy.logical_and(max_freqs < threshold,
                                                  max_freqs != 0)
        polymorphism = marker_is_polymorphic.sum(axis=1) / num_markers_per_pop
        return polymorphism, pop_order

    @property
    def polymorphism(self):
        polymorphism, pop_order = self._polymorphism()
        polymorphism = Series(polymorphism,
                              index=pop_order)
        return polymorphism

    def rarefaction(self):
        confidence = self._confidence
        lower = (100 - confidence) / 2
        upper = 100 - (100 - confidence) / 2

        num_indis = (genos.shape[0] for genos in self._genotypes_per_pop.viewvalues())
        max_num_indis_in_pop = max(num_indis)
        median = []
        lower_ci = []
        upper_ci = []
        range_start = 1
        range_end = max_num_indis_in_pop + 1
        for n_indis in xrange(range_start, range_end):
            polymorphism_estimations = []
            pop_labels = None
            for index in xrange(self.num_repeats):
                genotypes = self._jackknife_indis_within_pop(n_indis_to_sample=n_indis)
                pop_poly = PopPolymorphism()
                pop_poly._init_with_numpy(genotypes, codec=self._codec,
                                           genotypes_meta=self._genotypes_meta)
                poly = pop_poly._polymorphism()
                polymorphism_estimations.append(poly[0])
                if pop_labels is None:
                    pop_labels = poly[1]
            polymorphism_estimations = numpy.array(polymorphism_estimations)
            conf_inter = numpy.percentile(polymorphism_estimations,
                                          [lower, 50, upper], axis=0,
                                          overwrite_input=True)
            lower_ci.append(Series(conf_inter[0], index=pop_labels))
            median.append(Series(conf_inter[1], index=pop_labels))
            upper_ci.append(Series(conf_inter[2], index=pop_labels))

        median = DataFrame(median, index=xrange(range_start, range_end))
        upper_ci = DataFrame(upper_ci, index=xrange(range_start, range_end))
        lower_ci = DataFrame(lower_ci, index=xrange(range_start, range_end))
        return {'median': median, 'upper_ci': upper_ci, 'lower_ci': lower_ci}


class AlleleFreqsDistribs(_PopCounts):
    def maf_histograms(self):
        counts = self._genotypic_counts
        allele_freqs = counts['allele_freqs'].viewvalues()
        pop_order = counts['pop_order']
        max_freqs = None
        for allele_freq in allele_freqs:
            if max_freqs is None:
                max_freqs = allele_freq
            else:
                max_freqs = numpy.maximum(max_freqs, allele_freq)
        hists = []
        for pop_index, pop in enumerate(pop_order):
            hist, bin_edges = numpy.histogram(max_freqs[pop_index],
                                              range=(0.5, 1),
                                              bins=10,
                                              density=False)
            hist = hist / hist.sum()
            hists.append(hist)
        hists = DataFrame(hists, index=pop_order, columns=bin_edges[:-1])
        return hists

    def freq_by_locus(self):
        counts = self._genotypic_counts
        allele_freqs = counts['allele_freqs']
        pop_order = counts['pop_order']
        reference_allele = numpy.zeros(self._num_markers)
        for marker in range(self._num_markers):
            for allele, allele_freq in allele_freqs.viewitems():
                if sum(allele_freq[:, marker]) > 0:
                    reference_allele[marker] = allele
                    break
                else:
                    continue
        pop_freqs = []
        for pop_index, pop in enumerate(pop_order):
            pop_freqs.append([allele_freqs[reference_allele[marker]][pop_index, marker] for marker in range(self._num_markers)])
        return DataFrame(pop_freqs, index=pop_order, columns=self._markers)


def generate_plot_groups_for_rarefaction(rarefaction_mean, upper_ci=None,
                                         lower_ci=None, color_mapper=None):
    mean = rarefaction_mean
    if upper_ci and lower_ci:
        conf_intervals = True
    else:
        conf_intervals = False

    if color_mapper == None:
        n_pops = len(mean.columns)
        color_map = ColorMap(num_colors=n_pops)
    else:
        color_map = color_mapper

    groups = []
    for index, (pop, pop_means) in enumerate(mean.iteritems()):
        pop_means = pop_means.dropna()
        if conf_intervals:
            upper_cis = upper_ci[pop].dropna()
            lower_cis = lower_ci[pop].dropna()
            upper_error_bar = upper_cis - pop_means
            lower_error_bar = pop_means - lower_cis
        if color_mapper:
            color = color_map[pop]
        else:
            color = color_map[index]
        group = {'label': pop, 'x': pop_means.index, 'y': pop_means,
                 'color': color}
        if conf_intervals:
            group['y_error_bars'] = (lower_error_bar, upper_error_bar)
        groups.append(group)
    return groups
