from __future__ import division

from collections import defaultdict
import random
from math import acos, cos, radians, sin

import numpy
from scipy.spatial.distance import pdist, squareform
from scipy.stats import stats as scpy_stats
from cogent.maths.stats import test
from pandas import DataFrame

from variation.analyses.populations import (codominant_distance,
                                            codominant_population_distance)
from variation.matrixwithmeta import (MatrixWithMeta, BINARY, DISTANCE,
                                      INDIVIDUALS_IN_ROWS, PLOIDY)
from variation.analyses.pop_stats import _PopCounts
from variation.inout.genetic import get_codec_from_genotypes


# pylint: disable=W0601
# pylint: disable=C0301
# pylint: disable=C0111

BINARY_DIST_METHODS = ('jaccard', 'dice')


def _get_square_distance_matrix(distances):
    'Given a distance matrix it returns a squared version'
    shape = distances.shape
    if len(shape) == 1:
        return squareform(distances, force='tomatrix')
    elif shape[0] == shape[1]:
        return distances
    else:
        raise ValueError('Strange shape for a distance matrix')


def binary_matrix_distance(matrix, method='jaccard'):
    'Distances between rows in a Matrix with 1 or 0'
    if method not in BINARY_DIST_METHODS:
        msg = 'Distance method not supported : {:s}'.format(method)
        raise ValueError(method)
    if matrix.kind != BINARY:
        msg = 'Distance only available for binary matrixes.'
        raise ValueError(msg)
    row_labels = matrix.data.index
    numpy_vals = matrix.data.values
    if method in ('jaccard', 'dice'):
        dist = pdist(numpy_vals, metric=method)
        dist = _get_square_distance_matrix(dist)

    dist = DataFrame(dist, index=row_labels, columns=row_labels)
    dist = MatrixWithMeta(dist)
    dist.kind = DISTANCE

    return dist


def _individual_genetic_distance(geno1, geno2, method, ploidy):
    if method != 'kosman':
        msg = 'Individual distance is not available: ' + method
        raise NotImplementedError(msg)

    sum_dists = 0
    num_dists = 0
    for geno_mar_1, geno_mar_2 in zip(geno1, geno2):
        dist = _individual_genetic_distance_per_locus(geno_mar_1, geno_mar_2,
                                                      ploidy)
        if dist is not None:
            sum_dists += dist
            num_dists += 1
    if num_dists == 0:
        raise ValueError('Individual with only missing data')
    return sum_dists / num_dists


def _individual_genetic_distance_per_locus(geno1, geno2, ploidy):
    if geno1 is None or geno2 is None:
        return None

    if geno1 == geno2:
        return 0

    geno1_is_homo = len(set(geno1)) == 1
    geno2_is_homo = len(set(geno2)) == 1
    if geno1_is_homo and geno2_is_homo:
        return 1
    # TODO this only will work for diploids
    if ploidy != 2:
        raise NotImplementedError()
    n_shared_alleles = len(set(geno1).intersection(geno2))
    return n_shared_alleles / ploidy


def pairwise_individual_genetic_distance(genotypes, method='kosman'):
    '''It computes pairwise distances between individuals.

    For the time being markers are required to be biallelic

    Available methods:
    - kosman: as described in Kosman and Leonard (2005) "Similarity
    coefficients for molecular markers in studies of genetic relationships
    between individuals for haploid, diploid, and polyploid species" Molecular
    Ecology 14, 415:424
    '''

    genotype_codec = get_codec_from_genotypes(genotypes)
    meta = genotypes.meta
    ploidy = genotypes.meta[PLOIDY]
    genotypes = genotypes.data

    if meta[INDIVIDUALS_IN_ROWS]:
        indi_names = genotypes.index
    else:
        indi_names = genotypes.columns

    genotypes = genotypes.applymap(genotype_codec.decode_to_ints)

    n_indis = len(indi_names)
    dists = []
    for row_indi in xrange(n_indis):
        geno1 = genotypes.iloc[row_indi]
        for col_indi in xrange(row_indi + 1, n_indis):
            geno2 = genotypes.iloc[col_indi]
            dist = _individual_genetic_distance(geno1, geno2, method, ploidy)
            dists.append(dist)
    dists = squareform(dists)
    return DataFrame(dists, columns=indi_names, index=indi_names)


def _geographic_distance(location1, location2):
    lon1 = location1[0]
    lat1 = location1[1]
    lon2 = location2[0]
    lat2 = location2[1]
    partial = (cos(radians(90 - lat1)) * cos(radians(90 - lat2)) +
               sin(radians(90 - lat1)) * sin(radians(90 - lat2)) *
               cos(radians(lon1 - lon2)))
    if 1.0 < partial < 1.0000001:
        # sometimes there's a precision error and the acos throws a
        # ValueError: math domain error
        partial = 1.0
    if -1.0000001 < partial < -1.0:
        partial = -1.0
    dist = 6371 * acos(partial)
    return dist


def pairwise_geographic_distance(locations, longitude_col='Longitude',
                                 latitude_col='Latitude'):
    '''It computes pairwise geographic distances between individuals using the
    Haversine equation

    distance = acos[sin(lat1) * sin(lat2) + cos(lat1) * cos(lat2)
               * cos(lon2 - lon1)] * 6371

    being lat and lon in radians

    Return distances in Km
    '''

    locations = locations.data

    indi_names = locations.index
    n_indis = len(indi_names)
    dists = []
    for row_indi in xrange(n_indis):
        location1 = list(locations.iloc[row_indi][[longitude_col,
                                                   latitude_col]])
        for col_indi in xrange(row_indi + 1, n_indis):
            location2 = list(locations.iloc[col_indi][[longitude_col,
                                                       latitude_col]])
            dist = _geographic_distance(location1, location2)
            dists.append(dist)
    dists = squareform(dists)
    return DataFrame(dists, columns=indi_names, index=indi_names)


def correlation_distance_matrices(matrix1, matrix2, mantel_permutations=1000):

    m1_rows = matrix1.index
    m2_rows = matrix2.index
    m1_cols = matrix1.columns
    m2_cols = matrix2.columns

    if len(m1_rows) != len(m1_cols) or len(m2_rows) != len(m2_cols) or matrix1.shape != matrix2.shape:
        msg = 'Distance matrices must be square and equal size: matrix1 '
        msg += str(matrix1.shape) + ', matrix2 ' + str(matrix2.shape)
        raise RuntimeError(msg)
    if any(m1_rows != m1_cols):
        different = set(m1_rows).difference(m1_cols)
        msg = 'Distance matrices must contain the same elements in rows'
        msg += ' and columns. check the first matrix: ' + ' '.join(different)
        raise RuntimeError(msg)
    if any(m2_rows != m2_cols):
        different = set(m2_rows).difference(m2_cols)
        msg = 'Distance matrices must contain the same elements in rows'
        msg += ' and columns. Check the second matrix: ' + ' '.join(different)
        raise RuntimeError(msg)
    if any(m1_rows != m2_rows):
        different = set(matrix1.index).difference(matrix2.index)
        msg = 'The following elements are present in one matrix but not in'
        msg += ' the other: ' + ' '.join(different)
        raise RuntimeError(msg)

    results = {}

    if mantel_permutations > 0:
        pvalue = test.mantel_test(matrix1, matrix2, 100, alt="two sided")[0]
        results['mantel_p-value'] = pvalue

    x = squareform(matrix1)
    y = squareform(matrix2)
    slope, intercept, r_value, p_value, std_err = scpy_stats.linregress(x, y)
    results['slope'] = slope
    results['intercept'] = intercept
    results['r'] = r_value

    return results


class PopDistances(_PopCounts):
    def __init__(self, genotypes=None, classification=None,
                 conf_intervals_repeats=1000, permutation_repeats=1000,
                 confidence=95, min_num_individuals_per_pop=7):
        '''It inits the class.

        It can calculate confidence intervals and significances for the
        genetic distances.
        The confidence intervals are calculated boostraping the individuals
        inside every population that appears in the classification.
        If bootstrap_repeats are set to 0 no confidence intervals will be
        generated.
        The significances are calculated by permutating the individuals among
        the populations given in the classification.
        if permutation_repeats are set to 0 no permutation_repeats will
        be generated.

        genotypes and classification are not meant to be None. They have
        default None values just because we need them internally for the
        bootstraping process.
        '''
        self._cache = {}
        self._min_num_individuals_per_pop = min_num_individuals_per_pop

        self._confidence = confidence
        self.jackknife_sample_percent = 75
        self.min_num_individuals_per_pop_per_marker = 4

        if genotypes is None:
            return
        super(PopDistances, self).__init__(genotypes, classification,
                       min_num_individuals_per_pop=min_num_individuals_per_pop)

        self._remove_markers_with_few_ind_in_any_pop()
        self.conf_intervals_repeats = conf_intervals_repeats
        self.permutation_repeats = permutation_repeats

    def _init_with_numpy(self, genotypes_per_pop, codec, genotypes_meta,
                         conf_intervals_repeats=0, permutation_repeats=0):
        self._num_accs = sum(geno.shape[0] for geno in genotypes_per_pop.viewvalues())
        one_pop = list(genotypes_per_pop.viewkeys())[0]
        self._num_markers = genotypes_per_pop[one_pop].shape[1]
        self._genotypes_per_pop = genotypes_per_pop
        self._remove_markers_with_few_ind_in_any_pop()
        self._codec = codec
        self._genotypes_meta = genotypes_meta
        self._num_pops = len(self._genotypes_per_pop)
        self.conf_intervals_repeats = conf_intervals_repeats
        self.permutation_repeats = permutation_repeats

    def _remove_markers_with_few_ind_in_any_pop(self):
        markers_with_data = []
        min_num_indis_per_pop_per_marker = self.min_num_individuals_per_pop_per_marker
        for pop_index, pop_genotypes in enumerate(self._genotypes_per_pop.viewvalues()):
            for marker_index in xrange(self._num_markers):
                not_null_genos = numpy.sum(pop_genotypes[:, marker_index] != 0)
                if not_null_genos < min_num_indis_per_pop_per_marker:
                    marker_with_data = False
                else:
                    marker_with_data = True
                if pop_index == 0:
                    markers_with_data.append(marker_with_data)
                else:
                    markers_with_data[marker_index] &= marker_with_data

        if all(markers_with_data):
            return
        # We remove the markers with no data
        markers_with_data = [idx for idx, marker in enumerate(markers_with_data) if marker]
        self._num_markers = len(markers_with_data)
        genotypes_per_pop = {}
        for pop, pop_genotypes in self._genotypes_per_pop.viewitems():
            genotypes_per_pop[pop] = pop_genotypes[:, markers_with_data]
        self._genotypes_per_pop = genotypes_per_pop

    def _obs_het_by_loci(self):
        n_homs = self._genotypic_counts['n_homs']
        n_genotypes = self._genotypic_counts['n_genotypes']
        return (n_genotypes - n_homs) / n_genotypes

    def _exp_het_by_loci(self):
        allele_freqs = self._genotypic_counts['allele_freqs']
        sum_allele_freqs = numpy.zeros((self._num_pops, self._num_markers))
        # 1- sum(squared(allele frequency))
        for allele in allele_freqs:
            sum_allele_freqs += pow(allele_freqs[allele], 2)
        return 1 - sum_allele_freqs

    def _avg_obs_het_by_loci(self):
        if self._cache.get('avg_obs_het_by_loci', None) is not None:
            return self._cache['avg_obs_het_by_loci']
        obs_het = self._obs_het_by_loci().mean(axis=0)
        self._cache['avg_obs_het_by_loci'] = obs_het
        return self._cache['avg_obs_het_by_loci']

    def _hs_by_loci(self):
        return self._exp_het_by_loci().mean(axis=0)

    def _ht_by_loci(self):
        allele_freqs = self._genotypic_counts['allele_freqs']
        sum_allele_freqs = numpy.zeros(self._num_markers)
        # 1 - sum(squared(mean allele frequency over the populations))
        for allele in allele_freqs:
            sum_allele_freqs += pow(allele_freqs[allele].mean(axis=0), 2)
        return 1 - sum_allele_freqs

    def _pop_size_harmonic_mean_by_loci(self):
        if self._cache.get('pop_by_loci_harmonic_mean', None) is not None:
            return self._cache['pop_by_loci_harmonic_mean']
        n_genotypes = self._genotypic_counts['n_genotypes']
        mean = len(n_genotypes) / numpy.power(n_genotypes, -1).sum(axis=0)
        self._cache['pop_by_loci_harmonic_mean'] = mean
        return self._cache['pop_by_loci_harmonic_mean']

    def _corrected_hs_by_loci(self):
        ''' cH_s = hm/(hm-1) * (H_s - avgH_o/(2 * hm))

        where hm is the harmonic mean and avgH_o is the mean observed
        heterozygosity
        '''
        if self._cache.get('corrected_hs_by_loci', None) is not None:
            return self._cache['corrected_hs_by_loci']
        avg_obs_het_by_loci = self._avg_obs_het_by_loci()
        harmonic_mean_by_loci = self._pop_size_harmonic_mean_by_loci()
        hs_by_loci = self._hs_by_loci()
        term = harmonic_mean_by_loci / (harmonic_mean_by_loci - 1)
        val = term * (hs_by_loci - (avg_obs_het_by_loci / (2 * harmonic_mean_by_loci)))
        self._cache['corrected_hs_by_loci'] = val
        return self._cache['corrected_hs_by_loci']

    def _corrected_hs(self):
        if self._cache.get('corrected_hs', None) is not None:
            return self._cache['corrected_hs']
        self._cache['corrected_hs'] = self._corrected_hs_by_loci().mean()
        return self._cache['corrected_hs']

    def _corrected_ht_by_loci(self):
        ''' cH_t = H_t + cH_s/(hm * k) - avgH_o/(2 * hm * k

        where hm is the harmonic mean and k is the number of populations
        '''
        avg_obs_het_by_loci = self._avg_obs_het_by_loci()
        harmonic_mean_by_loci = self._pop_size_harmonic_mean_by_loci()
        corrected_hs_by_loci = self._corrected_hs_by_loci()
        ht_by_loci = self._ht_by_loci()
        num_pop = self._num_pops
        second_term = corrected_hs_by_loci / (harmonic_mean_by_loci * num_pop)
        third_term = avg_obs_het_by_loci / (2 * harmonic_mean_by_loci * num_pop)
        return ht_by_loci + second_term - third_term

    def _corrected_ht(self):
        if self._cache.get('corrected_ht', None) is not None:
            return self._cache['corrected_ht']
        self._cache['corrected_ht'] = self._corrected_ht_by_loci().mean()
        return self._cache['corrected_ht']

    def _gst(self):
        cht = self._corrected_ht()
        chs = self._corrected_hs()
        return (cht - chs) / cht

    @property
    def gst(self):
        '''Gst is calculated following Meirmans and Hedrick
        with the correction of Nei and Cheeser and Nei for small population
        size and inbreeding applied in the calculations of HT and HS.
        Gst = (cHt -cHs) / cHt
        '''

        result = {'value': self._gst()}
        method = 'gst'
        if self.conf_intervals_repeats:
            result['conf_intervals'] = self._confidence_intervals([method])
        if self.permutation_repeats:
            significance = self._significance([method],
                                              {method: result['value']})
            significance = significance[method]
            result['significance'] = significance
        return result

    def _nei_gst_prime(self):
        'With no confidence'
        num_pop = self._num_pops
        cht = self._corrected_ht()
        chs = self._corrected_hs()
        return num_pop * (cht - chs) / (num_pop * cht - chs)

    @property
    def nei_gst_prime(self):
        '''Standarized Gst
        Nei's standardized G'st(Nei) corrects for bias when the number of
        populations k is small.
        G'st = num_pops * (cHt - cHs) / (num_pops * cHt - cHs)
        '''
        result = {'value': self._nei_gst_prime()}
        method = 'nei_gst_prime'

        if self.conf_intervals_repeats:
            result['conf_intervals'] = self._confidence_intervals([method])
        if self.permutation_repeats:
            significance = self._significance([method],
                                              {method: result['value']})
            significance = significance[method]
            result['significance'] = significance
        return result

    def _hedrick_gst_prime_prime(self):
        nei_gst = self._nei_gst_prime()
        chs = self._corrected_hs()
        return nei_gst / (1 - chs)

    @property
    def hedrick_gst_prime_prime(self):
        '''Hedrick's standardized Gst
        further corrected for bias when the number of populations k is small.
        Gst = G'st / (1 - cHs)
        '''
        result = {'value': self._hedrick_gst_prime_prime()}
        method = 'hedrick_gst_prime_prime'

        if self.conf_intervals_repeats:
            result['conf_intervals'] = self._confidence_intervals([method])
        if self.permutation_repeats:
            significance = self._significance([method],
                                              {method: result['value']})
            significance = significance[method]
            result['significance'] = significance

        return result

    def _jost_dest(self):
        num_pop = self._num_pops
        cht = self._corrected_ht()
        chs = self._corrected_hs()
        term = num_pop / (num_pop - 1)
        return term * (cht - chs) / (1 - chs)

    @property
    def jost_dest(self):
        '''Jost's estimate of differentiation (Dest)
        Calculated following Meirmans and Hedrick eq 2. Their recommendation
        to average cHS and cHT for estimating Dest across loci is also used.
        '''
        result = {'value': self._jost_dest()}
        method = 'jost_dest'

        if self.conf_intervals_repeats:
            result['conf_intervals'] = self._confidence_intervals([method])
        if self.permutation_repeats:
            significance = self._significance([method],
                                              {method: result['value']})
            significance = significance[method]
            result['significance'] = significance
        return result

    @property
    def all_dists(self):
        dist_methods = ['gst', 'nei_gst_prime', 'hedrick_gst_prime_prime',
                        'jost_dest']

        distances = {}
        for method in dist_methods:
            dist_funct = getattr(self, '_' + method)
            value = dist_funct()
            distances[method] = value

        if self.conf_intervals_repeats:
            conf_intervals = self._confidence_intervals(dist_methods)
        if self.permutation_repeats:
            significance = self._significance(dist_methods,
                                              distances)
        results = {}
        for method in dist_methods:
            results[method] = {}
            results[method]['value'] = distances[method]
            results[method]['conf_intervals'] = conf_intervals[method]
            results[method]['significance'] = significance[method]

        return results

    def _jackknife_indis_within_pop(self):
        genotypes_per_pop = self._genotypes_per_pop
        jackknife_sample_percent = self.jackknife_sample_percent

        genotypes = {}
        for pop, pop_genotypes in genotypes_per_pop.viewitems():
            n_indis = pop_genotypes.shape[0]
            sampled_n_indis = int(n_indis * jackknife_sample_percent / 100)
            indis_index = list(range(n_indis))
            boot_index = random.sample(indis_index, sampled_n_indis)
            genotypes[pop] = pop_genotypes[boot_index, :]
        return genotypes

    def _confidence_intervals(self, dist_methods):
        confidence = self._confidence
        PopDists = self.__class__

        distances = defaultdict(list)
        for index in xrange(self.conf_intervals_repeats):
            genotypes = self._jackknife_indis_within_pop()
            pop_dists = PopDists()
            pop_dists._init_with_numpy(genotypes, codec=self._codec,
                                       genotypes_meta=self._genotypes_meta)
            for method in dist_methods:
                value = getattr(pop_dists, method)['value']
                distances[method].append(value)

        # confidence intervals
        lower = (100 - confidence) / 2
        upper = 100 - (100 - confidence) / 2
        intervals = {}
        for method in dist_methods:
            interval = numpy.percentile(distances[method], [lower, upper])
            intervals[method] = interval
        return intervals

    def _significance(self, dist_methods, dist_values):
        genotypes_per_pop = self._genotypes_per_pop
        PopDists = self.__class__

        genotypes = numpy.vstack(list(genotypes_per_pop.viewvalues()))
        tot_n_indis = genotypes.shape[0]

        distances = defaultdict(list)
        for index in xrange(self.permutation_repeats):
            indis_index = list(range(tot_n_indis))
            random.shuffle(indis_index)
            shuffle_genotypes = genotypes[indis_index, :]
            sampled_genotypes = {}
            acc_index = 0
            for pop, pop_genotypes in genotypes_per_pop.viewitems():
                pop_n_indis = pop_genotypes.shape[0]
                acc_index_2 = acc_index + pop_n_indis
                sampled_genotypes[pop] = shuffle_genotypes[acc_index:acc_index_2, :]
                assert sampled_genotypes[pop].shape[0] == pop_n_indis
                acc_index = acc_index_2
            pop_dists = PopDists()
            pop_dists._init_with_numpy(sampled_genotypes, codec=self._codec,
                                       genotypes_meta=self._genotypes_meta)
            for method in dist_methods:
                value = getattr(pop_dists, method)['value']
                distances[method].append(value)

        probabilities = {}
        for method in dist_methods:
            probability = scpy_stats.percentileofscore(distances[method],
                                                       dist_values[method])
            probabilities[method] = probability

        return probabilities

    def pairwise_distances(self, method):
        '''Available methods are: gst, nei_gst_prime, hedrick_gst_prime_prime
        and jost_dest

        '''
        results = {}
        reference_pops = self._genotypes_per_pop.keys()
        comparision_pops = reference_pops
        distance_matrix = DataFrame(index=reference_pops,
                                    columns=reference_pops)
        if self.permutation_repeats:
            significance_matrix = DataFrame(index=reference_pops,
                                            columns=reference_pops)
        for pop1 in reference_pops:
            for pop2 in comparision_pops:
                if pop1 == pop2:
                    distance_matrix.ix[pop1][pop2] = 0
                else:
                    pairwise_geno = {}
                    pairwise_geno[pop1] = self._genotypes_per_pop[pop1]
                    pairwise_geno[pop2] = self._genotypes_per_pop[pop2]

                    pop_dists = self._create_empty_self_copy()
                    pop_dists._init_with_numpy(pairwise_geno,
                                               codec=self._codec,
                                           genotypes_meta=self._genotypes_meta,
                                  permutation_repeats=self.permutation_repeats)

                    result = getattr(pop_dists, method)
                    distance_matrix.ix[pop2][pop1] = result['value']
                    distance_matrix.ix[pop1][pop2] = result['value']
                    if self.permutation_repeats:
                        significance = result['significance']
                        significance_matrix.ix[pop2][pop1] = significance
                        significance_matrix.ix[pop1][pop2] = significance
            comparision_pops = comparision_pops[1:]

        results['distance_matrix'] = distance_matrix
        if self.permutation_repeats:
            results['significance_matrix'] = significance_matrix

        return results

    def _create_empty_self_copy(self):
        PopDists = self.__class__
        pop_dists = PopDists()
        pop_dists.jackknife_sample_percent = self.jackknife_sample_percent
        pop_dists.min_num_individuals_per_pop_per_marker = self.min_num_individuals_per_pop_per_marker
        pop_dists.min_num_individuals_per_pop = self._min_num_individuals_per_pop
        return pop_dists

    def jackknife_pairwise_distances(self, method, num_repeats=100):
        for index in xrange(num_repeats):
            genotypes = self._jackknife_indis_within_pop()
            pop_dists = self._create_empty_self_copy()
            pop_dists._init_with_numpy(genotypes, codec=self._codec,
                                       genotypes_meta=self._genotypes_meta)
            yield pop_dists.pairwise_distances(method)['distance_matrix']
