'''
Created on 20/08/2012

@author: jose
'''
from __future__ import division

from numpy import average, std
from pandas import Series

from variation.iterutils import rolling_window
from variation.analyses.matrix_tools import (marker_map_type,
                                             transpose_genotypes)
from variation.matrixwithmeta import (GENETIC, PHYSICAL, MOLECULE_COL,
                                      LOCATION_COL, LINKAGE_GROUP_COL,
                                      GENETIC_LOCATION_COL, MatrixWithMeta,
                                      INDIVIDUALS_IN_ROWS)
from variation.inout.genetic import create_dummy_marker_map


def apply_rolling(series, func, window_width, min_items=None):
    '''It applies a function to a series using a moving window.

    The position should be coded in the series index.
    If min_items is given the windows with less items will be skipped.
    '''
    locations = []
    values = []
    for win, items in rolling_window(series, window_width=window_width):
        if min_items is not None and len(items) < min_items:
            continue
        values.append(func(items))
        locations.append((win[0] + win[1]) / 2)
    return Series(values, index=locations)


def rolling_average(series, window_width, min_items=None):
    '''It calculates a mean in a rolling window.

    The position should be coded in the series index.
    If min_items is given the windows with less items will be skipped.
    '''
    return apply_rolling(series=series, func=average,
                         window_width=window_width, min_items=min_items)


def rolling_std(series, window_width, min_items=None):
    '''It calculates a standard deviation in a rolling window.

    The position should be coded in the series index.
    If min_items is given the windows with less items will be skipped.
    '''
    return apply_rolling(series=series, func=std,
                         window_width=window_width, min_items=min_items)


def rolling_window_genotypes(genotypes, window_width, marker_map=None,
                             map_type_to_use=None, overlapping_windows=False):
    '''It generates genotype matrices along the map.

    If no marker_map is provided a dummy map is created based on the order of
    the markers in the genotypes
    '''
    if not genotypes.meta[INDIVIDUALS_IN_ROWS]:
        genotypes = transpose_genotypes(genotypes)

    markers = genotypes.data.columns

    if marker_map is not None:
        map_markers = marker_map.data.index
        if not set(markers).issubset(map_markers):
            diff_markers = set(markers).difference(map_markers)
            msg = 'Markers ' + ' '.join(diff_markers) + ' in the genotypes are'
            msg += ' not present in the distance_map provided'
            raise ValueError(msg)

        common_map_markers = list(set(markers).intersection(map_markers))
        marker_map = MatrixWithMeta(marker_map.data.ix[common_map_markers],
                                    marker_map.meta)

        if map_type_to_use is None:
            try:
                map_type_to_use = marker_map_type(marker_map)
            except ValueError:
                msg = 'Please specify if the map type to use should be genetic'
                msg += ' or physical or fix the map'
                raise ValueError(msg)

        if map_type_to_use not in (GENETIC, PHYSICAL):
            msg = 'sort_by should be either GENETIC or PHYSICAL'
            raise ValueError(msg)

        meta = marker_map.meta
        if map_type_to_use == PHYSICAL:
            col1 = meta[MOLECULE_COL]
            col2 = meta[LOCATION_COL]
        elif map_type_to_use == PHYSICAL:
            col1 = meta[LINKAGE_GROUP_COL]
            col2 = meta[GENETIC_LOCATION_COL]
    else:
        #If no marker_map is provided, a dummy one is generated
        marker_map = create_dummy_marker_map(markers)
        col1 = marker_map.meta[MOLECULE_COL]
        col2 = marker_map.meta[LOCATION_COL]

    # an alternative implementation, maybe faster, would be to sort the map
    # and then go row by row obtaining the markers that belong to the same
    # chromosome

    # if the markers are in rows transpose the data, it should be more
    # efficient

    genotypes_data = genotypes.data
    genotypes_meta = genotypes.meta

    mol_col = marker_map.meta[MOLECULE_COL]
    if len(set(marker_map.data[mol_col])) == 1:
        mol = list(set(marker_map.data[mol_col]))[0]
        grouped_marker_map = {mol: list(marker_map.data.index)}
    else:
        grouped_marker_map = marker_map.data.groupby([col1]).groups

    for mol, markers in grouped_marker_map.viewitems():
        marker_locs = marker_map.data.ix[markers][col2]
        marker_locs = marker_locs.order()
        for win, markers_in_win in rolling_window(marker_locs,
                                                  window_width=window_width,
                                      overlapping_windows=overlapping_windows):

            win_genos = genotypes_data.ix[:, markers_in_win]
            win_genos = MatrixWithMeta(win_genos, metadata=genotypes_meta)
            yield (mol, win[0], win[1]), win_genos
