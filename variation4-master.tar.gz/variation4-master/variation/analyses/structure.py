'''
Created on 22/03/2012

@author: jose
'''

from tempfile import NamedTemporaryFile
import os
from operator import itemgetter
from collections import Counter

from pandas import DataFrame, Series

from variation.matrixwithmeta import (INDIVIDUALS_IN_ROWS, PLOIDY,
                                      BITS_PER_ALLELE, ALLELE_CODING,
                                      CLASSIFICATION_COL, LINKAGE_GROUP_COL,
                                      GENETIC_LOCATION_COL, MOLECULE_COL,
                                      LOCATION_COL, MatrixWithMeta, FLOAT)
from variation.inout.genetic import GenotypeCodec
from variation.analyses.matrix_tools import (vector_is_subset_of_others,
                                             sorted_dframe_by_rows)
from variation.analyses.classification import select_most_probable_class
from variation.utils import (get_binary_path, check_finished_process,
                             TemporaryDir, run_wrapped_cmd)


ONEROW = 1
MISSINGVAL = -9
SEP = ' '
DEFAULT_PLOIDY = 2


class StructureCodec(GenotypeCodec):
    'It returns the int coded genotypes'
    def decode_to_structure(self, genotype):
        'It returns the structure coded genotype for one individual'
        genotype = self.decode_to_ints(genotype)
        if genotype is None:
            return [MISSINGVAL] * self.ploidy
        else:
            return genotype


def _sort_markers_genetic_or_physical(markers):
    '''It sorts the markers by genetic distance or physical if genetic is not
    found.'''
    meta = markers.meta
    if markers.is_genetic_marker_map():
        sort_columns = meta[LINKAGE_GROUP_COL], meta[GENETIC_LOCATION_COL]
    elif markers.is_physical_marker_map():
        sort_columns = meta[MOLECULE_COL], meta[LOCATION_COL]
    else:
        msg = 'The given matrix is not a marker map'
        raise ValueError(msg)
    dframe = markers.data.sort_index(by=sort_columns)
    return MatrixWithMeta(dframe, meta)


def _check_data_consistency(genotypes, markers_map, individuals, marker_names):
    'It checks that the marker and individual information is consistent'
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        indi_names = genotypes.data.index
    else:
        indi_names = genotypes.data.columns
    if individuals is not None:
        if CLASSIFICATION_COL not in individuals.meta:
            msg = 'individuals given, but no classification column in metadata'
            raise ValueError(msg)
        indis_in_individuals = individuals.data.index
        if not vector_is_subset_of_others(indi_names, [indis_in_individuals]):
            msg = 'Some individuals in the genotypes are not found in the '
            msg += 'individuals matrix, e.g.: '
            missing = set(indi_names).difference(set(indis_in_individuals))
            missing = ', '.join(missing[:3])
            msg += missing
            raise ValueError(msg)
    if markers_map is not None:
        markers_in_markers = markers_map.data.index
        if not vector_is_subset_of_others(marker_names, [markers_in_markers]):
            msg = 'Some markers in the genotypes are not found in the markers '
            msg += 'map matrix, e.g.: '
            missing = set(marker_names).difference(set(markers_in_markers))
            missing = ', '.join(missing[:3])
            msg += missing
            raise ValueError(msg)


def _sort_markers_by_location(markers_map):
    'It sorts the markers by genetic or physical location'
    if markers_map is not None:
        mmeta = markers_map.meta
        if markers_map.is_genetic_marker_map():
            marker_mol_col = mmeta[LINKAGE_GROUP_COL]
            marker_loc_col = mmeta[GENETIC_LOCATION_COL]
            physical = False
        elif markers_map.is_physical_marker_map():
            marker_mol_col = mmeta[MOLECULE_COL]
            marker_loc_col = mmeta[LOCATION_COL]
            physical = True
        else:
            msg = 'markers map matrix does not include a genetic or a physical'
            msg += ' map'
            raise ValueError(msg)
        return (_sort_markers_genetic_or_physical(markers_map), marker_mol_col,
                marker_loc_col, physical)
    else:
        marker_mol_col, marker_loc_col, physical = None, None, None
        return (markers_map, marker_mol_col, marker_loc_col, physical)


def _calculate_marker_distance_line(markers_map, marker_names, marker_mol_col,
                                    marker_loc_col, physical):
    'It returns the items for the marker distance line'
    previous_loc = None
    distances = []
    markersdf = markers_map.data
    for name in marker_names:
        marker_mol = markersdf.get_value(name, marker_mol_col)
        marker_loc = markersdf.get_value(name, marker_loc_col)
        loc = marker_mol, marker_loc
        if previous_loc is None or previous_loc[0] != loc[0]:
            distance = -1
        else:
            distance = loc[1] - previous_loc[1]
        if physical:
            distance = int(distance)
        distances.append(distance)
        previous_loc = loc
    distances = [str(dist) for dist in distances]
    return distances


def _get_pop_names(classification, individuals):
    'It builds a list of populations as they appear in a classification series'
    populations = []
    for indi in individuals:
        pop = classification[indi]
        if pop not in populations:
            populations.append(pop)
    return populations


def create_genotype_file(genotypes, fhand=None, markers_map=None,
                         individuals=None, params=None):
    'It creates a Structure input file'
    if params is None:
        params = {}
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        marker_names = genotypes.data.columns
        nindis = len(genotypes.data.index)
    else:
        marker_names = genotypes.data.index
        nindis = len(genotypes.data.columns)
    params['NUMINDS'] = nindis
    _check_data_consistency(genotypes, markers_map, individuals, marker_names)

    if fhand is None:
        fhand = NamedTemporaryFile(prefix='struct.', suffix='.geno')

    params['INFILE'] = fhand.name

    #if there is marker location info we have to sort the markers
    (markers_map, marker_mol_col,
     marker_loc_col, physical) = _sort_markers_by_location(markers_map)
    if markers_map:
        # which of these markers are used in the genotyping?
        marker_names = [m for m in markers_map.data.index if m in marker_names]

    str_marker_names = [str(m) for m in marker_names]

    fhand.write(SEP.join(str_marker_names) + '\n')
    params['MARKERNAMES'] = 1
    params['LABEL'] = 1

    if genotypes.is_binary():
        # Dominant alleles
        codominant = False
        params['RECESSIVEALLELES'] = 1
        fhand.write(SEP.join(['0'] * len(marker_names)) + '\n')
    else:
        codominant = True
        params['RECESSIVEALLELES'] = 0

    #distances
    if markers_map is None:
        params['MAPDISTANCES'] = 0
        params['LINKAGE'] = 0
    else:
        params['MAPDISTANCES'] = 1
        params['LINKAGE'] = 1
        distances = _calculate_marker_distance_line(markers_map, marker_names,
                                                    marker_mol_col,
                                                    marker_loc_col, physical)
        distances = [str(dist) for dist in distances]
        fhand.write(SEP.join(distances) + '\n')

    if ONEROW == 1:
        params['ONEROWPERIND'] = ONEROW
    else:
        raise NotImplementedError('We only know how to write in one row')

    if individuals is None:
        params['POPDATA'] = 0
        extracols = 0
    else:
        params['POPDATA'] = 1
        extracols = 1
    params['POPFLAG'] = 0
    params['LOCDATA'] = 0
    params['PHENOTYPE'] = 0
    params['EXTRACOLS'] = extracols

    meta = genotypes.meta
    if codominant:
        codec = StructureCodec(ploidy=meta[PLOIDY],
                               bits_per_allele=meta[BITS_PER_ALLELE],
                               alleles_coding=meta[ALLELE_CODING])

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        genotypes_for_indi = genotypes.data.iterrows()
        indi_names = genotypes.data.index
    else:
        genotypes_for_indi = genotypes.data.iteritems()
        indi_names = genotypes.data.columns
    if individuals is not None:
        indi_meta = individuals.meta
        individuals = individuals.data
    if params['POPDATA']:
        pops = individuals[indi_meta[CLASSIFICATION_COL]]
        populations = _get_pop_names(pops, indi_names)
    else:
        populations = None
    for indi_name, genotype in genotypes_for_indi:
        items = []
        items.append(indi_name)
        if params['POPDATA']:
            pop = individuals.get_value(indi_name,
                                        indi_meta[CLASSIFICATION_COL])
            pop_int = str(populations.index(pop))
            items.append(pop_int)
            # the extra column with the population string. It won't be read
            # by structure itself, but it is use to assign string to the
            # population numbers in the output
            pop_str = pop.replace(SEP, '_')
            items.append(pop_str)
        if markers_map is not None:
            genotype = genotype[marker_names]
        if codominant:
            genotype = [codec.decode_to_structure(g) for g in genotype]
        else:
            genotype = [(allele, allele) for allele in genotype]
        items.extend(str(item) for sublist in genotype for item in sublist)
        fhand.write(SEP.join(items) + '\n')
    fhand.flush()
    params['NUMLOCI'] = len(marker_names)
    return fhand, params


def _get_default_mainparams():
    'It returns a dict with the default main parameters.'
    default_params = {'BURNIN': 20000, 'NUMREPS': 100000,
                      'PLOIDY': DEFAULT_PLOIDY, 'MISSING': MISSINGVAL,
                      'NOADMIX': 0, 'USEPOPINFO': 0, 'LOCPRIOR': 0,
                      'LOCISPOP': 0, 'FREQSCORR': 0, 'ONEFST': 0,
                      'POPALPHAS': 0, 'INFERLAMBDA': 0, 'LAMBDA': 1,
                      'GENSBACK': 2, 'COMPUTEPROB': 1, 'INFERALPHA': 1,
                      'LOG10RMIN': 0, 'LOG10RMAX': 0, 'LOG10RSTART': 0,
                      'LOG10RPROPSD': 0}
    return default_params


def _get_default_extraparams():
    'It returns a dict with the default extra parameters.'
    return {}


def get_default_params():
    'It returns two dicts with the main and extra parameters.'
    return _get_default_mainparams(), _get_default_extraparams()


def _create_param_file(params, suffix, fhand=None):
    'It creates the a parameters file'
    if fhand is None:
        fhand = NamedTemporaryFile(suffix=suffix)
    for param, value in params.items():
        fhand.write('#define {:s} {:s}\n'.format(param.upper(), str(value)))
    fhand.flush()
    return fhand


def create_param_files(mainparams, extraparams,
                       mainparams_fhand=None, extraparams_fhand=None):
    'It creates the main and extra parameter files'

    mainparams_fhand = _create_param_file(mainparams, suffix='.mainparams',
                                          fhand=mainparams_fhand)
    if extraparams is not None:
        extraparams_fhand = _create_param_file(extraparams,
                                               suffix='.extraparams',
                                               fhand=extraparams_fhand)
    else:
        extraparams_fhand = None
    return mainparams_fhand, extraparams_fhand


def launch_structure(k, genotype_fhand, mainparams_fhand, extraparams_fhand,
                     output_fpath, work_dir):
    'It launches a structure analysis, but it does not wait till it finishes.'
    if not output_fpath.endswith('_f'):
        msg = 'The output fpath should finish with _f'
        raise ValueError(msg)
    cmd = [get_binary_path('structure')]
    cmd.extend(['-m', mainparams_fhand.name])
    cmd.extend(['-e', extraparams_fhand.name])
    cmd.extend(['-K', str(k)])
    cmd.extend(['-i', genotype_fhand.name])
    # structure adds an _f to the output fname
    cmd.extend(['-o', output_fpath[:-2]])
    process, stdout, stderr = run_wrapped_cmd(cmd, work_dir.name)
    return process, stdout, stderr


def do_structure(k, genotype_fhand, mainparams_fhand, extraparams_fhand,
                 output_fhand=None):
    'It launches a structure analysis and waits till it finishes.'
    working_dir = TemporaryDir(prefix='working_structure_')
    output_fhand = NamedTemporaryFile(suffix='_f')
    try:
        output = launch_structure(k=k, genotype_fhand=genotype_fhand,
                                  mainparams_fhand=mainparams_fhand,
                                  extraparams_fhand=extraparams_fhand,
                                  output_fpath=output_fhand.name,
                                  work_dir=working_dir)
        process, stdout, stderr = output
        process.wait()
        check_finished_process(process, binary='structure', stdout=stdout,
                               stderr=stderr)
    except Exception:
        raise
    finally:
        working_dir.close()
    if output_fhand is None:
        suffix = '.struct.k_' + str(k) + '.out'
        output_fhand = NamedTemporaryFile(suffix=suffix)
    return output_fhand


def launch_structure_for_ks(min_k, max_k, genotype_fhand, mainparams_fhand,
                            extraparams_fhand, working_directory,
                            in_parallel=False, out_directory=None,
                            output_prefix='', set_outputs_to_delete=True):
    '''It launches structure for a range of k values, it won't wait till they
    finish.

    It will create one output file for every k.
    '''
    processes = []
    out_fhands = []
    stdouts = []
    stderrs = []
    length_max_figure = len(str(max_k))
    suffix_format = '.struct.k_{:' + str(length_max_figure) + '}.out_f'
    for k in range(min_k, max_k + 1):
        output_fhand = NamedTemporaryFile(suffix=suffix_format.format(k),
                                          dir=out_directory,
                                          delete=set_outputs_to_delete)
        output = launch_structure(k=k, genotype_fhand=genotype_fhand,
                                  mainparams_fhand=mainparams_fhand,
                                  extraparams_fhand=extraparams_fhand,
                                  output_fpath=output_fhand.name,
                                  work_dir=working_directory)
        process, stdout, stderr = output
        if not in_parallel:
            process.wait()
            check_finished_process(process, binary='structure',
                                   stdout=stdout, stderr=stderr)
        processes.append(process)
        out_fhands.append(output_fhand)
        stdouts.append(stdout)
        stderrs.append(stderr)
    return processes, out_fhands, stdouts, stderrs


def do_structure_for_ks(min_k, max_k, genotype_fhand,
                        directory, mainparams_fhand, extraparams_fhand,
                        in_parallel=False, output_prefix=''):
    'It runs structure for a range of k values'
    working_dir = TemporaryDir(prefix='working_structure_')
    try:
        output = launch_structure_for_ks(min_k=min_k, max_k=max_k,
                                        genotype_fhand=genotype_fhand,
                                        mainparams_fhand=mainparams_fhand,
                                        extraparams_fhand=extraparams_fhand,
                                        working_directory=working_dir,
                                        in_parallel=in_parallel,
                                        out_directory=directory,
                                        output_prefix=output_prefix,
                                        set_outputs_to_delete=False)
        processes, out_fhands, stdouts, stderrs = output

        for index in range(len(processes)):
            check_finished_process(processes[index], binary='structure',
                                   stdout=stdouts[index],
                                   stderr=stderrs[index])
    except Exception:
        raise
    finally:
        working_dir.close()
    return out_fhands


def _read_structure_result_head(result_fhand):
    'It reads the ln_prob, the individual and the population classifications'
    # pylint: disable=W0141
    section = None
    indi_names = []
    indi_classification = []
    pop_classification = []
    with_prior_pops = None
    for line in result_fhand:
        if 'Inferred Clusters' in line:
            if line.startswith('Inferred Clusters'):
                with_prior_pops = False
            else:
                with_prior_pops = True
            section = 'pop_classification'
            continue
        elif line.startswith('Estimated Ln Prob of Data'):
            ln_prob = float(line.split('=')[1].strip())
            section = None
            continue
        elif line.startswith('--------------'):
            section = None
            continue
        elif line.startswith('Inferred ancestry of individuals'):
            section = 'indi_classification'
            continue
        elif line.startswith('Estimated Allele Frequencies'):
            break

        if section == 'pop_classification':
            if line.isspace():
                continue
            if ':' in line:
                pop_class = line.split()[1:-1]
            else:
                pop_class = line.split()
            if pop_class[0] != 'Pop':
                pop_classification.append(map(float, pop_class))
        elif section == 'indi_classification':
            if 'Label (%Miss) ' in line:
                continue
            elif line.isspace():
                section = None
                continue
            items = line.split()
            indi_names.append(items[1])
            indi_class = items[items.index(':') + 1:]
            indi_classification.append(map(float, indi_class))
    if with_prior_pops is None:
        # an empty or malformed file
        msg = 'The structure result file is empty or malformed'
        if hasattr(result_fhand, 'name'):
            msg += ': ' + result_fhand.name
        raise ValueError(msg)
    elif not with_prior_pops:
        pop_classification.pop(0)
    return {'ln_prob': ln_prob,
            'population_classification': pop_classification,
            'individual_names': indi_names,
            'individual_classification': indi_classification}


def _read_names_from_geno_fhand(genotype_fhand, params):
    'It reads the integer -> population names mapping from the first extracol.'
    if genotype_fhand is None:
        return None, None
    if params is None:
        msg = 'Cannot read the genotype file without the parameters'
        raise ValueError(msg)

    num_loci = params['NUMLOCI']

    non_geno_cols = 0
    if params['LABEL']:
        non_geno_cols += 1
    if params['POPDATA']:
        non_geno_cols += 1
    if params['POPFLAG']:
        non_geno_cols += 1
    if params['LOCDATA']:
        non_geno_cols += 1
    if params['PHENOTYPE']:
        non_geno_cols += 1
    if params['EXTRACOLS']:
        non_geno_cols += 1

    if params['LABEL']:
        indi_name_column = 0
        int_pop_column = 1
    else:
        indi_name_column = None
        int_pop_column = 0
    if params['EXTRACOLS'] >= 1:
        str_pop_column = non_geno_cols - params['EXTRACOLS']
    else:
        str_pop_column = None

    prior_pops = {}
    indi_names = []
    for line in genotype_fhand:
        items = line.split()
        if not(len(items) == num_loci + non_geno_cols or
               len(items) == num_loci * 2 + non_geno_cols):
            # we have to ignore the header lines
            continue
        if str_pop_column is not None:
            int_pop = int(items[int_pop_column])
            str_pop = items[str_pop_column]
            prior_pops[int_pop] = str_pop
        if indi_name_column is not None:
            indi_names.append(items[indi_name_column])
    prior_pops = [prior_pops[i] for i in range(len(prior_pops))]
    return indi_names, prior_pops


def _cast_to_num_or_str(string):
    'Given a string it returns an int, float or string'
    no_sing = string[1:] if string.startswith('-') else string
    if no_sing.isdigit():
        return int(string)
    no_dot = no_sing.replace('.', '', 1)
    if no_dot.isdigit():
        return float(string)
    return string


def _read_structure_result_params(result_fhand):
    'It reads the params from the end of the file'
    section = None
    for line in result_fhand:
        if line.startswith('Values of parameters used in structure'):
            section = 'params'
            continue
        if section is None:
            continue
        if line.startswith('[STRAT parameters]:'):
            line = line[19:]
        params = {}
        for item in line.split('\t'):
            if not item or item.isspace():
                continue
            key, val = item.strip().split('=')
            if key not in ('DATAFILE', 'OUTFILE'):
                val = _cast_to_num_or_str(val.rstrip(','))
            params[key] = val
        return params


def read_structure_result(result_fhand, genotype_fhand=None, params=None):
    '''It reads a structure result file.

    The genotype input file is used for two things:
    1) To infer the population string identifiers. In the structure output only
       the integers representing the populations are found. If the population
       strings are located in the first extra column this function will be able
        to read them.
    2) If for the individuals names with more than 11 characters are used, they
    will be right trimmed in the output file. If the genotype_fhand is given
    the name of the individuals will be taken from it.
    The parameters are not usually necessary because they will be read from
    the result file.
    '''

    result = _read_structure_result_head(result_fhand)

    read_params = _read_structure_result_params(result_fhand)
    params_for_infile = params if params is not None else read_params
    if genotype_fhand is not None:
        genotype_fhand.seek(0)
    indi_names, population_names = _read_names_from_geno_fhand(genotype_fhand,
                                                             params_for_infile)
    if indi_names:
        # check that names from input genotype fhand and from output fhand
        # match in the first 11 characters
        for out_name, in_name in zip(result['individual_names'], indi_names):
            if out_name[:12] != in_name[:12]:
                msg = 'Input genotype file does not match with output result '
                msg += 'file at least one individual name is different between'
                msg += ' them: ' + in_name + ' vs ' + out_name
        # We use the names of the input file because they are not truncated to
        # 11 characters
        result['individual_names'] = indi_names

    # check that there are no repeated individual names. It could happen
    # because structure truncates the names of the individuals to 11 characters
    if len(set(result['individual_names'])) != len(result['individual_names']):
        msg = 'Some individual names in the output file are not unique.\n'
        msg += 'Structure truncates the names to 11 characters, that might be'
        msg += 'the case.\n In that case it could be fixed providing the input'
        msg += 'genotype file to this function.\nThe repeated name was: '
        counts = Counter(result['individual_names'])
        repeated = [name for name, count in counts.viewitems() if count > 1]
        msg += ', '.join(repeated)
        raise RuntimeError(msg)

    # now we build the dataframes for the standard result
    n_pop = len(result['population_classification'][0])
    len_max_figure = len(str(n_pop))
    pop_name_fmt = 'ances_pop_{:' + str(len_max_figure) + '}'
    ancestral_pop_names = [pop_name_fmt.format(i) for i in range(1, n_pop + 1)]

    indi_class = DataFrame(result['individual_classification'],
                           index=result['individual_names'][:],
                           columns=ancestral_pop_names)
    indi_class = MatrixWithMeta(indi_class)
    indi_class.kind = FLOAT
    result['individual_classification'] = indi_class
    del result['individual_names']

    index = None if not population_names else population_names
    pop_class = DataFrame(result['population_classification'],
                          index=index,
                          columns=ancestral_pop_names)
    pop_class = MatrixWithMeta(pop_class)
    pop_class.kind = FLOAT
    result['population_classification'] = pop_class
    result['parameters_used'] = read_params
    return result


def read_structure_results(directory, genotype_fhand=None):
    '''It reads all structure results found in the directory.

    It searches for the result files with the suffix format created by the
    do_structure_for_ks function.
    '''
    fpaths = os.listdir(directory)
    fpaths = [f for f in fpaths if '.struct.k_' in f and f.endswith('.out_f')]
    fpaths = [os.path.join(directory, f) for f in fpaths]
    if not fpaths:
        return {}
    k_results = []
    for out_fpath in fpaths:
        if genotype_fhand:
            genotype_fhand.seek(0)
        result = read_structure_result(open(out_fpath),
                                       genotype_fhand=genotype_fhand)
        num_ances_pops = result['parameters_used']['MAXPOPS']
        k_results.append((num_ances_pops, result))
    k_results.sort(key=itemgetter(0))

    results = {'individual_classifications': [],
               'population_classifications': [],
               'parameters_used': [],
               'ln_probs': [],
               'ks': []}
    for num_ances_pops, result in k_results:
        results['ks'].append(num_ances_pops)
        results['individual_classifications'].append(
                                           result['individual_classification'])
        results['population_classifications'].append(
                                           result['population_classification'])
        results['parameters_used'].append(result['parameters_used'])
        results['ln_probs'].append(result['ln_prob'])
    return results


def sort_rows_by_similarity(matrix):
    'It clusters the similar rows together of the dframe in the MatrixWithMeta'
    # would it better to use a clustering?

    dframe = matrix.data

    # Which are the most important columns in each row?
    prominent_cols = select_most_probable_class(dframe)
    cols = dframe.columns
    # pylint: disable=C0301
    prominent_col_values = Series([dframe.get_value(i, cols[prominent_cols[i]]) for i in dframe.index],
                                  dframe.index)

    # sort by value of the most important column
    max_value = lambda row: prominent_col_values[row.name]
    dframe = sorted_dframe_by_rows(dframe, key=max_value, reverse=True)

    # sort by major ancestry
    max_ancestry = lambda row: prominent_cols[row.name]
    dframe = sorted_dframe_by_rows(dframe, key=max_ancestry)

    return MatrixWithMeta(dframe, matrix.meta)


def sort_individual_classification(indi_classification, individuals,
                                   sorted_pops):
    'It sorts the individual classification'

    # a possible way of getting the sorted_pops is
    #    pop_classification = _sort_rows_by_similarity(pop_classification)
    #    sorted_pops = list(pop_classification.data.index)
    pop_col = individuals.meta[CLASSIFICATION_COL]
    individuals = individuals.data

    def _prior_pop_index(indi_class_row):
        'It returns the index of the prior population in the sorted_pops'
        indi_name = indi_class_row.name
        pop_name = individuals.get_value(indi_name, pop_col)
        return sorted_pops.index(pop_name)

    indi_classification = sort_rows_by_similarity(indi_classification)

    if individuals is not None:
        dframe = sorted_dframe_by_rows(indi_classification.data,
                                       key=_prior_pop_index)
        indi_classification = MatrixWithMeta(dframe, indi_classification.meta)
    return indi_classification
