# This module defines several estimators of linkage disequilibrium
# statistics D and r.  All estimators work with data that lack gametic
# phase.  Each estimator requires two vectors, Y and Z, as input.  The
# i'th entry in Y is 2, 1, or 0, for genotypes AA, Aa, and aa, at the
# first locus.  The entries of Z are defined similarly for genotypes of
# the second locus.
#
# The Rogers-Huff method is described in:
#
# Rogers, Alan R.  and Huff, Chad. 2008. Linkage Disequilibrium in
# Loci with Unknown Phase.
#
# I hereby place this computer program into the public domain.  Alan
# R. Rogers

from math import sqrt
import traceback
from collections import defaultdict

from pandas import DataFrame

from variation.matrixwithmeta import (MOLECULE_COL, LOCATION_COL,
                                      INDIVIDUALS_IN_ROWS)
from variation.inout.genetic import get_codec_from_genotypes

# tol controls convergence.
tol = 1e-7


def bivmom(vec0, vec1):
    ''' Calculate means, variances, the covariance, from two data vectors.
    On entry, vec0 and vec1 should be vectors of numeric values and
    should have the same length.  Function returns m0, v0, m1, v1,
    cov, where m0 and m1 are the means of vec0 and vec1, v0 and v1 are
    the variances, and cov is the covariance.
    '''
    m0 = m1 = v0 = v1 = cov = 0
    for x, y in zip(vec0, vec1):
        m0 += x
        m1 += y
        v0 += x * x
        v1 += y * y
        cov += x * y
    n = len(vec0)
    assert n == len(vec1)
    n = float(n)
    m0 /= n
    m1 /= n
    v0 /= n
    v1 /= n
    cov /= n

    cov -= m0 * m1
    v0 -= m0 * m0
    v1 -= m1 * m1
    return m0, v0, m1, v1, cov


def get_covD(Y, Z):
    '''get_covD estimates pA, pB, and D w/o info on gametic phase.
    Uses the method of Rogers and Huff 2008.
    '''
    pA, v0, pB, v1, cov = bivmom(Y, Z)
    pA = 0.5 * pA
    pB = 0.5 * pB
    qA = 1 - pA
    qB = 1 - pB
    two_1pf = sqrt((v0 * v1) / (pA * qA * pB * qB))  # estimates 2( 1 + f)
    D = cov / two_1pf
    return pA, pB, D


def get_r(Y, Z):
    '''Estimates r w/o info on gametic phase.  Also works with gametic
    data, in which case Y and Z should be vectors of 0/1 indicator
    variables.
    Uses the method of Rogers and Huff 2008.
    '''
    mY, vY, mZ, vZ, cov = bivmom(Y, Z)
    return cov / sqrt(vY * vZ)


def get_r_corr_genotype(Y, Z):
    print "Enter get_r_corr_genotype"
    count = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

    print "A"
    print "type(Y):", type(Y)
    print "len(Y):", len(Y)

    for i in range(len(Y)):
        print i
        print Y[i]
        print Z[i]
        count[Y[i]][Z[i]] += 1

    print "B",

    sumx = sumy = sumxx = sumyy = sumxy = 0
    for i in range(3):
        for j in range(3):
            sumx += count[i][j] * i
            sumy += count[i][j] * j
            sumxx += count[i][j] * i * i
            sumyy += count[i][j] * j * j
            sumxy += count[i][j] * i * j

    print "sumx=%d sumy=%d sumxx=%d sumyy=%d sumxy=%d" \
        % (sumx, sumy, sumxx, sumyy, sumxy)
    # Calculate numerators in integer arithmetic to
    # avoid roundoff.
    lenght = len(Y)
    nsqr = float(lenght * (lenght - 1))
    cov = (lenght * sumxy - sumx * sumy) / nsqr
    vx = (lenght * sumxx - sumx * sumx) / nsqr
    vy = (lenght * sumyy - sumy * sumy) / nsqr
    r = cov / sqrt(vx * vy)
    print "get_r_corr_genotype returning:", r
    return r


# Excoffier-Slatkin EM algorithm for estimating haplotype frequencies.
# This code implements the special case of the algorithm for two
# biallelic loci.  With two biallelic loci, there are 4 types of
# gamete, which I represent as follows:
#
#    AB  Ab  aB  ab
#     0   1   2   3
#
# Here A and a are the two alleles at the first locus and B and
# b are the alleles at the other locus.  The numbers below the
# gamete symbols are used below as indexes into arrays.
#
# Phenotypes at the 1st locus: AA, Aa, and aa are numbered 0, 1, and 2.
#
# Phenotypes at the 2nd locus: BB, Bb, and bb are numbered 0, 1, and 2.
#
# Input:
#
# h is a vector of 4 haplotype frequencies, indexed as shown above.
#
# x is a 3X3 matrix of phenotype counts.  The phenotypes are coded
# as explained above.  Thus, x[1][2] is the number of copies of
# the phenotype Aa/BB.
#
# n is the sample size and should equal the sum of x.
#
# Function returns a revised estimate of h after a single EM step.
def esem_step(h, x):

    # g is a 4X4 matrix of genotype frequencies. g[0][3]
    # is the frequency of the genotype that combines gamete 0 (AB)
    # with gamete 3 (ab).
    g = [[None, None, None, None], [None, None, None, None],
         [None, None, None, None], [None, None, None, None]]
    for i in range(4):
        g[i][i] = h[i] * h[i]
        for j in range(i):
            g[i][j] = 2 * h[i] * h[j]

    # p is a 3X3 matrix of phenotype frequencies, recoded as
    # described for the input matrix x.
    p = [[None, None, None], [None, None, None], [None, None, None]]

    p[0][0] = g[0][0]
    p[0][1] = g[1][0]
    p[0][2] = g[1][1]

    p[1][0] = g[2][0]
    p[1][1] = g[3][0] + g[2][1]
    p[1][2] = g[3][1]

    p[2][0] = g[2][2]
    p[2][1] = g[3][2]
    p[2][2] = g[3][3]

    hh = [None, None, None, None]
    hh[0] = 2 * x[0][0] + x[0][1] + x[1][0] + x[1][1] * g[3][0] / p[1][1]
    hh[1] = x[0][1] + 2 * x[0][2] + x[1][1] * g[2][1] / p[1][1] + x[1][2]
    hh[2] = x[1][0] + x[1][1] * g[2][1] / p[1][1] + 2 * x[2][0] + x[2][1]
    hh[3] = x[1][1] * g[3][0] / p[1][1] + x[1][2] + x[2][1] + 2 * x[2][2]

    # haploid sample size
    n = float(sum(hh))

    # convert gamete counts counts to relative frequencies
    for i in range(4):
        hh[i] /= n

    return hh


# This is exactly like esem_step.  It's here so that I can count
# calls.
def rhesem_step(h, x):

    # g is a 4X4 matrix of genotype frequencies. g[0][3]
    # is the frequency of the genotype that combines gamete 0 (AB)
    # with gamete 3 (ab).
    g = [[None, None, None, None], [None, None, None, None],
         [None, None, None, None], [None, None, None, None]]
    for i in range(4):
        g[i][i] = h[i] * h[i]
        for j in range(i):
            g[i][j] = 2 * h[i] * h[j]

    # p is a 3X3 matrix of phenotype frequencies, recoded as
    # described for the input matrix x.
    p = [[None, None, None], [None, None, None], [None, None, None]]

    p[0][0] = g[0][0]
    p[0][1] = g[1][0]
    p[0][2] = g[1][1]

    p[1][0] = g[2][0]
    p[1][1] = g[3][0] + g[2][1]
    p[1][2] = g[3][1]

    p[2][0] = g[2][2]
    p[2][1] = g[3][2]
    p[2][2] = g[3][3]

    hh = [None, None, None, None]
    hh[0] = 2 * x[0][0] + x[0][1] + x[1][0] + x[1][1] * g[3][0] / p[1][1]
    hh[1] = x[0][1] + 2 * x[0][2] + x[1][1] * g[2][1] / p[1][1] + x[1][2]
    hh[2] = x[1][0] + x[1][1] * g[2][1] / p[1][1] + 2 * x[2][0] + x[2][1]
    hh[3] = x[1][1] * g[3][0] / p[1][1] + x[1][2] + x[2][1] + 2 * x[2][2]

    # haploid sample size
    n = float(sum(hh))

    # convert gamete counts counts to relative frequencies
    for i in range(4):
        hh[i] /= n

    return hh


# Excoffier-Slatkin EM algorithm for estimating haplotype frequencies.
# Input:
#
# Y is vector of genotype values at 1st locus, coded as 0, 1, and 2
# to represent genotypes aa, aA, and AA.
#
# Z is the corresponding vector for 2nd locus.
#
# h is the initial vector of haplotype frequencies
#
# Function returns h, a vector of 4 haplotype frequencies.
def esem(Y, Z, h=[0.25, 0.25, 0.25, 0.25], max_itr=1000):
    global tol
    x = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    for y, z in zip(Y, Z):
        x[y][z] += 1
    for itr in xrange(max_itr):
        hh = esem_step(h, x)
        dh = 0.0
        for u, v in zip(h, hh):
            dh += abs(u - v)
        if dh <= tol:
            break
        h = hh
    if dh > tol:
        raise ConvergenceError
    return hh


# Exactly like esem.  Here to count calls
def rhesem(Y, Z, h=[0.25, 0.25, 0.25, 0.25], max_itr=1000):
    global tol
    x = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    for y, z in zip(Y, Z):
        x[y][z] += 1
    for itr in xrange(max_itr):
        hh = rhesem_step(h, x)
        dh = 0.0
        for u, v in zip(h, hh):
            dh += abs(u - v)
        if dh <= tol:
            break
        h = hh
    if dh > tol:
        raise ConvergenceError
    return hh


# Use Rogers-Huff method to obtain initial values for the
# Excoffier-Slatkin algorithm.  Return r.
#
# Input:
#
# Y is vector of genotype values at 1st locus, coded as 0, 1, and 2
# to represent genotypes aa, aA, and AA.
#
# Z is the corresponding vector for 2nd locus.
def rhesem_r(Y, Z, max_itr=1000):
    global tol
    # RH step
    pA, pB, D = get_covD(Y, Z)
    qA = 1.0 - pA
    qB = 1.0 - pB
    h = [pA * pB + D, pA * qB - D, qA * pB - D, qA * qB + D]

    # ES step
    h = rhesem(Y, Z, h, max_itr)
    pA = h[0] + h[1]
    pB = h[0] + h[2]
    qA = 1.0 - pA
    qB = 1.0 - pB
    r = h[0] * h[3] - h[1] * h[2]
    r /= sqrt(pA * qA * pB * qB)
    return r


# Use Excoffier-Slatkin EM algorithm to estimate r.
# Input:
#
# Y is vector of genotype values at 1st locus, coded as 0, 1, and 2
# to represent genotypes aa, aA, and AA.
#
# Z is the corresponding vector for 2nd locus.
#
# h is the initial vector of haplotype frequencies
#
# Function returns r.
def esem_r(Y, Z, h=[0.25, 0.25, 0.25, 0.25], max_itr=1000):
    global tol
    h = esem(Y, Z, h, max_itr)
    pA = h[0] + h[1]
    pB = h[0] + h[2]
    qA = 1.0 - pA
    qB = 1.0 - pB
    r = h[0] * h[3] - h[1] * h[2]
    r /= sqrt(pA * qA * pB * qB)
    return r


# Algorithm of Hill 1974
def HillD(Y, Z, initD=None):
    global tol
    max_itr = 1000
    sampsize = len(Y)
    assert(sampsize > 0)
    n00 = n01 = n02 = 0.0
    n10 = n11 = n12 = 0.0
    n20 = n21 = n22 = 0.0
    pA = pB = 0.0
    for i in xrange(sampsize):
        pA += Y[i]
        pB += Z[i]
        score = 10 * Y[i] + Z[i]
        if score == 00:
            n00 += 1
        elif score == 01:
            n01 += 1
        elif score == 10:
            n10 += 1
        elif score == 11:
            n11 += 1
        else:
            pass
    pA /= 2.0 * sampsize
    pB /= 2.0 * sampsize

    if initD:
        x = pA * pB + initD
    else:
        x = (2.0 * n00 + n01 + n10) / (2.0 * (sampsize - n11))
    itr = 0
    while 1:
        y = n11 * x * (1.0 - pA - pB - x)
        y /= x * (1 - pA - pB - x) + (pA - x) * (pB - x)
        y += 2 * n00 + n01 + n10
        y /= 2 * sampsize
        if abs(x - y) <= tol  or itr > 1000:
            break
        x = y
        itr += 1
    if itr >= max_itr:
        raise ConvergenceError
    D = x - pA * pB
    return pA, pB, D


def Hill_r(Y, Z):
    pA, pB, D = HillD(Y, Z)
    qA = 1 - pA
    qB = 1 - pB
    return D / sqrt(pA * qA * pB * qB)


class Estimator:
    '''This class defines a generic estimator.  Initialize like this:

    e = Estimator('mylabel', myestimator)

    where 'mylabel' is the name of your estimator and myestimator is
    a function that takes two data vectors returns some value (presumably
    an estimate of something).

    Thereafter, e.lbl returns the label, e.estimate(Y,X,truval) returns the
    estimate of your statistic obtained from data vectors Y and X, and stores
    the err and MSE.  e.bias() returns the mean error, and stderr returns
    the standard error (root mean squared error).
    '''

    def __init__(self, lbl, estimator):
        self.lbl = lbl
        self.estimator = estimator
        self.clear()
        return

    def clear(self):
        '''Set all numeric values to zero.
        '''
        self.n = 0
        self.sum_err = 0.0
        self.sum_mse = 0.0
        return

    def estimate(self, Y, Z, truval=None):
        """
        Estimate r and record error and squared error.

        On entry: Y and Z are data vectors of genotypic values,
        coded as 0, 1, and 2, where 1 is the heterozygote and 0,2
        are the two homozygotes.  truval is the true value of
        r, obtained in some other way.

        On return: the state of the object has been modified to
        reflect another observation of error and squared error, and the
        estimated value is returned.

        If the estimator raises a ConvergenceError or a
        ZeroDivisionError, the state of the object is unchanged and
        the function returns None.
        """
        try:
            val = self.estimator(Y, Z)
        except (ConvergenceError, ZeroDivisionError):
            # These exceptions mean that the method
            # failed with this data set.  This will
            # show up in self.n
            pass
        except Exception, detail:
            print '-' * 60
            traceback.print_exc()
            print '-' * 60
            exit(1)
        else:
            if truval:
                err = val - truval
                self.sum_err += err
                self.sum_mse += err * err
            self.n += 1
            return val
        return None

    def bias(self):
        if self.n == 0:
            return None
        return self.sum_err / float(self.n)

    def stderr(self):
        if self.n == 0:
            return None
        mse = self.sum_mse / float(self.n)
        return sqrt(mse)


class ConvergenceError(Exception):
    def __init__(self, value=None):
        self.value = value

    def __str(self):
        return repr(self.value)


def _get_reference_allele_per_locus(genotypes, codec):
    reference = {}

    for marker, genotype in genotypes.iteritems():
        genos = list(set(genotype.values))
        genos = [geno for geno in genos if geno]
        if len(genos) == 0:
            reference[marker] = None
        else:
            reference[marker] = codec.decode_to_ints(genos[0])[0]

    return reference


def decode_to_reference(genotypes, codec):
    reference = _get_reference_allele_per_locus(genotypes, codec)

    for marker in genotypes.columns:
        if reference[marker] is None:
            continue
        for ind in genotypes.index:
            geno = genotypes.loc[ind, marker]
            if geno:
                geno = codec.decode_to_ints(geno)
                if geno[0] == geno[1] and geno[0] == reference[marker]:
                    genotypes.loc[ind, marker] = 2
                elif geno[0] == geno[1] and geno[0] != reference[marker]:
                    genotypes.loc[ind, marker] = 0
                elif geno[0] != geno[1] and (geno[0] == reference[marker] or geno[1] == reference[marker]):
                    genotypes.loc[ind, marker] = 1
            else:
                genotypes.loc[ind, marker] = -9

    return genotypes, reference


def _calculate_unphased_LD(decoded_genotypes, reference_alleles,
                           within_chromosome, method, physical_map,
                           markers, group=None):

    if physical_map is not None:
        molecule_col = physical_map.meta[MOLECULE_COL]
        position_col = physical_map.meta[LOCATION_COL]

    LD_results = defaultdict(dict)
    for index_marker1, marker1 in enumerate(markers):
        if reference_alleles[marker1] is None:
            continue
        for marker2 in markers[index_marker1 + 1:]:
            if reference_alleles[marker2] is None:
                continue
            if within_chromosome and physical_map:
                mol_marker1 = physical_map.data.loc[marker1, molecule_col]
                mol_marker2 = physical_map.data.loc[marker2, molecule_col]
                if mol_marker1 != mol_marker2:
                    continue
            genos1 = []
            genos2 = []
            for indv in decoded_genotypes.index:
                geno1 = decoded_genotypes.loc[indv, marker1]
                geno2 = decoded_genotypes.loc[indv, marker2]
                if geno1 != -9 and geno2 != -9:
                    genos1.append(geno1)
                    genos2.append(geno2)

            if len(set(genos1)) == 1 or len(set(genos2)) == 1:
                continue

            if method == 'Excoffier-Slatkin':
                LD = esem_r(genos1, genos2)
            elif method == 'Rogers-Huff':
                try:
                    LD = get_r(genos1, genos2)
                except:
                    print 'Error in Rogers'
                    print genos1
                    print genos2
                    LD = None
            else:
                msg = 'Available methods are \'Excoffier-Slatkin\' or '
                msg += '\'Rogers-Huff\' you choosed ' + method
                raise ValueError(msg)
            comparision = marker1 + '-' + marker2
            linkage_column = 'LD'
            if group:
                linkage_column += '_' + group
            LD_results[comparision][linkage_column] = LD
            LD_results[comparision]['marker1'] = marker1
            LD_results[comparision]['marker2'] = marker2
            if physical_map:
                if mol_marker1 == mol_marker2:
                    pos_marker1 = physical_map.data.loc[marker1, position_col]
                    pos_marker2 = physical_map.data.loc[marker2, position_col]
                    LD_results[comparision]['chromosome'] = mol_marker1
                    LD_results[comparision]['pos_marker_1'] = pos_marker1
                    LD_results[comparision]['pos_marker_2'] = pos_marker2
                    LD_results[comparision]['distance'] = pos_marker2 - pos_marker1
                else:
                    LD_results[comparision]['chromosome'] = None
                    LD_results[comparision]['distance'] = None
                    LD_results[comparision]['pos_marker_1'] = None
                    LD_results[comparision]['pos_marker_2'] = None

    return DataFrame(LD_results).T


def calculate_unphased_LD(genotypes, physical_map=None, classification=None,
                          within_chromosome=True, method='Excoffier-Slatkin'):
    '''Possible methods are Excoffier-Slatkin and Rogers-Huff
    '''

    codec = get_codec_from_genotypes(genotypes)

    if not genotypes.meta[INDIVIDUALS_IN_ROWS]:
        genotypes = genotypes.data.T
    else:
        genotypes = genotypes.data

    markers = genotypes.columns

    decoded_genotypes, reference_alleles = decode_to_reference(genotypes,
                                                               codec)
    if physical_map is not None:
        molecule_col = physical_map.meta[MOLECULE_COL]
        position_col = physical_map.meta[LOCATION_COL]

        #I order the physical map and I get the markers sorted
        ordered_physical_map = physical_map.data.sort(columns=[molecule_col,
                                                               position_col])
        markers = [marker for marker in ordered_physical_map.index if marker in markers]

    if classification is not None:
        pops = classification.groupby(classification.values).groups
    else:
        pops = {None: decoded_genotypes.index}

    LD_results = None
    for pop, accs in pops.viewitems():
        pop_LD_results = _calculate_unphased_LD(decoded_genotypes.ix[accs],
                                        reference_alleles=reference_alleles,
                                        within_chromosome=within_chromosome,
                                        method=method,
                                        physical_map=physical_map,
                                        markers=markers, group=pop)
        if LD_results is None:
            LD_results = pop_LD_results
        else:
            LD_results = LD_results.join(pop_LD_results['LD_' + pop],
                                         how='outer')

    return LD_results
