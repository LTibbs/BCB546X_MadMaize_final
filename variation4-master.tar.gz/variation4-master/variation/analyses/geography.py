
from collections import defaultdict

UNKOWN_CHAR = '-'
QUOTES = '"', "'"


def _latlon_to_deg(value):
    'It returns the latitude or longitude in degrees (float)'
    if isinstance(value, int):
        return float(value)
    elif isinstance(value, float) or value is None:
        return value
    elif isinstance(value, tuple) or isinstance(value, list):
        deg = float(value[0])
        minutes = float(value[1])
        sec = float(value[2])
        return deg + minutes / 60.0 + sec / 3600.0
    # So, it is a string
    value = value.strip()
    for quote in QUOTES:
        value = value.strip(quote)
    if not value or value[:-1] == (len(value) - 1) * UNKOWN_CHAR:
        return None

    def fix_unknown(string):
        'It replaces -- with 30'
        if string.startswith(UNKOWN_CHAR):
            return '30'
        elif string.endswith(UNKOWN_CHAR):
            return string[0] + '5'
        else:
            return string

    value = value.lower()
    if value[-1] in ('n', 's', 'w', 'e'):
        number = value[:-1]
        letter = value[-1]
        rev_digits = list(number)[::-1]
        rev_sec = rev_digits[:2]
        rev_min = rev_digits[2:4]
        rev_deg = rev_digits[4:]
        sec = int(fix_unknown(''.join(rev_sec[::-1])))
        minutes = int(fix_unknown(''.join(rev_min[::-1])))
        deg = int(''.join(rev_deg[::-1]))
        num = deg + minutes / 60.0 + sec / 3600.0
        if letter in ('s', 'w'):
            num = -num
        value = num
    else:
        value = float(value)
    return value


def lat_to_deg(value):
    'It returns a latitude in degrees'
    deg = _latlon_to_deg(value)
    if deg and (deg < -90 or deg > 90):
        msg = 'Invalid latitude: %s -> %.2f' % (value, deg)
        raise ValueError(msg)
    return deg


def lon_to_deg(value):
    'It returns a longitude in degrees'
    deg = _latlon_to_deg(value)
    if deg and (deg < -180 or deg > 180):
        msg = 'Invalid longitude: %s -> %.2f' % (value, deg)
        raise ValueError(msg)
    return deg


class _GridDict(dict):
    def __init__(self, *args, **kwargs):
        super(_GridDict, self).__init__(*args, **kwargs)
        self.lon_max = None
        self.lon_max = None
        self.lat_min = None
        self.lat_min = None
        self.bin_width = None


def split_in_grids(coords_matrix, nbins, lon_col, lat_col, lon_max=None,
                   lon_min=None, lat_max=None, lat_min=None):
    '''It splits the rows in coords dframe in a grid'''
    coords = coords_matrix.data

    # get max and min x and y
    if lon_max is None:
        desc = coords[lon_col].describe()
        x_max = desc['max']
        x_min = desc['min']
    else:
        x_max = lon_max
        x_min = lon_min
    if lat_max is None:
        desc = coords[lat_col].describe()
        y_max = desc['max']
        y_min = desc['min']
    else:
        y_max = lat_max
        y_min = lat_min

    # We add something to the x_max because otherwise the points in the max
    # line would not be in any bin
    rim = (x_max - x_min) * 0.005
    x_min -= rim
    x_max += rim
    y_min -= rim

    # Now the grid width
    gwidth = (x_max - x_min) / nbins

    # Which grid correspond to each row
    bins = defaultdict(list)
    for row in coords.index:
        x = coords.loc[row, lon_col]
        y = coords.loc[row, lat_col]
        x_bin_num = int((x - x_min) // gwidth)
        if x_bin_num < 0 or x_bin_num > nbins:
            continue    # outside the boundary
        y_bin_num = int((y - y_min) // gwidth)
        if y_bin_num < 0 or y_bin_num > nbins:
            continue    # outside the boundary
        bins[x_bin_num, y_bin_num].append(row)

    # we have to return the mid point for each bin
    new_bins = _GridDict()
    for bin_num, content in bins.viewitems():
        x = (bin_num[0] + 0.5) * gwidth + x_min
        y = (bin_num[1] + 0.5) * gwidth + y_min
        new_bins[bin_num] = {'mid_point': (x, y), 'row_names': content}
    new_bins.lon_max = x_max
    new_bins.lat_max = y_max
    new_bins.lon_min = x_min
    new_bins.lat_min = y_min
    new_bins.bin_width = gwidth
    return new_bins
