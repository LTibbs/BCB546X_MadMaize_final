import os
from operator import itemgetter
from os.path import join as pjoin
from os.path import exists
from tempfile import NamedTemporaryFile
import json

from pandas import Series, DataFrame, MultiIndex

from variation.matrixwithmeta import (INDIVIDUALS_IN_ROWS, LOCATION_COL,
                                      MOLECULE_COL, PLOIDY, BITS_PER_ALLELE,
                                      ALLELE_CODING, MatrixWithMeta)
from variation.analyses.matrix_tools import transpose_genotypes
from variation.inout.genetic import GenotypeCodec
from variation.utils import (get_binary_path, run_wrapped_cmd,
                             check_finished_process)


def _write_genotype_input_file(fhand, genotypes, physical_map, chromosome):
    '''It writes the individuals haplotypes for one chromosome in
    PHASE and fastPHASE format
    '''
    meta = genotypes.meta
    codec = GenotypeCodec(ploidy=meta[PLOIDY],
                          bits_per_allele=meta[BITS_PER_ALLELE],
                          alleles_coding=meta[ALLELE_CODING],
                          missing_tag='??')

    position_col = physical_map.meta[LOCATION_COL]
    chrom_col = physical_map.meta[MOLECULE_COL]

    if not meta[INDIVIDUALS_IN_ROWS]:
        raise ValueError('Individuals should be in rows')

    snps_in_genotypes = genotypes.data.columns

    map_dframe = physical_map.data

    snp_locations = []
    for snp in snps_in_genotypes:
        try:
            chrom = map_dframe.get_value(snp, chrom_col)
        except KeyError:
            continue
        if chrom != chromosome:
            continue
        snp_loc = map_dframe.get_value(snp, position_col)
        snp_locations.append((snp, snp_loc))

    snp_locations.sort(key=itemgetter(1))

    positions = ['%d' % pos for snp, pos in snp_locations]

    individuals = genotypes.data.index

    num_markers = len(snp_locations)

    fhand.write(str(len(individuals)) + '\n')
    fhand.write(str(num_markers) + '\n')
    fhand.write('P ' + (' ').join(positions) + '\n')
    fhand.write('S' * num_markers + '\n')

    genotypes = genotypes.data
    # we get only the markers that we need and in the correct order
    genotypes = genotypes[[snp_loc[0] for snp_loc in snp_locations]]
    # Not we put the individuals in columns to be more efficient?
    genotypes = genotypes.T

    for individual in individuals:
        fhand.write('#' + str(individual) + '\n')
        indv_genotype = genotypes[individual]
        str_haplotype_a = ''
        str_haplotype_b = ''
        for snp_genotype in indv_genotype:
            str_genotype = codec.decode_to_genotype(snp_genotype)
            str_haplotype_a += str_genotype[0]
            str_haplotype_b += str_genotype[1]
        fhand.write(str_haplotype_a + '\n')
        fhand.write(str_haplotype_b + '\n')
    fhand.flush()
    return [snp[0] for snp in snp_locations]


def _population_input_file(fhand, individual_classification):
    '''It writes the number of individuals in each class in
    PHASE and fastPHASE format
    '''
    pops = {}
    pop_line = []
    for pop in individual_classification:
        if pop not in pops:
            pops[pop] = str(len(pops) + 1)
        pop_line.append(pops[pop])
    fhand.write(' '.join(pop_line))
    fhand.flush()
    return fhand


def create_input_phase_files(genotypes, physical_map, dir_path,
                             individual_classification=None):

    result = {}
    if not genotypes.meta[INDIVIDUALS_IN_ROWS]:
        genotypes = transpose_genotypes(genotypes)

    if individual_classification is not None:

        individuals = list(genotypes.data.index)
        individual_classification = individual_classification.ix[individuals]
        genotypes.data.reindex(individual_classification.index)

        pop_fhand = NamedTemporaryFile(suffix='.subpopulations.phase',
                                       dir=dir_path, delete=False)
        pop_fhand = _population_input_file(pop_fhand,
                                           individual_classification)
        result['population_fhand'] = pop_fhand

    #It checks if physical map has a column for chromosome
    chromosome_col = physical_map.meta.get(MOLECULE_COL, None)
    if chromosome_col is None:
        raise ValueError('The physical map has no chromosome col')
    chromosomes = set(physical_map.data[chromosome_col])

    fhands = []
    chrom_ids = []
    snps = []
    for chromosome in chromosomes:
        chrom_id = 'chrom%d' % chromosome
        fhand = NamedTemporaryFile(prefix='input_phase.' + chrom_id + '.',
                                   suffix='.phase', dir=dir_path, delete=False)
        chrom_snps = _write_genotype_input_file(fhand, genotypes, physical_map,
                                                chromosome)
        snps.append(chrom_snps)
        fhands.append(fhand)
        chrom_ids.append(chrom_id)
    result['genotype_fhands'] = fhands
    result['chrom_ids'] = chrom_ids
    result['chrom_snps'] = snps

    return result


def _parse_hapguess_result(hap_fpath, snp_names, hap_type):
    in_genotypes = False
    fhand = open(hap_fpath)
    haplotypes = []
    multiindex = []
    for line in fhand:
        if line.startswith('BEGIN GENOTYPES'):
            in_genotypes = True
            continue
        if line.startswith('END GENOTYPES'):
            in_genotypes = False
            continue
        if not in_genotypes:
            continue
        indi_line = line
        if hap_type == 'individual':
            try:
                fhand.next()
            except StopIteration:
                msg = 'Malformed haplotype guess result file: ' + fhand.name
                raise RuntimeError(msg)
        try:
            haplo1_line = fhand.next()
        except StopIteration:
            msg = 'Malformed haplotype guess result file: ' + fhand.name
            raise RuntimeError(msg)
        try:
            haplo2_line = fhand.next()
        except StopIteration:
            msg = 'Malformed haplotype guess result file: ' + fhand.name
            raise RuntimeError(msg)
        # We're assuming diploids
        if not indi_line.startswith('#'):
            msg = 'Haplotype guess results file parsing failed in line:\n'
            msg += indi_line
            raise RuntimeError(msg)
        indi = indi_line[1:].split('#', 1)[0].strip()
        multiindex.append((indi, 'haplotype1'))
        haplo1 = Series(haplo1_line.split())
        haplotypes.append(haplo1)

        multiindex.append((indi, 'haplotype2'))
        haplo2 = Series(haplo2_line.split())
        haplotypes.append(haplo2)
    haplotypes = DataFrame(haplotypes)
    multiindex = MultiIndex.from_tuples(multiindex)
    haplotypes.index = multiindex
    haplotypes.columns = snp_names
    return MatrixWithMeta(haplotypes)


def _parse_fast_phase_haplotypes(processes_data, hap_type):

    haplo_names = {'switch': 'hapguess_switch',
                   'individual': 'hapguess_indiv'}
    fname = haplo_names[hap_type]
    chrom_haplotypes = {}
    for index in range(len(processes_data['result_dirs'])):
        results_dir = processes_data['result_dirs'][index]
        chrom_snps = processes_data['chrom_snps'][index]
        chrom_id = processes_data['chrom_ids'][index]
        hap_fname = filter(lambda x: fname in x, os.listdir(results_dir))
        if not hap_fname:
            return
        if len(hap_fname) > 1:
            msg = 'Too many ' + fname + 'result files in dir: ' + results_dir
            raise RuntimeError(msg)
        hap_fpath = pjoin(results_dir, hap_fname[0])
        chrom_haplotype = _parse_hapguess_result(hap_fpath, chrom_snps,
                                                 hap_type)
        chrom_haplotypes[chrom_id] = chrom_haplotype
    return chrom_haplotypes


def _parse_fast_phase_ouput(processes_data, haplotype_types=None):
    if haplotype_types is None:
        haplotype_types = ['switch', 'individual']
    results = {}
    for hap_type in haplotype_types:
        haplos = _parse_fast_phase_haplotypes(processes_data, hap_type)
        if haplos:
            results[hap_type + '_haplotypes'] = haplos
    return results


def run_fast_phase(genotypes, physical_map, dir_path,
                   individual_classification=None, in_parallel=False,
                   parameters=None):
    '''
    If individual_classification (Series object) is provided subpopulation
    file is created and fastPHASE is run with -u flag
    '''

    if not exists(dir_path):
        os.mkdir(dir_path)

    processes_data = create_input_phase_files(genotypes, physical_map,
                         individual_classification=individual_classification,
                                              dir_path=dir_path)

    cmd_template = [get_binary_path('fastPHASE')]

    if individual_classification is not None:
        cmd_template.append('-u' + processes_data['population_fhand'].name)
    if parameters is not None:
        cmd_template.extend(parameters)

    # run fast_phase
    processes = []
    processes_data['result_dirs'] = []
    for chrom_id, genotype_fhand in zip(processes_data['chrom_ids'],
                                        processes_data['genotype_fhands']):
        chrom_dir = pjoin(dir_path, chrom_id)
        processes_data['result_dirs'].append(chrom_dir)
        if not exists(chrom_dir):
            os.mkdir(chrom_dir)
        cmd = cmd_template[:]
        cmd.append(genotype_fhand.name)
        process, stdout, stderr = run_wrapped_cmd(cmd, chrom_dir)
        processes.append(process)
        if not in_parallel:
            process.wait()
    if in_parallel:
        for process in processes:
            process.wait()
    for process in processes:
        check_finished_process(process, binary='fastPHASE', stdout=stdout,
                               stderr=stderr)
    run_info_fhand = open(pjoin(dir_path, 'phase_run_info.json'), 'w')
    results_info = {}
    for key in ['result_dirs', 'chrom_snps', 'chrom_ids']:
        results_info[key] = processes_data[key]
    json.dump(results_info, run_info_fhand)
    run_info_fhand.flush()


def parse_fast_phase_results(results_dir):
    try:
        run_info_fhand = open(pjoin(results_dir, 'phase_run_info.json'))
    except IOError:
        msg = 'The given fast phase result dir lacks the phase_run_info.json'
        raise ValueError(msg)
    results_info = json.load(run_info_fhand)

    results = _parse_fast_phase_ouput(results_info)

    return results
