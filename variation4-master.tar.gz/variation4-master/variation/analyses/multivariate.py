'''
Created on 02/03/2012

@author: jose
'''

from numpy import add, newaxis, transpose, sqrt, argsort, dot
from numpy import sum as nsum
from numpy.linalg import eigh, svd
from pandas import DataFrame, Series

from variation.matrixwithmeta import MatrixWithMeta, FLOAT
from variation.analyses.smartpca import (do_smartpca,
                                         prepare_smartpca_outliers,
                                         prepare_smartpca_sex_chrom)


def _make_f_matrix(matrix):
    """It takes an E matrix and returns an F matrix

    The input is the output of make_E_matrix

    For each element in matrix subtract mean of corresponding row and
    column and add the mean of all elements in the matrix
    """
    num_rows, num_cols = matrix.shape
    #make a vector of the means for each row and column
    #column_means = (add.reduce(E_matrix) / num_rows)
    column_means = (add.reduce(matrix) / num_rows)[:, newaxis]
    trans_matrix = transpose(matrix)
    row_sums = add.reduce(trans_matrix)
    row_means = row_sums / num_cols
    #calculate the mean of the whole matrix
    matrix_mean = nsum(row_sums) / (num_rows * num_cols)
    #adjust each element in the E matrix to make the F matrix

    matrix -= row_means
    matrix -= column_means
    matrix += matrix_mean

    return matrix


def do_pcoa(distances):
    'It does a Principal Coordinate Analysis on a distance matrix'
    # the code for this function is taken from pycogent metric_scaling.py
    # Principles of Multivariate analysis: A User's Perspective.
    # W.J. Krzanowski Oxford University Press, 2000. p106.

    dists = distances.data.values

    e_matrix = (dists * dists) / -2.0
    f_matrix = _make_f_matrix(e_matrix)

    eigvals, eigvecs = eigh(f_matrix)
    eigvecs = eigvecs.transpose()
    # drop imaginary component, if we got one
    eigvals, eigvecs = eigvals.real, eigvecs.real

    # convert eigvals and eigvecs to point matrix
    # normalized eigenvectors with eigenvalues

    # get the coordinates of the n points on the jth axis of the Euclidean
    # representation as the elements of (sqrt(eigvalj))eigvecj
    # must take the absolute value of the eigvals since they can be negative
    pca_matrix = eigvecs * sqrt(abs(eigvals))[:, newaxis]

    # output
    # get order to output eigenvectors values. reports the eigvecs according
    # to their cooresponding eigvals from greatest to least
    vector_order = list(argsort(eigvals))
    vector_order.reverse()

    eigvals = eigvals[vector_order]

    #eigenvalues
    pcnts = (eigvals / nsum(eigvals)) * 100.0
    fmt = 'pcoa-{:0' + str(len(str(len(pcnts)))) + 'd}'
    dim_names = [fmt.format(i) for i in range(1, len(pcnts) + 1)]
    pcnts = Series(pcnts, dim_names)
    pcnts = MatrixWithMeta(pcnts)
    pcnts.kind = FLOAT

    # the outputs
    # eigenvectors in the original pycogent implementation, here we name them
    # princoords
    # I think that we're doing: if the eigenvectors are written as columns,
    # the rows of the resulting table are the coordinates of the objects in
    # PCO space
    projections = []
    for name_i in range(len(distances.data.index)):
        eigvect = [pca_matrix[vec_i, name_i] for vec_i in vector_order]
        projections.append(eigvect)
    projections = MatrixWithMeta(DataFrame(projections,
                                          index=distances.data.index,
                                          columns=dim_names))
    projections.kind = FLOAT

    return {'projections': projections,
            'var_percentages': pcnts}


def _center_matrix(matrix):
    'It centers the matrix'
    means = matrix.mean(axis=0)
    return matrix - means


def _standarize_matrix(matrix):
    'It centers the matrix'
    means = matrix.mean(axis=0)
    std_devs = matrix.std(axis=0)
    #center the matrix
    matrix = (matrix - means) / std_devs
    return matrix


def do_pca(matrix):
    'It does a Principal Component Analysis'

    matrix = matrix.data

    n_rows, n_cols = matrix.shape
    if n_rows < n_cols:
        # This restriction is in the matplotlib implementation, but I don't
        # know the reason
        msg = 'The implementation requires more rows than columns'
        raise RuntimeError(msg)

    # Implementation based on the matplotlib PCA class
    cen_matrix = _center_matrix(matrix)
    # The following line should be added from a example to get the correct
    #variances
    #cen_scaled_matrix = cen_matrix / math.sqrt(n_rows - 1)
    cen_scaled_matrix = cen_matrix

    singular_vals, princomps = svd(cen_scaled_matrix, full_matrices=False)[1:]
    eig_vals = singular_vals ** 2
    pcnts = eig_vals / eig_vals.sum() * 100.0
    projections = dot(princomps, cen_matrix.T).T

    #output
    fmt = 'pca-{:0' + str(len(str(len(pcnts)))) + 'd}'
    dim_names = [fmt.format(i) for i in range(1, len(pcnts) + 1)]
    pcnts = Series(pcnts, dim_names)
    pcnts = MatrixWithMeta(pcnts)
    pcnts.kind = FLOAT

    projections = DataFrame(projections, index=matrix.index, columns=dim_names)
    projections = MatrixWithMeta(projections)
    projections.kind = FLOAT

    princomps = DataFrame(princomps, index=dim_names)
    princomps = MatrixWithMeta(princomps)
    princomps.kind = FLOAT

    return {'projections': projections,
            'var_percentages': pcnts,
            'princomps': princomps}
