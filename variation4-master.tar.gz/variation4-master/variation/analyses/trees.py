
from __future__ import division

import sys
from itertools import imap
import copy
import re
import numpy

from scipy.stats import pearsonr

from cogent.phylo import nj
from cogent.core.tree import PhyloNode
from pandas import DataFrame

# pylint: disable=C0111

# The following code has been copied from cogent.core.tree


def getNewick(self, with_distances=False, semicolon=True, escape_name=True,
              with_boot=False):
    """Return the newick string for this tree.

Arguments:
- with_distances: whether branch lengths are included.
- semicolon: end tree string with a semicolon
- escape_name: if any of these characters []'"(),:;_ exist in a
nodes name, wrap the name in single quotes

NOTE: This method returns the Newick representation of this node
and its descendents. This method is a modification of an implementation
by Zongzhi Liu
"""
    result = ['(']
    nodes_stack = [[self, len(self.Children)]]
    node_count = 1

    while nodes_stack:
        node_count += 1
        #check the top node, any children left unvisited?
        top = nodes_stack[-1]
        top_node, num_unvisited_children = top
        if num_unvisited_children:  # has any child unvisited
            top[1] -= 1  # decrease the #of children unvisited
            next_child = top_node.Children[-num_unvisited_children]  # - for order
            #pre-visit
            if next_child.Children:
                result.append('(')
            nodes_stack.append([next_child, len(next_child.Children)])
        else:  # no unvisited children
            nodes_stack.pop()
            #post-visit
            if top_node.Children:
                result[-1] = ')'

            if top_node.NameLoaded:
                if top_node.Name is None:
                    name = ''
                else:
                    name = str(top_node.Name)
                    if escape_name and not (name.startswith("'") and \
                                            name.endswith("'")):
                        if re.search("""[]['"(),:;_]""", name):
                            name = "'%s'" % name.replace("'", "''")
                        else:
                            name = name.replace(' ', '_')
                result.append(name)

            if isinstance(self, PhyloNode):
                if with_distances and top_node.Length is not None:
                    length = top_node.Length
                else:
                    length = None
                if with_boot and hasattr(top_node, 'bootstrap_support'):
                    boot = top_node.bootstrap_support
                else:
                    boot = None
                if boot is not None and length is not None:
                    result[-1] = "%s%s:%s" % (result[-1], boot, length)
                elif boot is not None and length is None:
                    result[-1] = "%s%s" % (result[-1], boot)
                elif boot is None and length is not None:
                    result[-1] = "%s:%s" % (result[-1], length)
            result.append(',')

    len_result = len(result)
    if len_result == 2:  # single node no name
        if semicolon:
            return ";"
        else:
            return ''
    elif len_result == 3:  # single node with name
        if semicolon:
            return "%s;" % result[1]
        else:
            return result[1]
    else:
        if semicolon:
            result[-1] = ';'
        else:
            result.pop(-1)
        return ''.join(result)
# End of the code copied from cogent.core.tree

PhyloNode.getNewick = getNewick


def nostdout(funct):
    def decorated_funct(*args, **kwargs):
        old_stdout = sys.stdout
        null = open('/dev/null', 'a')
        sys.stdout = null
        result = funct(*args, **kwargs)
        sys.stdout = old_stdout
        return result
    return decorated_funct


def _dataframe_to_cogent_dists(dists_dframe):
    dists = {}
    for col, col_values in dists_dframe.iteritems():
        for row, row_value in col_values.iteritems():
            dists[col, row] = row_value
    return dists


@nostdout
def calc_nj(dist_matrix, boot_matrices=None):
    dists = _dataframe_to_cogent_dists(dist_matrix)
    master_tree = nj.nj(dists)
    if boot_matrices is not None:
        boot_trees = list(imap(calc_nj, boot_matrices))
        master_tree = bootstrap_support(master_tree, boot_trees)[0]
    return master_tree


def calc_cophenetic_corr(dist_matrix, tree):
    ''' It computes Pearson's correlation coefficient and it's p-value
    '''

    index = dist_matrix.index
    columns = dist_matrix.columns

    tree_distances_df = DataFrame(columns=columns, index=index).fillna(0)

    tree_distances = tree.getDistances()
    for pair, distance in tree_distances.viewitems():
        tree_distances_df.ix[pair[0]][pair[1]] = distance

    tree_vector = []
    dist_vector = []

    for row in xrange(0, len(index)):
        for column in xrange(0, len(columns)):
            if column < row:
                tree_vector.append(tree_distances_df.ix[row][column])
                dist_vector.append(dist_matrix.ix[row][column])

    results = {}
    results['corr_coef'], results['p-value'] = pearsonr(dist_vector,
                                                               tree_vector)
    return results


# The following code has been copied from qiime.tree_compare.py
def tree_support(master, subsampled_tree):
    """ compares master tree to subsampled_tree, modifies master in place

    this calculates bootstrap support of each nontip node in the master tree
    a given master_tree_node is supported if there exists a node in subsampled
    tree where sub_tree_node.tips == master_tree_node.tips (by name)

    each subsampled tree is first modified to remove tips and branches leading
    to them if the tip isn't in the master tree

    not specific to bootstrap, does node support for trees generated in any
    manner (e.g.: jackknifing)
    master is modified to have node.bootstrap_support incremented by 1 if
    subsampled tree has support for that node
    """
    master_tipnames = set(master.getTipNames())
    subsampled_tree_trimmed = copy.deepcopy(subsampled_tree)

    def delete_test(node):
        if not node.isTip():
            return False
        else:
            return (node.Name not in master_tipnames)
    subsampled_tree_trimmed.removeDeleted(delete_test)
    subsampled_tree_trimmed.prune()

    # subsampled_tree_nodes_names is a list of lists.
    # each elem is list of tip names for a node
    subsampled_tree_nodes_names = []
    for node in subsampled_tree_trimmed.iterNontips(include_self=True):
        subsampled_tree_nodes_names.append(node.getTipNames())

    #now a list of sets, each set is tip names for a specific node
    subsampled_tree_nodes_names = map(set, subsampled_tree_nodes_names)

    for master_node in master.iterNontips(include_self=True):
        if set(master_node.getTipNames()) in subsampled_tree_nodes_names:
            try:
                master_node.bootstrap_support += 1
            except AttributeError:
                master_node.bootstrap_support = 1


def bootstrap_support(master_tree, trees):
    """ calculate bootstrap/jackknife support of master, by trees

    this calculates bootstrap support of each nontip node in master_tree.

    a tree supports a given master_tree_node if there exists a node in tree
    where node.tips == master_tree_node.tips (by name), ignoring any tips which
    arent present both in the master tree and all support trees.

    not specific to bootstrap, does node support for trees generated in any
    manner (e.g.: jackknifing)

    bootstrap support of .5 => 50% of trees support that node

    input:
    PhyloNode objects, trees is a list of PhyloNode objects

    output: (modified master, bootstrap_supports)
    * new master_tree, modified with internally named nodes
    * bootstrap_supports: dict of (node name: bootstrap support)

    """
    new_master = setup_master_tree(master_tree, trees)
    for sub_tree in trees:
        # modifies new_master in place
        tree_support(new_master, sub_tree)
    num_trees = len(trees)
    bootstrap_supports = {}
    for node in new_master.iterNontips(include_self=True):
        node.bootstrap_support = node.bootstrap_support / num_trees * 100
        bootstrap_supports[node.Name] = node.bootstrap_support

    return new_master, bootstrap_supports


def setup_master_tree(master, support_trees):
    """ inits bootstrap_support on all nontip nodes, and ensures unique names

    returns a nearly identical copy, with uniquely named internal nodes,
    and node.bootstrap_support set to 0

    also removes all tips (and branches leading to them) from the master tree
    if they're not present in all support trees
    """
    new_master = copy.deepcopy(master)
    old_tipnames = new_master.getTipNames()
    old_tipnames_set = set(old_tipnames)
    if len(old_tipnames_set) != len(old_tipnames):
        msg = 'existing master tree appears to have nonunique tip names'
        raise RuntimeError(msg)

    #find tips present in all support trees, keep those in master
    support_tipnames_sets = [set(tree.getTipNames()) for tree in support_trees]
    support_intersection = set.intersection(*support_tipnames_sets)
    all_intersection = set.intersection(support_intersection, old_tipnames_set)

    def delete_test(node):
        if not node.isTip():
            return False
        else:
            return (node.Name not in all_intersection)
    new_master.removeDeleted(delete_test)
    new_master.prune()

    new_tipnames_set = set(new_master.getTipNames())
    if new_tipnames_set != all_intersection:
        raise RuntimeError('master tree not made correctly, sorry' + \
            str(new_master.getTipNames()))

    if len(new_tipnames_set) == 0:
        raise RuntimeError('no tips are present in every support tree')
    # give internal nodes unique names
    i = 0
    for node in new_master.iterNontips(include_self=True):
        node.bootstrap_support = 0
        if getattr(node, 'Name', None) == None or \
            getattr(node, 'Name', None) == "":
            node.Name = "node" + str(i)
            i += 1
    if len(set(new_master.getNodeNames())) != len(new_master.getNodeNames()):
        node_names = master.getNodeNames()

        nonuniques = []
        for name in set(node_names):
            if node_names.count(name) > 1:
                nonuniques.append(name)
        raise ValueError("can't setup master tree, nonunique node names" +
            str(nonuniques))

    return new_master
# End of the code copied from qiime.tree_compare.py
