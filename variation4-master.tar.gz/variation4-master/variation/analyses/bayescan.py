
from variation.analyses.pop_stats import PopPolymorphism
from variation.matrixwithmeta import INDIVIDUALS_IN_ROWS, PLOIDY


def create_infile(genotypes, classification, out_fhand, info_fhand):
    fhand = out_fhand
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        n_loci = genotypes.data.shape[1]
        markers = genotypes.data.columns
    else:
        n_loci = genotypes.data.shape[0]
        markers = genotypes.data.index
    fhand.write('[loci]=' + '%s' % (n_loci) + '\n\n')

    popstats = PopPolymorphism(genotypes, classification)

    pops = popstats._genotypic_counts['pop_order']
    n_genotypes = popstats._genotypic_counts['n_genotypes']
    fhand.write('[populations]=' + '%s' % (len(pops)) + '\n\n')

    allele_counts = {allele: popstats._genotypic_counts['allele_freqs'][allele] * n_genotypes * 2 for allele in range(1,5)}

    if pops:
        info_fhand.write('Populations\n')
    last_pop = False
    for pop_idx, pop in enumerate(pops):
        fhand.write('[pop]=%s\n' % (pop_idx + 1))
        info_fhand.write('%i\t%s\n' % (pop_idx + 1, pop))
        if pop_idx >= len(pops) - 1:
            info_fhand.write('Markers\n')
            last_pop = True
        for marker_idx, marker in enumerate(markers):
            if last_pop:
                info_fhand.write('%i\t%s\n' % (marker_idx + 1, marker))
            marker_cnts = [allele_counts[allele][pop_idx, marker_idx] for allele in range(1, 5)]
            line = [marker_idx + 1]
            line.append(sum(marker_cnts))
            line.append(len(marker_cnts))
            line.extend(marker_cnts)
            fhand.write(' '.join(str(int(cnt)) for cnt in line))
            fhand.write('\n')
        fhand.write('\n')
