
import os
from os.path import join as pjoin
from os.path import exists
import subprocess
from tempfile import NamedTemporaryFile

from pandas import DataFrame
import numpy

from variation.inout.genetic import get_codec_from_genotypes
from variation.matrixwithmeta import PLOIDY, INDIVIDUALS_IN_ROWS
from variation.utils import TemporaryDir, get_binary_path


def _create_inputfile(fhand, genotypes, classification,
                      standardized_sample_size=None):

    codec = get_codec_from_genotypes(genotypes)

    meta = genotypes.meta
    genotypes = genotypes.data

    ploidy = meta[PLOIDY]
    if not meta[INDIVIDUALS_IN_ROWS]:
        genotypes = genotypes.T

    params = {}
    #Max standardized sample size
    if standardized_sample_size:
        params['MAX_G'] = standardized_sample_size
    else:
        params['MAX_G'] = len(genotypes)
    #Number of lines of data
    params['DATA_LINES'] = ploidy * len(genotypes)
    #Number of loci
    params['LOCI'] = len(genotypes.columns)
    #Number of rows preceeding data including at least the locus names
    params['NON_DATA_ROWS'] = 1
    #Number of classifier columns at the beginning of each data line
    params['NON_DATA_COLS'] = 2
    #The column number by which to group the data
    params['GROUP_BY_COL'] = 2
    #Name of the datafile
    params['DATA_FILE'] = fhand.name
    #Missing data representation
    missing_data = '-9'
    params['MISSING'] = missing_data

    if set(classification.index) != set(genotypes.index):
        accs = set(classification.index).symmetric_difference(genotypes.index)
        msg = 'Some accesions are not present in the genotypes or '
        msg += 'classification: ' + ' '.join(accs)
        raise ValueError(msg)
    classification.sort()

    fhand.write(' '.join(genotypes.columns) + '\n')

    for acc in classification.index:
        group = classification[acc]
        ind_info = acc + ' ' + group
        geno = genotypes.ix[acc].apply(codec.decode_to_ints)
        lines = {}
        for chrom in range(ploidy):
            lines[chrom] = ''
        for marker in geno.index:
            alleles = geno[marker]
            if alleles:
                for chrom in range(ploidy):
                    lines[chrom] += (' ' + str(alleles[chrom]))
            else:
                for chrom in range(ploidy):
                    lines[chrom] += ' ' + missing_data
        for chrom in range(ploidy):
            fhand.write(ind_info + lines[chrom] + '\n')

    fhand.flush()
    return params


def _create_parmfile(fhand, params, tolerance, richness_out_fpath,
                     private_out_fpath):

    #Name of the allelic richness output file
    params['R_OUT'] = richness_out_fpath
    #Name of the private allelic richness
    params['P_OUT'] = private_out_fpath

    #Filter loci with a grouping having more than this fraction of missing data
    if  tolerance:
        if tolerance >= 0 and tolerance <= 1:
            params['TOLERANCE'] = tolerance
        else:
            raise ValueError('Tolerance has to be a value between 0 and 1')
    else:
        params['TOLERANCE'] = 1

    #Output private allelic richness results for all loci? [0,1]
    params['FULL_P'] = 0
    #Output private allelic richness for combinations for all loci? [0,1]
    params['FULL_C'] = 0
    #Output allelic richness results for all loci?
    params['FULL_R'] = 0
    #Track calculation progress on screen? [0,1]
    params['PRINT_PROGRESS'] = 0

    #Calculate private allelic richness for combinations of groupings?
    params['COMB'] = 0
    #A listing of combinations to calculate
    params['K_RANGE'] = ''
    #Name of the private allelic richness of combinations output file
    params['C_OUT'] = ''

    for key in params:
        fhand.write(key + ' ' + str(params[key]) + '\n')

    fhand.flush()


def parse_adze_results(richness_fhand, private_fhand):

    richness = {}
    pop = None
    pop_richness = []
    for line in richness_fhand:
        line = line.strip()
        if line:
            pop, n_chroms, n_markers, mean = line.split()[:-2]
            pop_richness.append(float(mean))
        else:
            if pop is not None:
                richness[pop] = pop_richness
            pop = None
            pop_richness = []

    max_n_chroms = max(len(r) for r in richness.values())
    for pop, values in richness.viewitems():
        if len(values) < max_n_chroms:
            dif = max_n_chroms - len(values)
            values.extend([numpy.float('nan')] * dif)
    richness = DataFrame(richness, index=map(str, range(2, max_n_chroms + 2)))

    private = {}
    pop = None
    pop_private = []
    for line in private_fhand:
        line = line.strip()
        if line:
            pop, n_chroms, n_markers, mean = line.split()[:-2]
            pop_private.append(float(mean))
        else:
            if pop is not None:
                private[pop] = pop_private
            pop = None
            pop_private = []
    n_chroms = len(private[private.keys()[0]])
    private = DataFrame(private, index=map(str, range(2, n_chroms + 2)))
    return {'allelic_richness': richness, 'private_alleles': private}


def do_rarefaction(genotypes, classification, dir_path=None,
                   fraction_missing_data_tolerance=0.5,
                   standardized_sample_size=None):

    if dir_path:
        if not exists(dir_path):
            os.mkdir(dir_path)
        temp_dir = None
    else:
        temp_dir = TemporaryDir()
        dir_path = temp_dir.name

    input_fhand = open(pjoin(dir_path, 'inputfile.txt'), 'w')
    param_fhand = open(pjoin(dir_path, 'parmfile.txt'), 'w')

    params = _create_inputfile(input_fhand, genotypes, classification,
                            standardized_sample_size=standardized_sample_size)

    richness_out_fhand = NamedTemporaryFile(prefix='richness', suffix='.txt',
                                            dir=dir_path, delete=False)
    private_out_fhand = NamedTemporaryFile(prefix='private', suffix='.txt',
                                           dir=dir_path, delete=False)
    _create_parmfile(param_fhand, params,
                     tolerance=fraction_missing_data_tolerance,
                     richness_out_fpath=richness_out_fhand.name,
                     private_out_fpath=private_out_fhand.name)

    cmd = [get_binary_path('adze-1.0')]
    cmd.append(param_fhand.name)

    subprocess.check_output(cmd)

    results = parse_adze_results(open(richness_out_fhand.name),
                                 open(private_out_fhand.name))

    if temp_dir is not None:
        temp_dir.close()

    return results