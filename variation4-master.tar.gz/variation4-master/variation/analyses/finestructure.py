
from __future__ import division

from os import mkdir
from os.path import exists
from tempfile import NamedTemporaryFile

from variation.matrixwithmeta import MOLECULE_COL, LOCATION_COL


def _create_recombination_infile(physical_map, genetic_map, valid_snps,
                                 out_dir_path):
    fhand = NamedTemporaryFile(suffix='.recomb', prefix='chromopainter.',
                               dir=out_dir_path, delete=False)

    physical_loc_col = physical_map.meta[LOCATION_COL]
    chrom_col = physical_map.meta[MOLECULE_COL]
    genetic_loc_col = genetic_map.meta[LOCATION_COL]

    fhand.write("start.pos recom.rate.perbp\n")

    physical_map = physical_map.data
    genetic_map = genetic_map.data

    for index in range(len(valid_snps)):
        snp = valid_snps[index]
        phys_loc = physical_map.get_value(snp, physical_loc_col)
        genet_loc = genetic_map.get_value(snp, genetic_loc_col)
        chrom = physical_map.get_value(snp, chrom_col)
        try:
            next_snp = valid_snps[index + 1]
        except IndexError:
            next_snp = None
        if next_snp is None:
            recomb_rate = 0
        else:
            next_chrom = physical_map.get_value(next_snp, chrom_col)
            if chrom == next_chrom:
                next_genet_loc = genetic_map.get_value(next_snp,
                                                       genetic_loc_col)
                next_phys_loc = physical_map.get_value(next_snp,
                                                       physical_loc_col)
                phys_dist = next_phys_loc - phys_loc
                if phys_dist < 0:
                    msg = 'markers in physical map should be sorted:'
                    msg += ' %s %s' % (snp, next_snp)
                    raise ValueError(msg)
                elif phys_dist == 0:
                    msg = 'Two markers are located in the same physical'
                    msg = 'location: %s %s' % (snp, next_snp)
                    raise ValueError(msg)
                genet_dist = next_genet_loc - genet_loc
                if genet_dist < 0:
                    msg = 'Inside a chromosome two consecutive markers have'
                    msg += 'negative genetic distance: %s %s' % (snp, next_snp)
                    raise ValueError(msg)
                recomb_rate = (genet_dist) / (phys_dist)
            else:
                recomb_rate = -9
        recomb_rate = '%.15f' % recomb_rate
        if recomb_rate.replace('0', '').replace('.', '') == '-':
            recomb_rate = recomb_rate[1:]
        line = '%d %s\n' % (phys_loc, recomb_rate)
        fhand.write(line)
    fhand.flush()
    return fhand


def _create_haplotype_infile(haplotypes, physical_map, valid_snps,
                             out_dir_path):

    pos_col = physical_map.meta[LOCATION_COL]

    fhand = NamedTemporaryFile(suffix='.hap_infile', prefix='chromopainter.',
                               dir=out_dir_path, delete=False)
    fhand.write('0\n')
    n_indis = len(set(haplotypes.index.get_level_values(0)))
    n_haplos = len(haplotypes.index.get_level_values(1))
    ploidy = n_haplos / n_indis
    if ploidy == 2:
        fhand.write('%d\n' % (len(haplotypes.index) / 2))
    elif ploidy == 1:
        fhand.write('%d\n' % (len(haplotypes.index)))
    else:
        msg = 'Data is neither diploid nor haploid'
        raise ValueError(msg)
    fhand.write('%d\n' % (len(valid_snps)))
    positions = ['%d' % physical_map.data.get_value(snp, pos_col) for snp in valid_snps]
    fhand.write('P ' + (' ').join(positions) + '\n')
    fhand.write('S' * len(valid_snps) + '\n')
    for haplo in haplotypes.index:
        str_haplotype = ('').join(haplotypes.xs(haplo)) + '\n'
        fhand.write(str_haplotype)
    fhand.flush()
    return fhand


def create_chromopainter_infiles(haplotypes, physical_map, genetic_map,
                                 out_dir_path, donor_haplotypes=None):

    if donor_haplotypes is not None:
        msg = 'donor_haplotypes options is not implemented yet'
        raise NotImplementedError(msg)

    if not exists(out_dir_path):
        mkdir(out_dir_path)

    # we want only the snps shared between the haplotypes and the maps
    haplotype_snps = haplotypes.data.columns
    snps_in_map = physical_map.data.index
    valid_snps = filter(lambda x: x in haplotype_snps, snps_in_map)
    haplotypes = haplotypes.data[valid_snps]

    maps_fhand = _create_recombination_infile(physical_map, genetic_map,
                                              valid_snps, out_dir_path)
    haplo_fhand = _create_haplotype_infile(haplotypes, physical_map, valid_snps,
                                           out_dir_path)
    maps_fhand.close()
    haplo_fhand.close()
    return {'maps_fhand': maps_fhand, 'haplotype_fhand': haplo_fhand}
