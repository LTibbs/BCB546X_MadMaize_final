
from variation.matrixwithmeta import (PLOIDY, INDIVIDUALS_IN_ROWS,
                                      BITS_PER_ALLELE, ALLELE_CODING)
from variation.analyses.matrix_tools import transpose_genotypes
from variation.inout.genetic import GenotypeCodec


def create_file_snp_fomat(fhand, genotypes, indi_classification=None):
    ''' It creates the input file to be read with adegenet (R package)
    read.snp function

    Adegenet performs spatial PCA, k-means analysis and discriminant analysis
    '''

    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        genotypes = transpose_genotypes(genotypes)

    meta = genotypes.meta
    genotypes = genotypes.data
    individuals = genotypes.columns

    fhand.write('>>>> begin comments - do not remove this line <<<<\n')
    fhand.write('>>>> end comments - do not remove this line <<<<\n')

    if meta[PLOIDY] is not None:
        fhand.write('>> ploidy\n')
        fhand.write(str(meta[PLOIDY]) + '\n')

    if indi_classification is not None:
        fhand.write('>> population\n')
        indi_classification = indi_classification.reindex(individuals)
        pops = (' ').join(indi_classification.values)
        fhand.write(pops + '\n')

    codec = GenotypeCodec(ploidy=meta[PLOIDY],
                          bits_per_allele=meta[BITS_PER_ALLELE],
                          alleles_coding=meta[ALLELE_CODING])

    coding = None
    for individual in individuals:
        fhand.write('> ' + str(individual) + '\n')
        indv_genotype = list(genotypes[individual].apply(codec.decode_to_ints))
        formated_geno = []
        #It keeps the first allele that founds as a reference allele
        if coding is None:
            coding = [snp[0] if snp is not None else None for snp in indv_genotype]
        for index in range(len(indv_genotype)):
            ref = coding[index]
            snp = indv_genotype[index]
            if (ref is None) and (snp is not None):
                coding[index] = snp[0]
                ref = coding[index]
            if snp is None:
                formated_geno.append('-')
            else:
                if (snp[0] == snp[1]) and (snp[0] == ref):
                    formated_geno.append('0')
                elif (snp[0] != snp[1]) and (snp[0] == ref or snp[1] == ref):
                    formated_geno.append('1')
                elif (snp[0] == snp[1]) and (snp[0] != ref):
                    formated_geno.append('2')
                else:
                    msg = 'Genotype %s cannot be converted ' % (snp, )
                    raise ValueError(msg)
        fhand.write(('').join(formated_geno) + '\n')
    fhand.flush()
