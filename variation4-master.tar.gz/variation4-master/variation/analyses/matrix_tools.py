'''
Created on 15/03/2012

@author: jose
'''

from collections import OrderedDict
from operator import itemgetter
import collections
from math import isnan

import numpy

from pandas import isnull, DataFrame, Series, concat

from variation.matrixwithmeta import (MatrixWithMeta, MOLECULE_COL,
                                      LOCATION_COL, LINKAGE_GROUP_COL,
                                      GENETIC_LOCATION_COL, GENETIC, PHYSICAL,
                                      INDIVIDUALS_IN_ROWS)


def _sets_are_equal(set1, set2):
    'It returns True if each set is a subset of the other'
    return set1.issubset(set2) and set2.issubset(set1)


def _get_items_from_series_or_index(series):
    'It returns the items given a series or an index'
    try:
        items = series.index
    except AttributeError:
        items = series
    return items


def vectors_have_same_items(series):
    'It returns True if all series, indexes or lists have the same items'
    items = None
    for serie in series:
        current_items = set(_get_items_from_series_or_index(serie))
        if items is None:
            items = current_items
        else:
            if not _sets_are_equal(current_items, items):
                return False
    return True


def vectors_have_same_items_sorted(series):
    '''It returns True if all series have the same items in the same order.

    It works with series, indexes and lists.
    '''
    items = None
    for serie in series:
        current_items = _get_items_from_series_or_index(serie)
        if items is None:
            items = current_items
        else:
            if numpy.any(current_items != items):
                return False
    return True


def vector_is_subset_of_others(serie, series):
    '''It returns True if series is a subset of all series.

    It works with series, indexes and lists.
    '''
    items = set(_get_items_from_series_or_index(serie))
    for serie in series:
        if not items.issubset(_get_items_from_series_or_index(serie)):
            return False
    return True


def _common_rows(dataframes):
    '''Given a list of dataframes it returns the common row names.

    The order of the final rows will be the ones of the first DataFrame.
    '''
    counts = None
    for dframe in dataframes:
        if counts is None:
            counts = OrderedDict((k, 1) for k in dframe.index)
        else:
            for row in dframe.index:
                if row in counts:
                    counts[row] += 1
    n_dframes = len(dataframes)
    common = [row for row, count in counts.viewitems() if count == n_dframes]
    return common


def dframes_purge_unshared_rows(dataframes):
    '''It returns the dataframes with the common rows.

    The order of the final rows might be the one of the first DataFrame.
    '''
    to_keep = _common_rows(dataframes)

    #now we filter
    filtered_dframes = []
    for dframe in dataframes:
        filtered_dframes.append(dframe.ix[to_keep, :])
    return filtered_dframes


def matrices_purge_unshared_rows(matrices):
    '''Given a list of MatrixWithMeta it returns new matrices with the common
    rows.

    It will copy the metadata to the new matrices.
    It assumes that all the MatrixWithMeta in the list contain dataframes.
    The order of the final rows might be the one of the first DataFrame.
    '''
    to_keep = _common_rows([mat.data for mat in matrices])

    #now we filter
    filtered_matrices = []
    for matrix in matrices:
        filtered_dataframe = matrix.data.ix[to_keep, :]
        filtered_matrix = MatrixWithMeta(filtered_dataframe,
                                         matrix.meta.copy())
        filtered_matrices.append(filtered_matrix)
    return filtered_matrices


def dframe_append_columns(dframe, series):
    '''It appends a list of series to a dataframe.

    It purges the rows not shared by all series and dataframe.
    '''
    merged_dframe = dframe
    common_rows = set(dframe.index)
    for serie in series:
        if serie.name is None:
            msg = 'The series to add should have the name set.'
            raise ValueError(msg)
        merged_dframe = merged_dframe.join(serie)
        common_rows = common_rows.intersection(serie.index)
    common_rows = list(common_rows)
    return merged_dframe.ix[common_rows]


def hstack_dframes(dframe1, dframe2, lsuffix=None, rsuffix=None):
    kwargs = {}
    if lsuffix is not None:
        kwargs['lsuffix'] = lsuffix
    if rsuffix is not None:
        kwargs['rsuffix'] = rsuffix
    return dframe1.join(dframe2, **kwargs)


def vstack_dframes(dframe1, dframe2):
    return concat([dframe1, dframe2])


def sorted_dframe_by_rows(dframe, key, reverse=False):
    'Given a key for the rows it returns a sorted dataframe'
    # pylint: disable=C0301
    # pylint: disable=W0612
    # we transpose to avoid creating the rows for every comparison
    dframe = sorted_dframe_by_cols(dframe.T, key, reverse=reverse)
    return dframe.T


def sorted_matrix_by_rows(matrix, key, reverse=False):
    'Given a key for the rows it returns a sorted dataframe'
    data = sorted_dframe_by_rows(matrix.data, key=key, reverse=reverse)
    return MatrixWithMeta(data, metadata=matrix.meta.copy())


def any_null(dframe_or_series):
    'It returns True if there is at least one null value'
    nulls = isnull(dframe_or_series)
    if isinstance(nulls, DataFrame):
        # pylint: disable=W0612
        for col_name, col in nulls.iteritems():
            if col.any():
                return True
        else:
            return False
    elif isinstance(nulls, Series):
        return nulls.any()
    else:
        raise NotImplementedError()


def sorted_dframe_by_cols(dframe, key, reverse=False):
    'Given a key for the columns it returns a sorted dataframe'
    # pylint: disable=C0301
    # pylint: disable=W0612

    values_to_sort = Series([key(dframe[col]) for col in dframe.columns])
    if any_null(values_to_sort):
        raise ValueError('Sorting with Nan values is not well defined')
    sorted_values = values_to_sort.order(ascending=not(reverse))
    sorted_cols = sorted_values.index

    sorted_frame = dframe.take(numpy.array(sorted_cols), axis=1)
    return sorted_frame


def sorted_matrix_by_cols(matrix, key, reverse=False):
    'Given a key for the columns it returns a sorted dataframe'
    data = sorted_dframe_by_cols(matrix.data, key=key, reverse=reverse)
    return MatrixWithMeta(data, metadata=matrix.meta.copy())


def sorted_matrix(matrix, by_rows=None, by_columns=None, by_index=False,
                  by_column_names=False, ascending=True):
    'It sorts a matrix by a row or a column'

    n_criteria = 0
    if by_rows is not None:
        n_criteria += 1
    if by_columns is not None:
        n_criteria += 1
    if by_index:
        n_criteria += 1
    if by_column_names:
        n_criteria += 1

    if n_criteria > 1:
        msg = 'Sorting should be done only by one criteria.'
        raise ValueError(msg)
    elif n_criteria == 0:
        raise ValueError('Some sorting criteria is required.')
    elif not by_columns is None:
        # para series print matrix.data[by_columns].notnull()
        if any_null(matrix.data[by_columns]):
            raise ValueError('Sorting with null values is not well defined')
        sorted_data = matrix.data.sort(columns=by_columns, ascending=ascending)
    elif by_index:
        sorted_data = matrix.data.sort(columns=None, axis=0,
                                       ascending=ascending)
    elif not by_rows is None:
        sorted_data = matrix.data.T.sort(columns=by_rows, ascending=ascending)
        sorted_data = sorted_data.T
    elif not by_column_names is None:
        sorted_data = matrix.data.T.sort(columns=None, axis=0,
                                         ascending=ascending)
        sorted_data = sorted_data.T
    return matrix.__class__(data=sorted_data, metadata=matrix.meta)


def marker_map_type(marker_map):
    '''It returns the type of marker map (genetic or physical).

    If it has no valid type or if it has two types it raises a ValueError.
    '''
    meta = marker_map.meta
    if MOLECULE_COL in meta and not LINKAGE_GROUP_COL in meta:
        kind = PHYSICAL
    elif not MOLECULE_COL in meta and LINKAGE_GROUP_COL in meta:
        kind = GENETIC
    elif not MOLECULE_COL in meta and not LINKAGE_GROUP_COL in meta:
        msg = 'This map is malformed. There is not enough metadata'
        raise ValueError(msg)
    else:
        msg = 'This map is both physical and genetic'
        raise ValueError(msg)
    return kind


def sorted_marker_map(marker_map, sort_by=None):
    '''It returns the marker map sorted by chromosome and position.

    sort_by can be "genetic" or "physical".
    '''
    if sort_by is None:
        try:
            sort_by = marker_map_type(marker_map)
        except ValueError:
            msg = 'Please specify if the sorting should be genetic or physical'
            msg += ' or fix the map'
            raise ValueError(msg)

    if sort_by not in (GENETIC, PHYSICAL):
        msg = 'sort_by should be either GENETIC or PHYSICAL'
        raise ValueError(msg)

    meta = marker_map.meta
    if sort_by == PHYSICAL:
        col2 = meta[LOCATION_COL]
    else:
        col2 = meta[GENETIC_LOCATION_COL]
    if sort_by == PHYSICAL:
        col1 = meta[MOLECULE_COL]
    else:
        col1 = meta[LINKAGE_GROUP_COL]

    marker_map = sorted_matrix(marker_map, by_columns=[col1, col2],
                               ascending=True)
    return marker_map


def _is_callable(item):
    'It returns True if the given item is callable'
    if hasattr(item, '__call__') or isinstance(item, collections.Callable):
        return True
    else:
        return False


def _is_dict(item):
    'It returns True if the item is a dictionary'
    if hasattr(item, 'keys'):
        return True
    else:
        return False


def _is_collection(item):
    'It returns True if the item is a collection with an __contains__ method'
    if isinstance(item, basestring):
        return False
    if hasattr(item, '__contains__'):
        return True
    else:
        return False


def filter_matrix_rows(matrix, criteria, reverse=False):
    '''It returns a new matrix with the selected rows.

    The criteria can be a callable that takes rows and returns a boolean,
    a dictionary with column names as keys and values to be matched as values
    or a collection with row names.
    In the dictionary case the values can be a collection or just an item.
    '''
    selected_rows = []
    dframe = matrix.data
    if _is_callable(criteria):
        for row_index, (row_name, row) in enumerate(dframe.iterrows()):
            criteria_eval = criteria(row)
            if reverse:
                criteria_eval = not(criteria_eval)
            if criteria_eval:
                selected_rows.append(row_index)
    elif _is_dict(criteria) or _is_collection(criteria):
        crit_type = 'dict' if _is_dict(criteria) else 'col'
        for row_index, row_name in enumerate(dframe.index):
            if crit_type == 'dict':
                col_matches = []
                for col, val in criteria.viewitems():
                    cell_value = dframe.get_value(row_name, col)
                    if _is_collection(val):
                        #print row_name, cell_value, val
                        col_matches.append(cell_value in val)
                    else:
                        col_matches.append(cell_value == val)
                criteria_eval = all(col_matches)
            else:
                criteria_eval = row_name in criteria
            if reverse:
                criteria_eval = not(criteria_eval)
            if criteria_eval:
                selected_rows.append(row_index)
    else:
        msg = 'The criteria should be a callable, a dict or a collection'
        raise ValueError(msg)
    sel_dframe = dframe.take(numpy.array(selected_rows), axis=0)

    return MatrixWithMeta(sel_dframe, metadata=matrix.meta)


def filter_matrix_cols(matrix, criteria, reverse=False):
    '''It returns a new matrix with the selected cols.

    The criteria can be a callable that takes rows and returns a boolean,
    a dictionary with column names as keys and values to be matched as values
    or a collection with row names.
    In the dictionary case the values can be a collection or just an item.
    '''
    selected_cols = []
    dframe = matrix.data
    if _is_callable(criteria):
        for col_index, (col_name, col) in enumerate(dframe.iteritems()):
            criteria_eval = criteria(col)
            if reverse:
                criteria_eval = not(criteria_eval)
            if criteria_eval:
                selected_cols.append(col_index)
    elif _is_dict(criteria) or _is_collection(criteria):
        crit_type = 'dict' if _is_dict(criteria) else 'col'
        for col_index, col_name in enumerate(dframe.columns):
            if crit_type == 'dict':
                row_matches = []
                for row, val in criteria.viewitems():
                    cell_value = dframe.get_value(row, col_name)
                    if _is_collection(val):
                        row_matches.append(cell_value in val)
                    else:
                        row_matches.append(cell_value == val)
                criteria_eval = all(row_matches)
            else:
                criteria_eval = col_name in criteria
            if reverse:
                criteria_eval = not(criteria_eval)
            if criteria_eval:
                selected_cols.append(col_index)
    else:
        msg = 'The criteria should be a callable, a dict or a collection'
        raise ValueError(msg)
    sel_dframe = dframe.take(numpy.array(selected_cols), axis=1)

    return MatrixWithMeta(sel_dframe, metadata=matrix.meta)


def transpose_genotypes(genotypes):
    'It transposes the given genotype matrix'
    meta = genotypes.meta.copy()
    meta[INDIVIDUALS_IN_ROWS] = not meta[INDIVIDUALS_IN_ROWS]
    return MatrixWithMeta(genotypes.data.T, metadata=meta)
