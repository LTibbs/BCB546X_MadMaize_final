'''
Created on 03/04/2012

@author: jose
'''

from tempfile import NamedTemporaryFile
import os.path
from subprocess import Popen, PIPE

import numpy
from pandas import DataFrame

from variation.matrixwithmeta import (CLASSIFICATION_COL, INDIVIDUALS_IN_ROWS,
                                      PLOIDY, BITS_PER_ALLELE, ALLELE_CODING,
                                      DISTANCE, MatrixWithMeta)
from variation.inout.genetic import (GenotypeCodec, DEFAULT_PLOIDY,
                                     DEF_BITS_PER_ALLELE)
from variation.utils import get_binary_path

AVAILABLE_DISTANCES = {
     'shared_allele': ('DAS',
                       'shared allele distance (Chakraborty et Jin., 1993)'),
     'nei_minimum': ('Dm', 'Nei, minimum genetic distance, Dm (Nei,1987)'),
     'nei_standard': ('Ds', 'Nei, standard genetic distance, Ds (Nei, 1987)'),
     'cavalli': ('Dc', 'Cavalli-Sforza and Edwards, Dc (1967)'),
     'nei_da': ('DA', 'Nei et als, DA (1983)'),
     'fst': ('Fst', 'Latter, Fst (1972)'),
     'prevosti': ('Cp', 'Prevosti et al.s, Cp (1975)'),
     'roger': ('Dr', 'Roger s, Dr (1972)'),
     'reynolds_unweighted': ('Dru', 'Reynolds J. unweighted, Dru (1983)'),
     'reynolds_weighted': ('Drw', 'Reynolds J. weighted, Drw (1983)'),
     'reynolds_least_squares': ('Drl',
                                'Reynolds J. least squares, Drl (1983)'),
     'mu2': ('dmu2', 'Goldstein et al., dmu2 (1995a)'),
     'asd': ('ASD',
             'Average Square Distance ( ASD , Goldstein, Slatkin 1995)'),
     'shriver': ('Dsw', 'Shriver et al s, Dsw (1995)'),
     'zhivotovsky': ('Dr', 'Lev A. Zhivotovsky, DR (1999)')
}

DISTANCE_CODES = {'Dm': 1, 'Ds': 2, 'Dc': 3, 'Da': 4, 'DAS': 5, 'dmu2': 6,
                  'Fst': 7, 'Cp': 8, 'Dr': 9, 'ASD': 10, 'Dsw': 11, 'DR': 12,
                  'Dru': 13, 'Drw': 14, 'Drl': 15}

MISSINGVAL = '0'
ALLELE_STR_LEN = 2
ALLELE_SEP = ' '


def create_genotype_file(genotypes, fhand=None, individuals=None):
    'It creates a populations genotype file'
    if fhand is None:
        fhand = NamedTemporaryFile(suffix='.pop')

    try:
        project_name = os.path.basename(fhand.name)
    except AttributeError:
        project_name = 'genepop file'
    fhand.write('%s\n' % project_name)

    # populations
    if individuals:
        class_col = individuals.meta[CLASSIFICATION_COL]
        populations = list(set(individuals.data[class_col]))
        populations.sort()
    else:
        populations = []

    # markers
    if genotypes.meta[INDIVIDUALS_IN_ROWS]:
        marker_names = genotypes.data.columns
    else:
        marker_names = genotypes.data.index

    for marker in marker_names:
        fhand.write(marker + '\n')

    if populations:
        for population in populations:
            _write_population(fhand, population, genotypes, individuals)
    else:
        _write_population(fhand, None, genotypes)
    fhand.flush()
    return fhand


class PopGeneCodec(GenotypeCodec):
    'It returns the int coded genotypes'
    def __init__(self, ploidy=DEFAULT_PLOIDY,
                 bits_per_allele=DEF_BITS_PER_ALLELE,
                 allele_splitter='default_allele_splitter',
                 alleles_coding=None):
        'It inits the decoder'
        if ploidy != 2:
            msg = 'Genotype format cannot deal with ploidies different than 2'
            raise ValueError(msg)
        self.max_allele = int(ALLELE_STR_LEN * '9')
        super(PopGeneCodec, self).__init__(ploidy=ploidy,
                                           bits_per_allele=bits_per_allele,
                                           allele_splitter=allele_splitter,
                                           alleles_coding=alleles_coding)

    def _allele_to_popgene(self, allele):
        'It codes one allele to the popgene format'
        if allele > self.max_allele:
            msg = 'allele coded by number {:i}, but it cannot be higher than '
            msg += str(self.max_allele)
            msg = msg.format(allele)
            raise RuntimeError(msg)
        al_fmt = '{:0' + str(ALLELE_STR_LEN) + 'd}'
        return al_fmt.format(allele)

    def decode_to_popgene(self, genotype):
        'It returns the popgene coded genotype for one individual'
        genotype = self.decode_to_ints(genotype)
        if genotype is None:
            return str(MISSINGVAL) * ALLELE_STR_LEN * self.ploidy
        else:
            genotype = [self._allele_to_popgene(allele) for allele in genotype]
            return ''.join(genotype)


def _write_population(fhand, pop_name, genotypes, individuals=None):
    'It writes the individuals for one population in genepop format'
    populations_fmt = True

    indis_in_rows = genotypes.meta[INDIVIDUALS_IN_ROWS]
    meta = genotypes.meta
    genotypes = genotypes.data

    if indis_in_rows:
        indis_in_genotypes = genotypes.index
        markers = genotypes.columns
    else:
        indis_in_genotypes = genotypes.columns
        markers = genotypes.index

    if pop_name is None:
        pop_name = 'all_individuals'
        indis = indis_in_genotypes
    else:
        class_col = individuals.meta[CLASSIFICATION_COL]
        individuals = individuals.data
        indis_in_pop = individuals.index[individuals[class_col] == pop_name]
        # some individuals might have passport data but not genotype
        indis = set(indis_in_genotypes).intersection(set(indis_in_pop))

    if populations_fmt:
        fhand.write('POP %s\n' % pop_name)
    else:
        fhand.write('POP\n')

    codec = PopGeneCodec(ploidy=meta[PLOIDY],
                         bits_per_allele=meta[BITS_PER_ALLELE],
                         alleles_coding=meta[ALLELE_CODING])

    allele_sep = ALLELE_SEP
    for indi in indis:
        if indi not in indis_in_genotypes:

            continue
        # pylint: disable=C0301
        if indis_in_rows:
            indi_genotype = [codec.decode_to_popgene(genotypes.get_value(indi, m)) for m in markers]
        else:
            indi_genotype = [codec.decode_to_popgene(genotypes.get_value(m, indi)) for m in markers]
        indi_genotype = allele_sep.join(indi_genotype)
        if populations_fmt:
            name_for_line = indi
        else:
            name_for_line = pop_name
        fhand.write('%s, %s\n' % (name_for_line, indi_genotype))


def codominant_distance(genotypes, method='nei_standard'):
    'It calculates genetic distances between individuals'
    return _calculate_distances(genotypes, between_indis=True, method=method)


def codominant_population_distance(genotypes, individuals,
                                   method='nei_standard'):
    'It calculates the distances between populations by using populations'
    return _calculate_distances(genotypes, between_indis=False,
                                individuals=individuals, method=method)


def _calculate_distances(genotypes, between_indis, individuals=None,
                         method='nei_standard'):
    'It calculates the distances using populations'

    if not between_indis and individuals is None:
        msg = 'Population distance require population individual information'
        raise ValueError(msg)
    geno_fhand = create_genotype_file(genotypes, individuals=individuals)

    dist_fhand = NamedTemporaryFile(suffix='.dist')

    stdin = ''
    if between_indis:
        stdin += '1\n'  # individual distances
    else:
        stdin += '2\n'  # group distances

    stdin += geno_fhand.name + '\n'

    stdin += '1\n'  # distance
    #stdin += '2\n'  #tree with no boot
    #stdin += '3\n'  #boot on individuals

    stdin += dist_fhand.name + '\nY\n'

    try:
        distance = AVAILABLE_DISTANCES[method][0]
    except:
        msg = 'Unknown distance method (' + method
        msg += '), available distances for codominant '
        msg += 'data are: '
        msg += ', '.join(sorted(AVAILABLE_DISTANCES.viewkeys()))
        raise ValueError(msg)

    if distance in DISTANCE_CODES:
        dist_code = DISTANCE_CODES[distance]
    else:
        raise ValueError('Unknown distance: ' + distance)

    stdin += '%i\n' % dist_code
    stdin += '0\n'
    cmd = [get_binary_path('populations')]
    process = Popen(cmd, stdout=PIPE, stderr=PIPE, stdin=PIPE)
    stdout, stderr = process.communicate(stdin)
    retcode = process.returncode
    if retcode:
        msg = 'There was a problem running population\n'
        msg += 'stdout: ' + stdout
        msg += 'stderr: ' + stderr
        raise RuntimeError(msg)

    distances = _parse_distance_file(open(dist_fhand.name))
    return distances


def _parse_distance_file(fhand):
    'It parses a populations distance file'

    in_matrix = False
    names = []
    distances = []
    for line in fhand:
        if line.startswith('#'):
            in_matrix = True
            continue
        if not in_matrix:
            continue
        items = line.strip().split()
        names.append(items.pop(0))
        # pylint: disable=W0141
        items = map(float, items)
        distances.append(items)
    distances = numpy.array(distances, dtype=numpy.float_)
    dist = DataFrame(distances, index=names, columns=names)
    dist = MatrixWithMeta(dist)
    dist.kind = DISTANCE
    return dist
