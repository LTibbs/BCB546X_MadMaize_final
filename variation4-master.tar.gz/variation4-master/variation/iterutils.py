
from __future__ import division


def rolling_window(series, window_width, overlapping_windows=False):
    '''Given a series it generates the items in a rolling window.

    The first window will start at the first position.
    The windows will span [position, position + window_width[.
    If in a particular window there are no items it won't be generated.

    Overlapping windows are created using as a starting position the
    middle point of the previous window
    '''

    step = window_width
    positions = series.values
    n_items = len(positions)
    if not n_items:
        raise StopIteration

    max_pos = positions.max()

    win = float(positions[0]), float(positions[0] + step)
    while win[0] <= max_pos:
        win_items = series[(series.values >= win[0]) &
                           (series.values < win[1])].index
        win_items = win_items.tolist()
        if win_items:
            yield (win, win_items)
        if overlapping_windows:
            medium_point = (win[0] + win[1]) / 2
            win = medium_point, medium_point + step
        else:
            win = float(win[1]), float(win[1] + step)


def count_contiguous_items(items):
    '''It counts how many times an item is repeated in the sequence.

    e.g ['a', 'a', 'b', 'a'] -> [('a', 2'), ('b', 1), ('a', 1)]
    '''
    prev_item = None
    count = 0
    for item in items:
        if prev_item is None:
            prev_item = item
            count += 1
        elif prev_item == item:
            count += 1
        else:
            yield prev_item, count
            prev_item = item
            count = 1
    else:
        if count:
            yield item, count
