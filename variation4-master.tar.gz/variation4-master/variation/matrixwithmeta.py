'''
Created on 29/02/2012

@author: jose

A pandas DataFrame class with some extra metadata.
'''

# TODO divide MatrixWithMeta into a SeriesWithMeta and MatrixWithMeta that
# intherit from KlassWithMeta

#notes for python 3
#from __future__ import division
#open file 'rt'
#dict .viewitems(), .viewkeys() and .viewvalues()
#str.format()

import cPickle as pickle
import array

import numpy
from scipy.spatial.distance import is_valid_dm
from pandas import DataFrame, Series

MATRIX = 'Matrix'
DISTANCE = 'Distance'
FLOAT = 'Float Matrix'
INT = 'Integer Matrix'
STR = 'Str Matrix'
BINARY = 'Binary Matrix'
CODOMINANT = 'Codominant'
MARKER_MAP = 'Marker map'

MOLECULE_COL = 'molecule_col'
LOCATION_COL = 'location_col'
LINKAGE_GROUP_COL = 'linkage_group_col'
GENETIC_LOCATION_COL = 'genetic_location_col'
GENETIC = 'genetic'
PHYSICAL = 'physical'
CLASSIFICATION_COL = 'classification_col'
GENDER_COL = 'gender_col'
SEX_CHROMOSOMES = 'sex_chromosomes'
DEF_SEX_CHROMOSOMES = ('X', 'Y')
LONGITUDE_COL = 'longitude_col'
LATITUDE_COL = 'latitude_col'
PLOIDY = 'ploidy'
BITS_PER_ALLELE = 'bits_per_allele'
ALLELE_CODING = 'allele_coding'
ALLELE_SPLITTER = 'allele_splitter'
INDIVIDUALS_IN_ROWS = 'individuals_in_rows'
LONGITUDE_COL = 'longitude'
LATITUDE_COL = 'latitude'

NUMPY = 'Numpy'
PANDAS_DATAFAME = 'pandas_dataframe'
PANDAS_SERIES = 'pandas_series'

DATAFRAME_KINDS = {MATRIX, DISTANCE, BINARY, CODOMINANT, FLOAT, INT, STR,
                   MARKER_MAP}


# I have attempted to do DataFrame(pandas.DataFrame), but it does not work
# because a lot of DataFrame methods return pandas DataFrame objects, and
# I would had to overload a lot of code.

class MatrixWithMeta(object):
    '''A class to add some metadata to a Numpy array or a pandas DataFrame.

    The data stored will be considered immutable. It it is changed it is the
    user responsibility to delete the metadata with the method delete_metadata.
    '''
    def __init__(self, data, metadata=None):
        'It inits with the data to annotate'
        self._data = data
        if metadata is None:
            metadata = {}
        self._metadata = metadata

    @property
    def data(self):
        'It returns the data'
        return self._data

    @property
    def meta(self):
        'It returns the metadata dict'
        return self._metadata

    def delete_metadata(self):
        'It deletes the metadata'
        self._metadata = {}

    def _get_kind(self):
        'It returns the kind'
        return self._metadata['kind']

    def _set_kind(self, kind):
        'It sets the kind'
        if kind == MATRIX:
            pass
        elif kind == BINARY:
            if not self.is_binary(allow_missing=True):
                msg = 'Some values are not 0, 1 or missing data'
                raise ValueError(msg)
        elif kind == DISTANCE:
            if not self.is_distance():
                msg = 'It is not a valid distance matrix'
                raise ValueError(msg)
        elif kind == FLOAT:
            if not self.is_float():
                msg = 'Some values are not float or missing data'
                raise ValueError(msg)
        elif kind == CODOMINANT:
            if not self.is_codominant():
                msg = 'The matrix is not a codominant one.'
                raise ValueError(msg)
        elif kind == MARKER_MAP:
            if not self.is_marker_map():
                msg = 'The matrix is not a Marker Map one.'
                raise ValueError(msg)
        else:
            raise NotImplementedError
        self._metadata['kind'] = kind

    kind = property(_get_kind, _set_kind)

    def __str__(self):
        'It returns a string representation'
        return str(self.data)

    @property
    def matrix_format(self):
        'It returns if the stored format is Numpy or pandas'
        try:
            # pylint: disable=W0104
            # The following statement does has an effect, it checks that the
            # values attribute exists
            self._data.values
            if isinstance(self.data, DataFrame):
                return PANDAS_DATAFAME
            elif isinstance(self.data, Series):
                return PANDAS_SERIES
            else:
                raise ValueError('Unknown object type.')
        except AttributeError:
            # The data is a Numpy array
            return NUMPY

    def _get_values(self):
        'It returns the values of the matrix, the numpy array'
        matrix_format = self.matrix_format
        if matrix_format in (PANDAS_DATAFAME, PANDAS_SERIES):
            values = self.data.values
        elif matrix_format == NUMPY:
            values = self.data
        else:
            raise NotImplementedError
        return values

    def is_codominant(self):
        'It checks that the matrix is a codominant one'
        if not self.is_int():
            return False
        expected_metadata = [PLOIDY, BITS_PER_ALLELE, ALLELE_CODING,
                             ALLELE_SPLITTER, INDIVIDUALS_IN_ROWS]
        meta = self.meta
        if any((e not in meta for e in expected_metadata)):
            return False
        return True

    def is_marker_map(self):
        'It checks that the matrix is a marker map'
        if self.is_physical_marker_map() or self.is_genetic_marker_map():
            return True
        else:
            return False

    def is_physical_marker_map(self):
        'It checks that the matrix is a marker physical map'
        expected_metadata = [MOLECULE_COL, LOCATION_COL]
        meta = self.meta
        if any((e not in meta for e in expected_metadata)):
            return False
        return True

    def is_genetic_marker_map(self):
        'It checks that the matrix is a marker physical map'
        expected_metadata = [LINKAGE_GROUP_COL, GENETIC_LOCATION_COL]
        meta = self.meta
        if any((e not in meta for e in expected_metadata)):
            return False
        return True

    def is_binary(self, allow_missing=False):
        'True if all values are 0 or 1'
        is_valid_val = numpy.vectorize(lambda x: x in (0, 1))
        values = self._get_values()
        is_binary = is_valid_val(values)

        if allow_missing:
            nan = numpy.isnan(values)
            if not numpy.all(numpy.logical_or(is_binary, nan)):
                return False
        else:
            if not numpy.all(is_binary):
                return False
        return True

    def _is_of_types(self, types):
        'True if all columns are of the given types'
        if self.matrix_format == PANDAS_DATAFAME:
            col_types = [str(t) for t in self.data.get_dtype_counts().index]
        elif self.matrix_format == PANDAS_SERIES:
            col_types = [str(self.data.values.dtype)]
        elif self.matrix_format == NUMPY:
            col_types = [str(self.data.dtype)]
        else:
            raise NotImplementedError
        for col_type in col_types:
            if not any(t in col_type for t in types):
                return False
        return True

    def is_float(self):
        'True if all values are float or NaN'
        return self._is_of_types(['int', 'float'])

    def is_distance(self):
        '''True if it is a valid distance matrix.

        It should be symmetric and it should have a 0 diagonal.
        '''
        return is_valid_dm(self._get_values())

    def is_int(self):
        'True if all values are integers'
        return self._is_of_types(['int'])

    def save(self, fhand):
        'It saves the object into a file'
        data = {'metadata': self._metadata, 'data': self._data}
        pickle.dump(data, fhand)
        fhand.flush()

    def dropna(self, axis):
        'It removes the missing data and returns a new matrix'
        data = self.data.dropna(axis=axis)
        return self.__class__(data=data, metadata=self.meta)


def load_matrix(fhand):
    '''It loads a MatrixWithMeta from the given fhand.

    It loadas pickle files created with MatrixWithMeta.save.
    '''
    data = pickle.load(fhand)
    return MatrixWithMeta(data['data'], data['metadata'])


def is_vector(object):
    if isinstance(object, basestring):
        return False
    if isinstance(object, list):
        return True
    if isinstance(object, array.array):
        return True
    if isinstance(object, numpy.ndarray):
        return True
    if isinstance(object, Series):
        return True
    return False
