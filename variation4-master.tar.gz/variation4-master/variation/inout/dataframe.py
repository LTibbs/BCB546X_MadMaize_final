
from pandas.io.parsers import read_csv

from variation.matrixwithmeta import (MatrixWithMeta, MATRIX, LONGITUDE_COL,
                                      LATITUDE_COL)
from variation.analyses.geography import lon_to_deg, lat_to_deg

NA_VALUES = ['NA', 'NAN', '-', '']  # missing data possible strings
DEFAULT_SEP = ','


def load_dataframe_csv(fhand, index_col=None, header=0, sep=DEFAULT_SEP,
                       kind=None, meta=None, **kwargs):
    'It loads a CSV file with dominant markers into a DataFrame'
    dataframe = read_csv(fhand, index_col=index_col, header=header, sep=sep,
                         na_values=NA_VALUES, **kwargs)
    data = MatrixWithMeta(dataframe)
    if kind is None:
        kind = MATRIX
    data.kind = kind
    if meta is not None:
        data.meta.update(meta)
    return data


def load_geographic_data(fhand, latitude_col, longitude_col, index_col=None,
                         header=0, sep=DEFAULT_SEP, kind=None, meta=None,
                         **kwargs):
    'It loads geographic data.'
    data = load_dataframe_csv(fhand, index_col=index_col, header=header,
                              sep=sep, kind=kind, meta=meta, **kwargs)
    dframe = data.data
    deg_lat = dframe[latitude_col].apply(lat_to_deg)
    deg_lon = dframe[longitude_col].apply(lon_to_deg)
    dframe[latitude_col] = deg_lat
    dframe[longitude_col] = deg_lon
    meta = data.meta
    meta.update({LATITUDE_COL: latitude_col,
                 LONGITUDE_COL: longitude_col})
    return MatrixWithMeta(dframe, meta)
