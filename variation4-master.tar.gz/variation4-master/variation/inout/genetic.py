'''
Created on 01/03/2012

@author: jose
'''

from warnings import warn

import numpy
from pandas import isnull, DataFrame

from variation.matrixwithmeta import (MatrixWithMeta, BINARY, CODOMINANT,
                                      MARKER_MAP, PLOIDY, INDIVIDUALS_IN_ROWS,
                                      MOLECULE_COL, LOCATION_COL,
                                      LINKAGE_GROUP_COL, GENETIC_LOCATION_COL,
                                      BITS_PER_ALLELE, ALLELE_CODING,
                                      ALLELE_SPLITTER, SEX_CHROMOSOMES,
                                      DEF_SEX_CHROMOSOMES)
from variation.inout.dataframe import (NA_VALUES, DEFAULT_SEP,
                                       load_dataframe_csv)

DEFAULT_PLOIDY = 2
DEF_BITS_PER_ALLELE = 8
GENOTYPE_SEPARATOR = ''
MISSING_INT_GENOTYPE = NA_VALUES[-2]
NULL_ALLELE = 0     # Do not change this value it is used in the internal logic
IUPAC_CODES = {'A': 'A', 'C': 'C', 'G': 'G', 'T': 'T', 'U': 'U',
                'R': ('A', 'G'), 'Y': ('C', 'T'), 'S': ('G', 'C'),
                'W': ('A', 'T'), 'K': ('G', 'T'), 'M': ('A', 'C'),
                'B': ('C', 'G', 'T'), 'D': ('A', 'G', 'T'),
                'H': ('A', 'C', 'T'), 'V': ('A', 'C', 'G'), 'N': None}


def load_dominant_genetic_csv(fhand, individuals_in_rows, index_col=None,
                              sep=DEFAULT_SEP):
    'It loads a CSV file with dominant markers into a DataFrame'
    if not isinstance(individuals_in_rows, bool):
        raise ValueError('individuals_in_rows should be a boolean')
    data = load_dataframe_csv(fhand, index_col=index_col, sep=sep)
    data.kind = BINARY
    data.meta[INDIVIDUALS_IN_ROWS] = individuals_in_rows
    return data


def create_nucleotide_string_allele_splitter(ploidy=DEFAULT_PLOIDY,
                                             missing_tag=None):

    def _default_allele_splitter(genotype):
        'Given a genotype it returns a list of alleles'
        if genotype == missing_tag:
            genotype = []
        else:
            genotype = list(genotype)
        if genotype and len(genotype) != ploidy:
            msg = str(len(genotype))
            msg += ' alleles found for a individual with ploidy '
            msg += str(ploidy)
            raise ValueError(msg)
        return genotype
    return _default_allele_splitter


default_allele_splitter = create_nucleotide_string_allele_splitter()


def create_iupac_allele_splitter(ploidy=DEFAULT_PLOIDY):
    'It creates an allele_splitter function for IUPAC coded genotypes'
    if ploidy != 2:
        msg = 'IUPAC codes are only well suited for diploid genotypes'
        raise ValueError(msg)

    def iupac_allele_splitter(genotype):
        'It expects the genotype to be encoded following the IUPAC rules'
        try:
            genotype = IUPAC_CODES[genotype.upper()]
        except KeyError:
            msg = 'Genotype "{:s}" is an unknown IUPAC code'
            msg = msg.format(genotype)
            raise ValueError(msg)
        if isinstance(genotype, basestring):
            genotype = tuple([genotype] * ploidy)
            if len(genotype) != ploidy:
                msg = str(len(genotype))
                msg += ' alleles found for a individual with ploidy '
                msg += str(ploidy)
                raise ValueError(msg)
        return genotype
    return iupac_allele_splitter


class GenotypeCodec(object):
    'It encodes and decodes genotypes as integers'
    def __init__(self, ploidy=DEFAULT_PLOIDY,
                 bits_per_allele=DEF_BITS_PER_ALLELE,
                 allele_splitter='default_allele_splitter',
                 alleles_coding=None, missing_tag=None):
        '''It inits the class.

        alleles_coding should be a dict with the alleles as keys and the
        encoding int as value, e.g. alleles['A'] = 1
        '''
        self._genotype_cache = {}
        if allele_splitter == 'default_allele_splitter':
            allele_splitter = create_nucleotide_string_allele_splitter(ploidy=ploidy)
        elif allele_splitter == 'iupac_allele_splitter':
            allele_splitter = create_iupac_allele_splitter(ploidy=ploidy)

        self.ploidy = ploidy
        self.missing_tag = missing_tag
        self._bits_per_allele = bits_per_allele
        if alleles_coding is None:
            alleles_coding = {}
            alleles_dec = {}
        else:
            alleles_dec = {v: k for k, v in alleles_coding.viewitems()}
        self._alleles_coding = alleles_coding
        self._alleles_decoding = alleles_dec    # the reciprocal to
                                                # alleles_coding al[0] = 'A'
        self._allele_splitter = allele_splitter
        self._max_int = int('1' * bits_per_allele, 2)

    @property
    def alleles_coding(self):
        'It returns the alleles coding dict'
        return self._alleles_coding

    @property
    def alleles_decoding(self):
        'It returns the alleles decoding dict'
        return self._alleles_decoding

    @property
    def bits_per_allele(self):
        return self._bits_per_allele

    def encode(self, genotype):
        'It returns a genotype for a locus and and indiviual encoded as an int'
        if isnull(genotype) or genotype == self.missing_tag:
            genotype = [0] * self.ploidy
            return self._pack_ints(genotype)
        alleles = self._allele_splitter(genotype)
        int_alleles = []
        alleles_cod = self._alleles_coding
        alleles_dec = self._alleles_decoding
        for allele in alleles:
            if allele not in alleles_cod:
                coded_allele = len(alleles_cod) + 1   # we start at one
                                                        # because 0 is for NaN
                if coded_allele > self._max_int:
                    msg = 'Too many different alleles, please allocate more '
                    msg += 'bits per allele'
                    raise ValueError(msg)
                alleles_cod[allele] = coded_allele
                alleles_dec[coded_allele] = allele
            int_alleles.append(alleles_cod[allele])
        return self._pack_ints(int_alleles)

    def _pack_ints(self, ints):
        '''It packs several ints into one.'''
        # the number of bits taken by every int to be packed.
        size_of_int = self._bits_per_allele
        # max number of integers packed
        n_ints = self.ploidy

        max_int = int('1' * size_of_int, 2)

        if n_ints is None and ints[-1] == 0:
            #if the number of ints is not given an 0 is the last int to
            #be coded, when unpacked to recover of all ints (including the
            #last 0 the number of ints should be provided
            #This should be an error in unpack_ints, but since ints are coded
            #by infinite bits in python it is not possible to know when
            #the integer ends, so we assume that the integer ends in the
            #most left 0
            msg = 'You are packing 0 withoug giving the number or ints, '
            msg += 'when decoding information might be lost'
            warn(msg)

        #all ints given should be smaller than this max
        if not all(num < max_int for num in ints):
            msg = 'Some integer to be packed is bigger than the maximum (%i)'
            msg %= max_int
            raise ValueError(msg)

        if n_ints is None:
            n_ints = len(ints)
        elif len(ints) < n_ints:
            n_ints = len(ints)
        elif len(ints) > n_ints:
            msg = 'Too many integers to pack (%i)' % len(ints)
            raise ValueError(msg)
        ints = [ints[index] << index * size_of_int for index in range(n_ints)]
        return reduce(lambda x, y: x | y, ints)

    def decode_to_ints(self, coded_genotype):
        'Given a genotype as an int it returns an int tuple or None'
        if self._genotype_cache.get(coded_genotype, None) is not None:
            return self._genotype_cache[coded_genotype]
        n_ints = self.ploidy
        size_of_int = self._bits_per_allele

        max_int = int('1' * size_of_int, 2)
        # line too long, just for once
        # pylint: disable=C0301
        ints = tuple((int(coded_genotype) >> (index * size_of_int)) & max_int for index in range(n_ints))
        if any([i == 0 for i in ints]):
            ints = None
        self._genotype_cache[coded_genotype] = ints
        return ints

    def decode_to_genotype(self, coded_genotype):
        'Given a coded genotype it returns a str genotype'
        if isnull(coded_genotype):
            return self.missing_tag
        ints = self.decode_to_ints(coded_genotype)
        if ints is None:
            return self.missing_tag
        known_alleles = self.alleles_decoding
        alleles = [known_alleles[allele] for allele in ints]
        return GENOTYPE_SEPARATOR.join(alleles)


def load_codominant_genetic_csv(fhand, individuals_in_rows, index_col=None,
                                sep=DEFAULT_SEP, ploidy=DEFAULT_PLOIDY,
                                allele_splitter='default_allele_splitter',
                                missing_tag=None, genotype_codec=None):
    '''It loads a CSV file with codominant markers into a DataFrame.

    individuals_in_rows is a boolean
    '''
    matrix = load_dataframe_csv(fhand, index_col=index_col, sep=sep)
    # apply a vectorized function to the data to convert to ints
    if genotype_codec is None:
        encoder = GenotypeCodec(ploidy=ploidy,
                                bits_per_allele=DEF_BITS_PER_ALLELE,
                                allele_splitter=allele_splitter,
                                missing_tag=missing_tag)
    else:
        encoder = genotype_codec
    enc_func = numpy.vectorize(encoder.encode)
    dframe = matrix.data.apply(enc_func, axis=1)
    dframe = dframe.fillna(NULL_ALLELE)
    dframe = dframe.astype(numpy.int32)

    matrix = MatrixWithMeta(dframe)
    matrix.meta[PLOIDY] = ploidy
    matrix.meta[BITS_PER_ALLELE] = encoder.bits_per_allele
    matrix.meta[ALLELE_CODING] = encoder.alleles_coding
    matrix.meta[ALLELE_SPLITTER] = allele_splitter
    if not isinstance(individuals_in_rows, bool):
        raise ValueError('individuals_in_rows should be a boolean')
    matrix.meta[INDIVIDUALS_IN_ROWS] = individuals_in_rows
    matrix.kind = CODOMINANT
    return matrix


def load_markers_map(fhand, molecule_col=None, location_col=None,
                     linkage_group_col=None, genetic_location_col=None,
                     sex_chromosomes=DEF_SEX_CHROMOSOMES,
                     index_col=None, sep=DEFAULT_SEP):
    '''It loads a genetic or physical map in csv format.'''
    dataframe = load_dataframe_csv(fhand, index_col=index_col, sep=sep)
    physical, genetic = False, False
    if molecule_col is not None:
        if location_col is None:
            msg = 'Physical molecule given, but not physical location'
            raise ValueError(msg)
        dataframe.meta[MOLECULE_COL] = molecule_col
        dataframe.meta[LOCATION_COL] = location_col
        float_col = dataframe.data[location_col].map(float)
        dataframe.data[location_col] = float_col
        physical = True
    if linkage_group_col is not None:
        if genetic_location_col is None:
            msg = 'Linkage group given, but not genetic location'
            raise ValueError(msg)
        dataframe.meta[LINKAGE_GROUP_COL] = linkage_group_col
        dataframe.meta[GENETIC_LOCATION_COL] = genetic_location_col
        float_col = dataframe.data[genetic_location_col].map(float)
        dataframe.data[genetic_location_col] = float_col
        genetic = True
    if not physical and not genetic:
        msg = 'No information given either for genetic or physical map'
        raise ValueError(msg)
    dataframe.meta[SEX_CHROMOSOMES] = sex_chromosomes
    dataframe.kind = MARKER_MAP
    return dataframe


def write_genetic_csv(fhand, genotypes, missing_tag=None):
    '''It writes the genotypes into a file.

    The genotypes should be a MatrixWithMeta.
    '''
    meta = genotypes.meta
    decoder = GenotypeCodec(ploidy=meta[PLOIDY],
                            bits_per_allele=meta[BITS_PER_ALLELE],
                            alleles_coding=meta[ALLELE_CODING],
                            missing_tag=missing_tag)

    str_genotypes = genotypes.data.applymap(decoder.decode_to_genotype)
    str_genotypes.to_csv(fhand, index_label=False)


def get_codec_from_genotypes(genotypes):
    meta = genotypes.meta
    genotype_codec = GenotypeCodec(ploidy=meta[PLOIDY],
                                   bits_per_allele=meta[BITS_PER_ALLELE],
                                   alleles_coding=meta[ALLELE_CODING])
    return genotype_codec

def create_dummy_marker_map(markers):
    '''It creates a dummy marker map based on a list of markers

    '''
    col1 = 'chromosome'
    col2 = 'position'
    marker_map = DataFrame(index=markers, columns=[col1, col2])
    marker_map[col1] = None
    marker_map[col2] = xrange(len(markers))
    marker_map = MatrixWithMeta(marker_map)
    marker_map.meta[MOLECULE_COL] = col1
    marker_map.meta[LOCATION_COL] = col2

    return marker_map

