'''
Created on 03/04/2012

@author: jose
'''
import unittest
from StringIO import StringIO

from variation.matrixwithmeta import CLASSIFICATION_COL
from variation.inout.genetic import load_codominant_genetic_csv
from variation.inout.dataframe import load_dataframe_csv
from variation.analyses.populations import create_genotype_file


# pylint: disable=R0201
# pylint: disable=R0904


class TestPopulations(unittest.TestCase):
    'It tests the populations software'

    def test_genepop_file(self):
        'It creates a genepop input file for populations'
        data = '''marker1,marker2,marker3,marker4,marker5,marker6
indi1,AA,CG,GG,,AA,TT
indi2,AA,CG,GG,CC,AA,TT
indi3,GG,AA,AC,CC,GG,AT
indi4,GG,AA,AC,CC,GG,AT
indi5,GC,AA,AC,CC,GG,AA
'''
        fhand = StringIO(data)
        data = load_codominant_genetic_csv(fhand, individuals_in_rows=True)
        geno_fhand = create_genotype_file(data)
        content = open(geno_fhand.name).read()
        assert 'POP all_individuals\nindi' in content
        assert 'indi1, 0101 0203 0303 0000 0101 0404' in content

        # with population data
        indis = 'population,gender\n'
        indis += 'indi5,pop1,M\n'
        indis += 'indi2,pop1,F\n'
        indis += 'indi3,pop2,F\n'
        indis += 'indi4,pop2,F\n'
        indis += 'indi1,pop2,F\n'
        indis = StringIO(indis)
        indis = load_dataframe_csv(indis,
                                   meta={CLASSIFICATION_COL: 'population'})
        geno_fhand = create_genotype_file(data, individuals=indis)
        content = open(geno_fhand.name).read()
        assert 'marker1\nmarker2\nmarker3\nmarker4\nmarker5\n' in content
        assert 'indi5, 0302 0101 0102 0202 0303 0101' in content
        assert 'POP pop1\nindi' in content


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_load_dominant_genetic']
    unittest.main()
