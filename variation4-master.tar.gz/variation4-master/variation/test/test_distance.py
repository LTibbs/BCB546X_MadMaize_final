'''
Created on 01/03/2012

@author: jose
'''

import unittest
from StringIO import StringIO
import math

import numpy
from scipy.spatial.distance import squareform

from pandas import DataFrame, Series

from variation.matrixwithmeta import (MatrixWithMeta, BINARY, DISTANCE,
                                      CLASSIFICATION_COL)
from variation.inout.genetic import load_codominant_genetic_csv
from variation.inout.dataframe import load_dataframe_csv
from variation.analyses.distance import (binary_matrix_distance,
                                         codominant_distance,
                                         codominant_population_distance,
                                         PopDistances,
                                         pairwise_individual_genetic_distance,
                                         pairwise_geographic_distance,
                                         correlation_distance_matrices)
from variation.analyses.matrix_tools import transpose_genotypes

# pylint: disable=R0201
# pylint: disable=R0904


def floats_are_equal(num1, num2, ratio=0.01):
    'Given two numbers it returns True if they are similar'
    if num1 == 0.0:
        if num2 == 0.0:
            return True
        else:
            return False
    log1 = math.log(float(num1))
    log2 = math.log(float(num2))
    return abs(log1 - log2) < ratio


def lists_of_floats_are_equal(floats1, floats2, ratio=0.01):
    return all([floats_are_equal(num1, num2, ratio)for num1, num2 in zip(floats1, floats2)])


class TestDistance(unittest.TestCase):
    'It tests the row matrix distance calculations'
    def test_binary_matrix_dist(self):
        'It tests the distances between matrixes with 1 and 0'
        matrix = DataFrame({'row1': [1, 1, 1, 1],
                            'row2': [0, 1, 0, 0],
                            'row3': [0, 1, 1, 1]})
        matrix = matrix.T
        matrix = MatrixWithMeta(matrix)
        matrix.kind = BINARY
        distance = binary_matrix_distance(matrix, method='jaccard')
        expected = [[0., 0.75, 0.25],
                    [0.75, 0., 0.66666667],
                    [0.25, 0.66666667, 0.]]
        assert numpy.allclose(distance.data, expected)
        assert distance.kind == DISTANCE
        assert all(distance.data.index == ['row1', 'row2', 'row3'])

        matrix = DataFrame({'row1': [1, 0, 0, 1, 0, 1, 0, 0],
                            'row2': [0, 1, 0, 1, 0, 1, 1, 0]})
        matrix = matrix.T
        matrix = MatrixWithMeta(matrix)
        matrix.kind = BINARY
        distance = binary_matrix_distance(matrix, method='dice')
        expected = [[0., 0.428571],
                    [0.428571, 0.]]
        assert numpy.allclose(distance.data, expected)

    def test_codominant_matrix_dist(self):
        'It calculates genetic distances for codominant data'
        data = '''marker1,marker2,marker3,marker4,marker5,marker6
indi1,AA,CG,GG,,AA,TT
indi2,AA,CG,GG,CC,AA,TT
indi3,GG,AA,AC,CC,GG,AT
indi4,GG,AA,AC,CC,GG,AT
'''
        fhand = StringIO(data)
        data = load_codominant_genetic_csv(fhand, individuals_in_rows=True)
        dist = codominant_distance(data)
        assert all(dist.data.index == ['indi1', 'indi2', 'indi3', 'indi4'])
        expected = [[0.00000, 0.00000, 2.13833, 2.13833],
                    [0.00000, 0.00000, 1.25163, 1.25163],
                    [2.13833, 1.25163, 0.00000, 0.00000],
                    [2.13833, 1.25163, 0.00000, 0.00000]]
        assert numpy.allclose(dist.data, expected)

        # with population data
        indis = 'population,gender\n'
        indis += 'indi5,pop1,M\n'
        indis += 'indi2,pop1,F\n'
        indis += 'indi3,pop2,F\n'
        indis += 'indi4,pop2,F\n'
        indis += 'indi1,pop2,F\n'
        indis = StringIO(indis)
        indis = load_dataframe_csv(indis,
                                   meta={CLASSIFICATION_COL: 'population'})
        dist = codominant_population_distance(data, indis)
        assert all(dist.data.index == ['pop1', 'pop2'])
        expected = [[0.000000, 0.437302], [0.437302, 0.000000]]
        assert numpy.allclose(dist.data, expected)

    def test_gst(self):
        data = '''marker1,marker2
indi1,AA,AT
indi2,AT,AA
indi3,AC,AA
indi4,AG,AT
indi5,TT,TT
indi6,TC,TC
indi7,TG,TG
indi8,CC,CC
indi9,CG,CG
indi10,GG,GG
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        classification = Series(['pop1'] * 5 + ['pop2'] * 5,
                                index=genotypes.data.index)
        dists = PopDistances(genotypes, classification,
                             conf_intervals_repeats=100, permutation_repeats=100,
                             min_num_individuals_per_pop=5)
        counts = dists._genotypic_counts
        n_homs = counts['n_homs']
        n_genotypes = counts['n_genotypes']
        allele_freqs = counts['allele_freqs']
        assert numpy.all(n_homs == [[2, 2], [2, 3]])
        assert numpy.all(n_genotypes == [[5, 5], [5, 5]])
        assert numpy.all(allele_freqs[1] == [[0, 0], [0.5, 0.6]])

        obs_het = dists._obs_het_by_loci()
        assert lists_of_floats_are_equal(obs_het[1], [0.6, 0.4])
        exp_het = dists._exp_het_by_loci()
        assert lists_of_floats_are_equal(exp_het[1], [0.64, 0.48])

        avg_obs_het = dists._avg_obs_het_by_loci()
        assert lists_of_floats_are_equal(avg_obs_het, [0.6, 0.5])
        hs = dists._hs_by_loci()
        assert lists_of_floats_are_equal(hs, [0.64, 0.56])
        ht = dists._ht_by_loci()
        assert list(ht) == [0.75, 0.74]

        _pop_size_harmonic_mean = dists._pop_size_harmonic_mean_by_loci()
        assert list(_pop_size_harmonic_mean) == [5, 5]

        assert round(dists.gst['value'], 3) == 0.133
        assert round(dists.nei_gst_prime['value'], 3) == 0.235
        assert round(dists.hedrick_gst_prime_prime['value'], 3) == 0.736
        assert round(dists.jost_dest['value'], 3) == 0.655

        pairwise = dists.pairwise_distances('gst')
        distance_matrix = pairwise['distance_matrix'].as_matrix()
        significance_matrix = pairwise['significance_matrix'].as_matrix()
        assert numpy.all(distance_matrix == [[0, 0.13285600636435971],
                                             [0.13285600636435971, 0]])
        assert significance_matrix[1][0] > 95

        data = '''marker1,marker2
indi1,AA,AT
indi2,AT,AA
indi3,AC,AA
indi4,AG,
indi5,TT,TT
indi6,,TC
indi7,TG,TG
indi8,CC,CC
indi9,CG,
indi10,GG,TC
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)

        genotypes = transpose_genotypes(genotypes)
        dists = PopDistances(genotypes, classification,
                             conf_intervals_repeats=100, permutation_repeats=100,
                             min_num_individuals_per_pop=5)
        counts = dists._genotypic_counts
        n_homs = counts['n_homs']
        n_genotypes = counts['n_genotypes']
        allele_freqs = counts['allele_freqs']
        assert numpy.all(n_homs == [[2, 1], [2, 3]])
        assert numpy.all(n_genotypes[1] == [5, 4])
        assert numpy.all(allele_freqs[2] == [[0.125, 0.375], [0.3, 0.375]])

        obs_het = dists._obs_het_by_loci()
        assert list(obs_het[0]) == [0.5, 0.75]
        exp_het = dists._exp_het_by_loci()
        assert lists_of_floats_are_equal(exp_het[1], [0.64, 0.46875])

        avg_obs_het = dists._avg_obs_het_by_loci()
        assert lists_of_floats_are_equal(avg_obs_het, [0.55, 0.5])
        hs = dists._hs_by_loci()
        assert lists_of_floats_are_equal(hs, [0.616, 0.531])
        ht = dists._ht_by_loci()
        assert lists_of_floats_are_equal(ht, [0.746, 0.695])

        _pop_size_harmonic_mean = dists._pop_size_harmonic_mean_by_loci()
        assert lists_of_floats_are_equal(_pop_size_harmonic_mean, [4.444, 4.0])

        assert floats_are_equal(dists.gst['value'], 0.1278)
        assert floats_are_equal(dists.nei_gst_prime['value'], 0.226)
        assert floats_are_equal(dists.hedrick_gst_prime_prime['value'], 0.688)
        assert floats_are_equal(dists.jost_dest['value'], 0.597)

        pairwise = dists.pairwise_distances('jost_dest')
        distance_matrix = pairwise['distance_matrix'].as_matrix()
        significance_matrix = pairwise['significance_matrix'].as_matrix()
        assert numpy.all(distance_matrix == [[0, 0.59684822521419822],
                                             [0.59684822521419822, 0]])
        assert significance_matrix[1][0] > 90

        data = '''marker1,marker2
indi1,AA,AT
indi2,AT,AA
indi3,AC,AA
indi4,AG,
indi5,TT,TT
indi6,,
indi7,TG,
indi8,CC,
indi9,CG,
indi10,GG,
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)

        genotypes = transpose_genotypes(genotypes)
        dists = PopDistances(genotypes, classification,
                             conf_intervals_repeats=0, permutation_repeats=0,
                             min_num_individuals_per_pop=5)
        counts = dists._genotypic_counts
        assert counts['n_genotypes'].shape == (2, 1)

    def test_jack_distances(self):

        data = '''marker1,marker2
indi1,AA,AT
indi2,AT,AA
indi3,AC,AA
indi4,AG,AT
indi5,TT,TT
indi6,TC,TC
indi7,TG,TG
indi8,CC,CC
indi9,CG,CG
indi10,GG,GG
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        classification = Series(['pop1'] * 5 + ['pop2'] * 5,
                                index=genotypes.data.index)
        dists = PopDistances(genotypes, classification,
                             conf_intervals_repeats=100, permutation_repeats=100,
                             min_num_individuals_per_pop=5)
        dists.min_num_individuals_per_pop_per_marker = 2
        assert list(dists.jackknife_pairwise_distances('gst', num_repeats=5))

    def test_pairwise_individuals_genetic_distance(self):
        data = '''marker1,marker2
indi1,AA,GG
indi2,TT,CC
indi3,AA,GG
indi4,AT,GC
indi5,AA,
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        dists = pairwise_individual_genetic_distance(genotypes)
        assert all(dists['indi1'] == [0, 1, 0, 0.5, 0])

    def test_pairwise_individuals_geographic_distance(self):
        data = ''',Longitude,Latitude
ind1,-2,2
ind2,-0.5,1.5
ind3,1.5,1.5
ind4,-0.5,0.5
ind5,0,1
ind6,3,
'''
        fhand = StringIO(data)
        locations = load_dataframe_csv(fhand, index_col=0, header=0, sep=',')
        dists = pairwise_geographic_distance(locations,
                                                    longitude_col='Longitude',
                                                       latitude_col='Latitude')
        expected = [0.0, 175.7403, 392.9524, 235.8486, 248.5687]
        assert lists_of_floats_are_equal(dists['ind1'], expected)

    def test_correlation_distance_matrices(self):
        dist_matrix1 = squareform(numpy.random.random_sample(size=10))
        dist_matrix2 = squareform(numpy.random.random_sample(size=10))

        indis = ['ind1', 'ind2', 'ind3', 'indi4', 'indi5']
        dist1 = DataFrame(dist_matrix1, index=indis, columns=indis)
        dist2 = DataFrame(dist_matrix2, index=indis, columns=indis)

        correlation = correlation_distance_matrices(dist1, dist2)
        assert correlation['mantel_p-value'] > 0

        mat1 = [[0.0000000, 0.3937326, 0.4088031, 0.6144127, 0.1854888],
                [0.3937326, 0.0000000, 0.3749446, 0.2206810, 0.5743590],
                [0.4088031, 0.3749446, 0.0000000, 0.5116772, 0.4994034],
                [0.6144127, 0.2206810, 0.5116772, 0.0000000, 0.7944601],
                [0.1854888, 0.5743590, 0.4994034, 0.7944601, 0.0000000]]

        mat2 = [[0.000000, 1.326612, 3.172921, 0.044354, 1.149193],
                [1.326612, 0.000000, 1.846309, 1.282258, 0.177419],
                [3.172921, 1.846309, 0.000000, 3.128567, 2.023728],
                [0.044354, 1.282258, 3.128567, 0.000000, 1.104839],
                [1.149193, 0.177419, 2.023728, 1.104839, 0.000000]]
        mat1 = DataFrame(mat1)
        mat2 = DataFrame(mat2)
        correlation = correlation_distance_matrices(mat1, mat2,
                                                    mantel_permutations=100000)
        assert correlation['r'] + 0.206 < 0.001
        assert correlation['mantel_p-value'] > 0.4

if __name__ == "__main__":
    #import sys; sys.argv = ['', 'TestDistance.test_gst']
    unittest.main()
