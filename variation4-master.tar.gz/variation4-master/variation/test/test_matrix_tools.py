'''
Created on 15/03/2012

@author: jose
'''

import unittest
import operator
from StringIO import StringIO

import numpy
from pandas import Series, DataFrame, Index

from variation.inout.genetic import load_markers_map
from variation.matrixwithmeta import MatrixWithMeta, INDIVIDUALS_IN_ROWS
from variation.analyses.matrix_tools import (vectors_have_same_items,
                                             vectors_have_same_items_sorted,
                                             vector_is_subset_of_others,
                                             dframes_purge_unshared_rows,
                                             matrices_purge_unshared_rows,
                                             dframe_append_columns,
                                             sorted_dframe_by_rows,
                                             sorted_dframe_by_cols,
                                             filter_matrix_rows,
                                             filter_matrix_cols,
                                             sorted_matrix_by_rows,
                                             sorted_matrix_by_cols,
                                             sorted_marker_map,
                                             sorted_matrix,
                                             hstack_dframes, vstack_dframes,
                                             transpose_genotypes)
from variation.inout.genetic import load_codominant_genetic_csv

# pylint: disable=R0201
# pylint: disable=R0904
# pylint: disable=C0111


class SeriesEqualityTest(unittest.TestCase):
    'It tests the different equalities between series'
    def test_series_equality(self):
        'It tests the different equalities between series'

        names = ['item1', 'item2', 'item3']
        elements = [i for i in range(len(names))]
        series1 = Series(elements, index=names)
        series2 = Series(elements, index=names)
        series3 = Series(elements[:-1], index=names[:-1])
        series4 = Series(elements, index=['item3', 'item2', 'item1'])

        assert vectors_have_same_items([series1, series2])
        assert not vectors_have_same_items([series1, series3, series4])

        assert vectors_have_same_items_sorted([series1, series2])
        assert not vectors_have_same_items_sorted([series1, series4])

        assert vector_is_subset_of_others(series3, [series1, series4])
        assert not vector_is_subset_of_others(series1, [series3])

    def test_index_equality(self):
        'It tests the different equalities between indexes'

        names = ['item1', 'item2', 'item3']
        series1 = Index(names)
        series2 = Index(names)
        series3 = Index(names[:-1])
        series4 = Index(['item3', 'item2', 'item1'])

        assert vectors_have_same_items([series1, series2])
        assert not vectors_have_same_items([series1, series3, series4])

        assert vectors_have_same_items_sorted([series1, series2])
        assert not vectors_have_same_items_sorted([series1, series4])

        assert vector_is_subset_of_others(series3, [series1, series4])
        assert not vector_is_subset_of_others(series1, [series3])


class MatrixManipulation(unittest.TestCase):
    'It tests the filtering of rows'
    def test_purge_non_common_rows(self):
        'We remove non common rows in dataframes'
        df1 = DataFrame(numpy.random.randn(3, 2), index=['a', 'b', 'c'])
        df2 = DataFrame(numpy.random.randn(3, 2), index=['d', 'c', 'a'])
        df1, df2 = dframes_purge_unshared_rows([df1, df2])
        assert numpy.all(df1.index == ['a', 'c'])
        assert numpy.all(df2.index == ['a', 'c'])

    def test_purge_non_common_rows_mwm(self):
        'We remove non common rows in MatrixWithMeta'
        df1 = DataFrame(numpy.random.randn(3, 2), index=['a', 'b', 'c'])
        df2 = DataFrame(numpy.random.randn(3, 2), index=['d', 'c', 'a'])
        meta1 = {'hola': 'caracola'}
        meta2 = {'to be': 'not to be'}
        mat1 = MatrixWithMeta(df1, {'hola': 'caracola'})
        mat2 = MatrixWithMeta(df2, {'to be': 'not to be'})
        mat1, mat2 = matrices_purge_unshared_rows([mat1, mat2])
        assert numpy.all(mat1.data.index == ['a', 'c'])
        assert numpy.all(mat2.data.index == ['a', 'c'])
        assert mat1.meta == meta1
        assert mat2.meta == meta2

    def test_append_colums(self):
        'It appends some columns to a DataFrame'
        df1 = DataFrame(numpy.random.randn(3, 2), index=['a', 'b', 'c'])
        series = Series(numpy.random.randn(3), index=['d', 'c', 'a'],
                           name='new_col')
        new_df = dframe_append_columns(df1, [series])
        assert new_df.shape == (2, 3)
        assert 'new_col' == new_df.columns[-1]
        assert list(sorted(new_df.index)) == ['a', 'c']

    def test_hstack(self):
        df1 = DataFrame(numpy.random.randn(3, 2), index=['a', 'b', 'c'],
                        columns=['1', '2'])
        df2 = DataFrame(numpy.random.randn(3, 2), index=['a', 'b', 'c'],
                        columns=['3', '4'])
        new_df = hstack_dframes(df1, df2)
        assert list(new_df.columns) == ['1', '2', '3', '4']
        assert list(new_df.index) == ['a', 'b', 'c']

    def test_vstack(self):
        df1 = DataFrame(numpy.random.randn(3, 2), index=['a', 'b', 'c'],
                        columns=['1', '2'])
        df2 = DataFrame(numpy.random.randn(3, 2), index=['d', 'e', 'f'],
                        columns=['1', '2'])
        new_df = vstack_dframes(df1, df2)
        assert list(new_df.columns) == ['1', '2']
        assert list(new_df.index) == ['a', 'b', 'c', 'd', 'e', 'f']

    def test_frame_sort(self):
        'It returns a sorted dataframe given a key'
        df1 = DataFrame([[10, 2], [1, 20]], index=['row1', 'row2'],
                        columns=['col1', 'col2'])
        df2 = sorted_dframe_by_rows(df1, key=operator.itemgetter(0))
        assert list(df2.index) == ['row2', 'row1']
        df3 = sorted_dframe_by_rows(df2, key=operator.itemgetter(0),
                                    reverse=True)
        assert list(df3.index) == ['row1', 'row2']
        df4 = sorted_dframe_by_rows(df2, key=operator.itemgetter(1))
        assert list(df4.index) == ['row1', 'row2']

        df5 = sorted_dframe_by_cols(df1, key=operator.itemgetter(0))
        assert list(df5.columns) == ['col2', 'col1']
        df5 = sorted_dframe_by_cols(df5, key=operator.itemgetter(0),
                                    reverse=True)
        assert list(df5.columns) == ['col1', 'col2']
        df5 = sorted_dframe_by_cols(df5, key=operator.itemgetter(1),
                                    reverse=True)
        assert list(df5.columns) == ['col2', 'col1']

    def test_matrix_sort(self):
        'It returns a sorted dataframe given a key'
        df1 = DataFrame([[10, 2], [1, 20]], index=['row1', 'row2'],
                        columns=['col1', 'col2'])
        mat1 = MatrixWithMeta(df1, metadata={'hola': 'caracola'})
        mat2 = sorted_matrix_by_rows(mat1, key=operator.itemgetter(0))
        assert list(mat2.data.index) == ['row2', 'row1']
        assert mat2.meta == {'hola': 'caracola'}
        mat3 = sorted_matrix_by_cols(mat1, key=operator.itemgetter(0))
        assert list(mat3.data.columns) == ['col2', 'col1']
        assert mat3.meta == {'hola': 'caracola'}

        # more efficient sort
        df1 = DataFrame([[10, 2, 5], [3, 20, 1], [5, 1, 0]],
                        index=['row1', 'row3', 'row2'],
                        columns=['col2', 'col1', 'col3'])
        mat1 = MatrixWithMeta(df1, metadata={'hola': 'caracola'})

        mat = sorted_matrix(mat1, by_columns='col1')
        assert list(mat.data.index) == ['row2', 'row1', 'row3']
        mat = sorted_matrix(mat1, by_index=True)
        assert list(mat.data.index) == ['row1', 'row2', 'row3']
        mat = sorted_matrix(mat1, by_rows='row1')
        assert list(mat.data.columns) == ['col1', 'col3', 'col2']
        mat = sorted_matrix(mat1, by_column_names=True)
        assert list(mat.data.columns) == ['col1', 'col2', 'col3']

    def test_map_sort(self):
        'It returns a sorted genetic map'
        map_ = 'chr,location\n'
        map_ += 'marker1,chr1,1\n'
        map_ += 'marker3,chr1,3\n'
        map_ += 'marker5,chr2,2\n'
        map_ += 'marker0,,\n'
        map_ += 'marker4,chr2,1\n'
        map_ += 'marker2,chr1,2\n'
        map_fhand = StringIO(map_)
        marker_map = load_markers_map(map_fhand, molecule_col='chr',
                                      location_col='location')
        try:
            marker_map = sorted_marker_map(marker_map)
            self.fail('ValueError expected due to missing data')
        except ValueError:
            pass

        marker_map = sorted_marker_map(marker_map.dropna(axis=0))
        expected = ['marker1', 'marker2', 'marker3', 'marker4', 'marker5']
        assert list(marker_map.data.index) == expected

    def test_filter_matrix_rows(self):
        'It tests the selection of rows in a matrix'
        df1 = DataFrame([[10, 2, 'hola'], [1, 20, 'caracola']],
                        index=['row1', 'row2'],
                        columns=['col1', 'col2', 'col3'])

        mat1 = MatrixWithMeta(df1, {'some': 'metadata'})
        mat2 = filter_matrix_rows(mat1, ['row1'])
        assert mat2.data.index == ['row1']
        assert mat2.meta == {'some': 'metadata'}
        mat6 = filter_matrix_rows(mat1, ['row1'], reverse=True)
        assert mat6.data.index == ['row2']

        mat3 = filter_matrix_rows(mat1, {'col3': 'caracola'})
        assert mat3.data.index == ['row2']
        mat7 = filter_matrix_rows(mat1, {'col3': 'caracola'}, reverse=True)
        assert mat7.data.index == ['row1']

        mat4 = filter_matrix_rows(mat1, {'col3': ['hola']})
        assert mat4.data.index == ['row1']
        mat8 = filter_matrix_rows(mat1, {'col3': ['hola']}, reverse=True)
        assert mat8.data.index == ['row2']

        mat5 = filter_matrix_rows(mat1, lambda x: x['col1'] > 5)
        assert mat5.data.index == ['row1']
        mat9 = filter_matrix_rows(mat1, lambda x: x['col1'] > 5, reverse=True)
        assert mat9.data.index == ['row2']

    def test_filter_matrix_cols(self):
        'It tests the selection of columns in a matrix'
        df1 = DataFrame([[10, 2, 'hola'], [1, 20, 'caracola']],
                        index=['row1', 'row2'],
                        columns=['col1', 'col2', 'col3'])

        mat1 = MatrixWithMeta(df1, {'some': 'metadata'})
        mat2 = filter_matrix_cols(mat1, ['col1'])
        assert mat2.data.columns == ['col1']
        assert mat2.meta == {'some': 'metadata'}
        mat6 = filter_matrix_cols(mat1, ['col1'], reverse=True)
        assert list(mat6.data.columns) == ['col2', 'col3']

        mat3 = filter_matrix_cols(mat1, {'row2': 'caracola'})
        assert mat3.data.columns == ['col3']
        mat7 = filter_matrix_cols(mat1, {'row2': 'caracola'}, reverse=True)
        assert list(mat7.data.columns) == ['col1', 'col2']

        mat4 = filter_matrix_cols(mat1, {'row1': ['hola']})
        assert mat4.data.columns == ['col3']
        mat8 = filter_matrix_cols(mat1, {'row1': ['hola']}, reverse=True)
        assert list(mat8.data.columns) == ['col1', 'col2']

        mat5 = filter_matrix_cols(mat1, lambda x: x['row1'] == 10)
        assert list(mat5.data.columns) == ['col1']
        mat9 = filter_matrix_cols(mat1, lambda x: x['row1'] == 10, reverse=True)
        assert list(mat9.data.columns) == ['col2', 'col3']

    def test_genotype_transposition(self):
        'It transposes genotype matrixes'

        data = '''marker1,marker2,marker3,marker4,marker5,marker6
indi1,AA,CG,GG,,AA,TT
indi2,AA,CG,GG,CC,AA,TT
indi3,GG,AA,AC,CC,GG,AT
indi4,GG,AA,AC,CC,GG,AT
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        genotypes = transpose_genotypes(genotypes)
        assert list(genotypes.data.index) == ['marker1', 'marker2', 'marker3',
                                              'marker4', 'marker5', 'marker6']
        assert list(genotypes.data.columns) == ['indi1', 'indi2', 'indi3',
                                                'indi4']
        assert not genotypes.meta[INDIVIDUALS_IN_ROWS]

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'MatrixManipulation.test_map_sort']
    unittest.main()
