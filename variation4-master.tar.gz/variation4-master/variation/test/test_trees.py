
import unittest

from pandas import DataFrame

from variation.analyses.trees import calc_nj, calc_cophenetic_corr

# pylint: disable=R0201
# pylint: disable=R0904
# pylint: disable=C0111


class NjTest(unittest.TestCase):
    def test_nj_tree(self):
        dists = DataFrame({'a': [0, 7, 11, 14], 'b': [7, 0, 6, 9],
                           'c': [11, 6, 0, 7], 'd': [14, 9, 7, 0]})
        dists.index = ['a', 'b', 'c', 'd']
        tree = calc_nj(dists)
        assert '(b,a)' in tree.getNewick(with_distances=False)

    def test_boot_nj_tree(self):
        dists = DataFrame({'a': [0, 7, 11, 14], 'b': [7, 0, 6, 9],
                           'c': [11, 6, 0, 7], 'd': [14, 9, 7, 0]})
        dists.index = ['a', 'b', 'c', 'd']
        boot_dists = [dists] * 10
        boot_dists = iter(boot_dists)
        tree = calc_nj(dists, boot_dists)
        assert '(b,a)' in tree.getNewick()
        assert '100' in tree.getNewick(with_boot=True)

    def test_cophenetic_corr(self):
        dists = DataFrame({'a': [0, 7, 10, 14], 'b': [7, 0, 6, 9],
                           'c': [10, 6, 0, 7], 'd': [14, 9, 7, 0]})
        dists.index = ['a', 'b', 'c', 'd']
        tree = calc_nj(dists)
        correlation = calc_cophenetic_corr(dists, tree)
        assert round(correlation['corr_coef'], 3) == 0.997
        assert correlation['p-value'] - 0.000013 < 0.01

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'PlotTest.test_plot_matrix']
    unittest.main()
