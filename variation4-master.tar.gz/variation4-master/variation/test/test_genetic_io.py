'''
Created on 01/03/2012

@author: jose
'''

import unittest
from StringIO import StringIO

import numpy

from variation.matrixwithmeta import (BINARY, CODOMINANT, LOCATION_COL, PLOIDY,
                                      BITS_PER_ALLELE, ALLELE_CODING)
from variation.inout.genetic import (load_dominant_genetic_csv,
                                     load_codominant_genetic_csv,
                                     GenotypeCodec,
                                     create_iupac_allele_splitter,
                                     load_markers_map,
                                     write_genetic_csv)

# pylint: disable=R0201
# pylint: disable=R0904


class TestLoadGenetic(unittest.TestCase):
    'It tests the loading of Genetic data'

    def test_load_dominant_genetic(self):
        'It loads dominant genetic data'
        data = '''acc\taflp1\taflp2
acc1\t1\t1
acc2\t0\t0
'''
        fhand = StringIO(data)
        data = load_dominant_genetic_csv(fhand, individuals_in_rows=True,
                                         index_col=0, sep=None)
        assert data.is_binary
        assert data.data['aflp1'][0] == 1
        assert data.kind == BINARY

        data = '''aflp1,aflp2
acc1,1,1
acc2,0,0
'''
        fhand = StringIO(data)
        data = load_dominant_genetic_csv(fhand, individuals_in_rows=True)
        assert data.data['aflp1'][0] == 1
        assert data.kind == BINARY

        #missing data
        data = '''aflp1,aflp2
acc1,,1
acc2,1,0
'''
        fhand = StringIO(data)
        data = load_dominant_genetic_csv(fhand, individuals_in_rows=True)
        assert numpy.isnan(data.data['aflp1'][0])
        assert data.kind == BINARY

    def test_load_codominant_genetic(self):
        'It loads codominant genetic data.'
        data = '''marker1,marker2,marker3
indi1,TA,CG,
indi2,AA,CG,GG
indi3,GG,CC,failed
'''
        fhand = StringIO(data)
        data = load_codominant_genetic_csv(fhand, individuals_in_rows=True,
                                           missing_tag='failed')
        assert PLOIDY in data.meta
        assert BITS_PER_ALLELE in data.meta
        assert data.kind == CODOMINANT
        assert set(data.meta[ALLELE_CODING].viewkeys()) == {'A', 'C', 'T',
                                                            'G'}
        meta = data.meta
        decoder = GenotypeCodec(ploidy=meta[PLOIDY],
                                bits_per_allele=meta[BITS_PER_ALLELE],
                                alleles_coding=meta[ALLELE_CODING],
                                missing_tag='-')
        ints = [decoder.decode_to_ints(g) for g in data.data.values.flat]
        assert ints == [(1, 2), (3, 4), None, (2, 2), (3, 4), (4, 4), (4, 4),
                        (3, 3), None]
        expected = ['TA', 'CG', '-', 'AA', 'CG', 'GG', 'GG', 'CC', '-']
        str_genos = data.data.applymap(decoder.decode_to_genotype).values.flat
        str_genos = list(str_genos)
        assert expected == str_genos

        #now an IUPAC coded example
        genotypes = 'indi1,indi2,indi3\n'
        genotypes += 'marker1,A,M,C\n'
        genotypes += 'marker2,S,C,failed\n'
        genotypes_fhand = StringIO(genotypes)
        allele_splitter = create_iupac_allele_splitter()
        data = load_codominant_genetic_csv(genotypes_fhand,
                                           allele_splitter=allele_splitter,
                                           individuals_in_rows=False,
                                           missing_tag='failed')
        meta = data.meta
        assert data.kind == CODOMINANT
        decoder = GenotypeCodec(ploidy=meta[PLOIDY],
                                bits_per_allele=meta[BITS_PER_ALLELE],
                                alleles_coding=meta[ALLELE_CODING],
                                missing_tag='-')
        str_genos = data.data.applymap(decoder.decode_to_genotype).values.flat
        expected = ['AA', 'AC', 'CC', 'GC', 'CC', '-']
        assert numpy.all(expected == str_genos)

    def test_write_genetic_csv(self):
        'It writes genetic data to a csv.'
        data = '''marker1,marker2,marker3
indi1,TA,CG,-
indi2,AA,CG,GA
indi3,GG,CC,-
'''
        fhand = StringIO(data)
        data = load_codominant_genetic_csv(fhand, individuals_in_rows=True,
                                           missing_tag='-')
        out_fhand = StringIO()
        write_genetic_csv(out_fhand, data, missing_tag='-')
        assert fhand.getvalue() == out_fhand.getvalue()

    def test_load_markers_map(self):
        'It loads a genetic or physical map'
        map_ = 'chr,location\n'
        map_ += 'marker1,chr1,1\n'
        map_ += 'marker2,chr2,3\n'
        map_ += 'marker3,,\n'
        map_fhand = StringIO(map_)
        data = load_markers_map(map_fhand, molecule_col='chr',
                                location_col='location')
        assert data.meta[LOCATION_COL] == 'location'

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'TestLoadGenetic.test_write_genetic_csv']
    unittest.main()
