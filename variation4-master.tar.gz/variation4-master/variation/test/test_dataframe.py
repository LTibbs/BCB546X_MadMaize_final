'''
Created on 01/03/2012

@author: jose
'''
import unittest
import tempfile
from cStringIO import StringIO

from pandas import DataFrame

from variation.matrixwithmeta import (BINARY, MatrixWithMeta, load_matrix,
                                      LONGITUDE_COL)
from variation.inout.dataframe import  load_geographic_data

# pylint: disable=R0201
# pylint: disable=R0904


class TestMatrixWithDataIO(unittest.TestCase):
    'It tests the loading and saving of MatrixWithData'
    def test_matrixwithdata_io(self):
        'It saves and loads MatrixWithData'
        matrix = DataFrame({'col1': [1, 1, 1, 1],
                            'col2': [0, 1, 0, 0],
                            'col3': [0, 1, 1, 1]})
        matrix = MatrixWithMeta(matrix)
        matrix.kind = BINARY

        fhand = tempfile.TemporaryFile()
        matrix.save(fhand)
        fhand.seek(0)
        loaded_matrix = load_matrix(fhand)
        assert all(loaded_matrix.data.index == [0, 1, 2, 3])
        assert loaded_matrix.kind == BINARY


class TestPassportDataInput(unittest.TestCase):
    'It loads passport data with longitudes and latitudes'
    def test_geographic_data_loading(self):
        'It loads CSVs with geographic data.'
        data = '''lat,lon,esp
indi1,6000--N,0600000W,
indi2,500010N,0600000W,esp1
indi3,3000--N,0501000W,esp2
'''
        fhand = StringIO(data)
        data = load_geographic_data(fhand, latitude_col='lat',
                                    longitude_col='lon')
        assert int(data.data['lon'][0]) == -60
        assert data.meta[LONGITUDE_COL] == 'lon'

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_metadata']
    unittest.main()
