
import unittest
from StringIO import StringIO
from tempfile import NamedTemporaryFile

from pandas import Series

from variation.analyses.adze import (_create_inputfile, _create_parmfile,
                                     do_rarefaction)
from variation.inout.genetic import load_codominant_genetic_csv


class AdzeTest(unittest.TestCase):

    def test_input_files(self):
        data = '''marker1,marker2
indi1,AA,AT
indi2,AT,AA
indi3,AC,AA
indi4,AG,AT
indi5,TT,TT
indi6,TC,TC
indi7,TG,TG
indi8,CC,
indi9,CG,CG
indi10,GG,GG
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        classification = Series(['pop2'] * 5 + ['pop1'] * 5,
                                index=genotypes.data.index)
        input_fhand = NamedTemporaryFile()
        params = _create_inputfile(input_fhand, genotypes, classification)
        input_fhand.seek(0)
        assert 'marker1 marker2' in input_fhand.readline()
        assert 'indi6 pop1 2 2' in input_fhand.readline()
        assert 'indi6 pop1 3 3' in input_fhand.readline()

        input_fhand = NamedTemporaryFile()
        dir_path = 'dir_path'
        _create_parmfile(input_fhand, params,
                         tolerance=0.5, richness_out_fpath='rich.txt',
                         private_out_fpath='private.txt')
        input_fhand.seek(0)
        parmfile = input_fhand.read()
        assert 'DATA_LINES 20' in parmfile

    def test_rarefaction(self):
        data = '''marker1,marker2
indi1,AA,AT
indi2,AT,AA
indi3,AC,AA
indi4,AG,AT
indi5,TT,TT
indi6,TC,TC
indi7,TG,TG
indi8,CC,
indi9,CG,CG
indi10,GG,GG
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        classification = Series(['pop2'] * 5 + ['pop1'] * 5,
                                index=genotypes.data.index)
        results = do_rarefaction(genotypes, classification)
        assert results['allelic_richness'].shape == (9,2)
        assert results['private_alleles'].iloc[6,0] == 1.2

if __name__ == "__main__":
    unittest.main()
