import unittest
import tempfile

import numpy
from pandas import DataFrame, Series

from variation.plot import (scatter_groups, histogram, scatter_series,
                            stacked_bars, get_scatter_groups_from_matrix,
                            geographic_map, plot_matrix)

# pylint: disable=R0201
# pylint: disable=R0904


def _create_normal_distrib(n_distribs, n_draws, mean=0, std_dev=1):
    'It creates random normal distributions that end up in columns'
    distrib = numpy.random.normal(mean, std_dev, (n_draws, n_distribs))
    row_names = ['row_{:d}'.format(i) for i in range(1, n_draws + 1)]
    col_names = ['col_{:d}'.format(i) for i in range(1, n_distribs + 1)]
    distrib = DataFrame(distrib, index=row_names, columns=col_names)
    return distrib


class PlotTest(unittest.TestCase):
    'It tests the plotting'
    def test_prepare_scatter(self):
        'We prepare the scatter of a matrix'
        xys = _create_normal_distrib(2, 20)
        markers = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 0]]
        colors = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 1]]
        xys = DataFrame({'xs': xys.ix[:, 0], 'ys': xys.ix[:, 1],
                         'colors': colors, 'markers': markers})
        groups = get_scatter_groups_from_matrix(xys, x_col='xs', y_col='ys',
                                                marker_col='markers',
                                                color_col='colors')
        assert 'color' in groups[0]
        assert 'marker' in groups[0]
        assert 'x' in groups[0]
        assert 'y' in groups[0]
        assert 'egt0_lt0' in [g['label'] for g in groups]

        # with some missing data in the colors
        xys = _create_normal_distrib(2, 20)
        colors = [1] * 10 + [None] * 10
        xys = DataFrame({'xs': xys.ix[:, 0], 'ys': xys.ix[:, 1],
                         'colors': colors, 'markers': markers})
        groups = get_scatter_groups_from_matrix(xys, x_col='xs', y_col='ys',
                                                color_col='colors')

    def test_scatter(self):
        'It plots an scatter'

        # a simple plot
        xys = _create_normal_distrib(2, 20)

        # a plot with series in the markers
        markers = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 0]]
        markers = Series(markers, index=xys.index)
        colors = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 1]]
        colors = Series(colors, index=xys.index)

        matrix = DataFrame({'xs': xys.ix[:, 0], 'ys': xys.ix[:, 1],
                            'colors': colors, 'markers': markers})
        groups = get_scatter_groups_from_matrix(matrix, x_col='xs', y_col='ys',
                                                marker_col='markers',
                                                color_col='colors')
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_groups(groups, fhand, labels=True)
        #raw_input(fhand.name)

        # a simple plot
        groups = [{'x': xys.ix[:, 0], 'y': xys.ix[:, 1]}]
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_groups(groups, fhand)
        # raw_input(fhand.name)

        # a simple plot with colors
        groups = [{'x': xys.ix[:, 0], 'y': xys.ix[:, 1],
                   'color': xys.ix[:, 1]}]
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_groups(groups, fhand)
        #raw_input(fhand.name)

    def test_plot_lines(self):

        # a simple plot
        xys = _create_normal_distrib(2, 20)

        # a plot with series in the markers
        markers = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 0]]
        markers = Series(markers, index=xys.index)
        colors = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 1]]
        colors = Series(colors, index=xys.index)

        matrix = DataFrame({'xs': xys.ix[:, 0], 'ys': xys.ix[:, 1],
                            'colors': colors, 'markers': markers,
                            'y_error_bars_up': abs(xys.ix[:, 0] / 5),
                            'y_error_bars_low': abs(xys.ix[:, 0] / 10)})
        groups = get_scatter_groups_from_matrix(matrix, x_col='xs', y_col='ys',
                                               marker_col='markers',
                                               color_col='colors',
                                            y_error_bars_col='y_error_bars_up')
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_groups(groups, fhand, labels=True, plot_lines=True)

        groups = get_scatter_groups_from_matrix(matrix, x_col='xs', y_col='ys',
                                               marker_col='markers',
                                               color_col='colors',
                                           y_error_bars_col='y_error_bars_low',
                                      y_error_bars_col_upper='y_error_bars_up')
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_groups(groups, fhand, labels=True, plot_lines=False)
        #raw_input(fhand.name)

    def test_simple_scatter(self):
        'It plots an scatter'

        # a simple plot
        xys = _create_normal_distrib(2, 20)
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_series(xys['col_1'], xys['col_2'], fhand, labels=True)
        #raw_input(fhand.name)

        # with color
        xys = _create_normal_distrib(2, 20)
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        scatter_series(xys['col_1'], xys['col_2'], fhand,
                       color=list(xys['col_1']), labels=True)
        #raw_input(fhand.name)

    def test_histogram(self):
        'It plots an scatter'

        data = _create_normal_distrib(1, 30)
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        histogram(data, fhand)
        # raw_input(fhand.name)

    def test_stacked_cols(self):
        'It plots stacked columns'
        n_indis = 10
        matrix = _create_normal_distrib(4, n_indis, mean=5, std_dev=0.5)
        matrix = matrix.applymap(lambda x: x if x > 0 else 0)
        classification = ['group{:d}'.format(i // 3) for i in range(n_indis)]
        classification = Series(classification)
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        stacked_bars(matrix, fhand, classification=classification)
        #raw_input('fichero:' + fhand.name)

        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        err_matrix = matrix / 10
        err_matrix2 = matrix / 20
        stacked_bars(matrix, fhand, classification=classification,
                     y_error_bars_lower=err_matrix,
                     y_error_bars_upper=err_matrix2)
        #raw_input('fichero:' + fhand.name)

    def test_geographic_map(self):
        # a simple map
        xys = _create_normal_distrib(2, 20, mean=0, std_dev=20)

        # a plot with series in the markers
        markers = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 0]]
        markers = Series(markers, index=xys.index)
        colors = ['lt0' if x < 0 else 'egt0' for x in xys.ix[:, 1]]
        colors = Series(colors, index=xys.index)

        matrix = DataFrame({'longitude': xys.ix[:, 0],
                            'latitude': xys.ix[:, 1],
                            'colors': colors, 'markers': markers})
        groups = get_scatter_groups_from_matrix(matrix, x_col='longitude',
                                                y_col='latitude',
                                                marker_col='markers',
                                                color_col='colors')
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        geographic_map(groups, fhand, labels=True)
        # raw_input('fichero:' + fhand.name)

    def test_plot_matrix(self):
        xys = _create_normal_distrib(10, 10, mean=0, std_dev=20)
        fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        plot_matrix(xys, fhand)
        #raw_input('fichero:' + fhand.name)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'PlotTest.test_stacked_cols']
    unittest.main()
