
import unittest
from StringIO import StringIO


from variation.inout.dataframe import load_dataframe_csv
from variation.inout.genetic import load_markers_map
from variation.utils import TemporaryDir
from variation.analyses.finestructure import (create_chromopainter_infiles,
                                              _create_recombination_infile)


class fineStructureTest(unittest.TestCase):
    'It tests the Chromopainter and fineStucture software'

    def test_recomb_infile(self):
        physical_map = '''chromosome,position
marker1,1,100
marker2,1,300
marker3,2,250
marker4,2,450'''
        genetic_map = '''chromosome,distance
marker1,1,1
marker2,1,3
marker3,2,5
marker4,2,9'''

        genetic_map = load_markers_map(StringIO(genetic_map), index_col=0,
                                       molecule_col='chromosome',
                                       location_col='distance', sep=',')

        physical_map = load_markers_map(StringIO(physical_map), index_col=0,
                                            molecule_col='chromosome',
                                            location_col='position', sep=',')

        valid_snps = ['marker1', 'marker2', 'marker3', 'marker4']
        temp_dir = TemporaryDir()
        try:
            fhand = _create_recombination_infile(physical_map, genetic_map,
                                             valid_snps,
                                             out_dir_path=temp_dir.name)
            result = '''start.pos recom.rate.perbp
100 0.010000000000000
300 -9.000000000000000
250 0.020000000000000
450 0.000000000000000'''
            assert result in open(fhand.name).read()
        finally:
            temp_dir.close()

    def test_create_chromopainter_infiles(self):
        physical_map_data = '''chromosome,position
marker1,1,20
marker6,1,45
marker2,1,25
marker4,2,35
marker3,2,30
marker5,1,40
marker7,2,45
'''
        genetic_map_data = '''chromosome,distance
marker1,1,0.01
marker6,1,0.07
marker2,1,0.03
marker4,2,0.03
marker3,2,0.00
marker5,1,0.05
marker7,2,0.05
'''

        haplotypes_data = '''individual,haplotype_num,marker1,marker2,marker5,marker6,marker3,marker4
indi1,haplotype1,A,C,A,A,C,G
indi1,haplotype2,A,C,A,C,T,G
indi2,haplotype1,A,G,T,A,C,A
indi2,haplotype2,A,G,A,A,C,A
indi3,haplotype1,G,C,A,C,T,G
indi3,haplotype2,G,G,T,A,T,G
indi4,haplotype1,G,C,A,C,C,A
indi4,haplotype2,G,C,A,C,T,G
indi5,haplotype1,A,G,A,A,C,G
indi5,haplotype2,G,C,A,A,T,G'''

        haplotypes = load_dataframe_csv(StringIO(haplotypes_data),
                                       index_col=[0, 1])
        physical_map_fhand = StringIO(physical_map_data)
        physical_map = load_markers_map(physical_map_fhand, index_col=0,
                                        molecule_col='chromosome',
                                        location_col='position', sep=',')
        genetic_map_fhand = StringIO(genetic_map_data)
        genetic_map = load_markers_map(genetic_map_fhand, index_col=0,
                                       molecule_col='chromosome',
                                       location_col='distance', sep=',')

        temp_dir = TemporaryDir()
        expected = '0\n5\n6\nP 20 25 40 45 30 35\nSSSSSS\nACAACG\n'
        expected += 'ACACTG\nAGTACA\nAGAACA\nGCACTG\nGGTATG\nGCACCA\nGCACTG\n'
        expected += 'AGAACG\nGCAATG\n'
        try:
            fhands = create_chromopainter_infiles(haplotypes, physical_map,
                                                  genetic_map, temp_dir.name)
            self.fail('ValueError expected')
        except ValueError:
            pass
        finally:
            temp_dir.close()

        # a sorted physical map
        physical_map_data = '''chromosome,position
marker1,1,20
marker2,1,25
marker5,1,40
marker6,1,45
marker3,2,30
marker4,2,35
marker7,2,45
'''
        physical_map_fhand = StringIO(physical_map_data)
        physical_map = load_markers_map(physical_map_fhand, index_col=0,
                                        molecule_col='chromosome',
                                        location_col='position', sep=',')

        try:
            fhands = create_chromopainter_infiles(haplotypes, physical_map,
                                                  genetic_map, temp_dir.name)
            haplos = open(fhands['haplotype_fhand'].name).read()
        finally:
            temp_dir.close()
        assert haplos == expected


if __name__ == "__main__":
    unittest.main()
