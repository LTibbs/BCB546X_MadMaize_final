'''
Created on 06/05/2013

@author: pau
'''
import unittest
from StringIO import StringIO
from pandas.core.series import Series
import numpy

from variation.inout.genetic import load_codominant_genetic_csv
from variation.analyses.pop_stats import (calculate_individual_heterozigosity,
                                          calculate_marker_heterozigosity,
                                          calculate_polymorphism_by_groups,
                                          calculate_obs_het_by_groups,
                                          calculate_exp_het_by_groups,
                                          calculate_basic_stats,
                                          PopPolymorphism,
                                          generate_plot_groups_for_rarefaction,
                                          AlleleFreqsDistribs)

# pylint: disable=R0201
# pylint: disable=R0904
# pylint: disable=C0111


class TestPopStats(unittest.TestCase):

    def test_check_heterozygosity(self):
        genotypes_data = '''indi1,indi2,indi3,indi4
marker1,AA,AG,AG,GG
marker2,CC,CG,CG,CC
marker3,CC,CT,CT,CT
marker4,GG,AA,AG,
marker5,AA,TT,AT,
marker6,AA,CC,AC,CC
'''
        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)
        heterozygotes = calculate_individual_heterozigosity(genotypes)

        assert heterozygotes['indi1'] == 0
        assert heterozygotes['indi2'] == 0.5
        assert heterozygotes['indi3'] == 1.0
        assert heterozygotes['indi4'] == 0.25

        heterozygotes = calculate_marker_heterozigosity(genotypes)

        assert heterozygotes['marker1'] == 0.5
        assert heterozygotes['marker2'] == 0.5
        assert heterozygotes['marker3'] == 0.75
        assert heterozygotes['marker6'] == 0.25

    def test_calculate_population_stats_by_group(self):
        genotypes_data = '''indi1,indi2,indi3,indi4
marker1,AA,AG,AG,GG
marker2,CC,CG,CG,CC
marker3,CC,CT,CT,CT
marker4,GG,GG,GT,
marker5,AA,TT,AT,
marker6,AA,CC,AC,CC
'''
        pops = ['pop1', 'pop1', 'pop2', 'pop2']
        indis = ['indi1', 'indi2', 'indi3', 'indi4']

        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)

        populations = Series(pops, index=indis)

        polimorphic_loci = calculate_polymorphism_by_groups(genotypes,
                                                            populations)
        assert round(polimorphic_loci['pop1'], 3) == 0.833
        assert round(polimorphic_loci['pop2'], 3) == 1.000

        obs_het = calculate_obs_het_by_groups(genotypes, populations,
                                              min_num_individuals=1)

        assert round(obs_het['pop1'], 3) == 0.25
        assert round(obs_het['pop2'], 3) == 0.75

        exp_het, std_exp_het = calculate_exp_het_by_groups(genotypes, populations,
                                              min_num_individuals=1)
        assert round(exp_het['pop1'], 3) == 0.472
        assert round(exp_het['pop2'], 3) == 0.694

        stats = calculate_basic_stats(genotypes, populations,
                                      min_num_individuals=1)
        expected = [0.25, 0.47222222222222215, 0.10015420209622192,
                    0.83333333333333337, 0.83333333333333337,
                    0.47058823529411759, 0.3600000000000001, 2.0]
        assert all(stats['pop1'] == expected)

    def test_pop_rarefaction(self):
        genotypes_data = '''indi1,indi2,indi3,indi4,indi5
marker1,AA,AG,AG,GG,GG
marker2,CC,CG,CG,CC,CC
marker3,CC,CT,CT,CT,TT
marker4,GG,GG,GT,,GT
marker5,AA,TT,AT,,
marker6,AA,CC,AC,CC,CC
'''
        pops = ['pop1', 'pop1', 'pop2', 'pop2', 'pop3']
        indis = ['indi1', 'indi2', 'indi3', 'indi4', 'indi5']

        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)

        classification = Series(pops, index=indis)
        pop_polymorphism = PopPolymorphism(genotypes, classification,
                                           polymorphism_threshold=95)
        polymorphism = pop_polymorphism.polymorphism
        assert polymorphism['pop3'] == 1 / 5.0
        expected = [0.83333, 1.0]
        polymorphism = polymorphism.ix[['pop1', 'pop2']]
        assert all(polymorphism - expected < 0.01)

        rarefaction = pop_polymorphism.rarefaction()
        rarefaction_keys = rarefaction.viewkeys()
        assert list(rarefaction_keys) == ['median', 'lower_ci', 'upper_ci']

#         plot_groups = generate_plot_groups_for_rarefaction(rarefaction)
#         assert len(plot_groups) == 3
#         from variation.plot import scatter_groups
#         from tempfile import NamedTemporaryFile
#         fhand = NamedTemporaryFile(suffix='.svg')
#         scatter_groups(plot_groups, fhand, plot_lines=True)
#         print plot_groups
#         raw_input(fhand.name)

    def test_pop_allele_freqs_distrib(self):
        genotypes_data = '''indi1,indi2,indi3,indi4,indi5
marker1,AA,AG,AG,GG,GG
marker2,CC,CG,CG,CC,CC
marker3,CC,CT,CT,CT,TT
marker4,GG,GG,GT,,GT
marker5,AA,TT,AT,,
marker6,AA,CC,AC,CC,CC
'''
        pops = ['pop1', 'pop1', 'pop2', 'pop2', 'pop3']
        indis = ['indi1', 'indi2', 'indi3', 'indi4', 'indi5']

        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)

        classification = Series(pops, index=indis)
        poly = AlleleFreqsDistribs(genotypes, classification)
        hist = poly.maf_histograms()
        expected = [0.333333, 0, 0, 0, 0, 0.5, 0, 0, 0, 0.166667]
        numpy.testing.assert_array_almost_equal(hist.ix['pop1'], expected)

        freq_by_locus = poly.freq_by_locus()
        expected = [0.75, 0.25, 0.75, 1.0, 0.5, 0.5]
        numpy.testing.assert_array_almost_equal(freq_by_locus.ix['pop1'],
                                                expected)


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'SmartPCATest.test_smartpca']
    unittest.main()
