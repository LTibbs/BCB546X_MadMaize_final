import unittest
from StringIO import StringIO

from pandas.core.series import Series

from variation.inout.genetic import load_codominant_genetic_csv
from variation.analyses.bayescan import create_infile

# pylint: disable=R0201
# pylint: disable=R0904
# pylint: disable=C0111


class BayescanTest(unittest.TestCase):
    def test_pop_rarefaction(self):
        genotypes_data = '''indi1,indi2,indi3,indi4,indi5
marker1,AA,AG,AG,GG,GG
marker2,CC,CG,CG,CC,CC
marker3,CC,CT,CT,CT,TT
marker4,GG,GG,GT,,GT
marker5,AA,TT,AT,,
marker6,AA,CC,AC,CC,CC
'''
        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)

        pops = ['pop1', 'pop1', 'pop2', 'pop2', 'pop3']
        indis = ['indi1', 'indi2', 'indi3', 'indi4', 'indi5']
        classification = Series(pops, index=indis)

        out_fhand = StringIO()
        info_fhand = StringIO()
        create_infile(genotypes, classification, out_fhand, info_fhand)
        res = out_fhand.getvalue()
        assert '[loci]=6\n\n[populations]=3\n\n[pop]=1\n1 2 4 0 2 0 0' in res
        expected = 'Populations\n1\tpop3\n2\tpop2\n3\tpop1\nMarkers\n1\tmarker'
        assert expected in info_fhand.getvalue()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'SmartPCATest.test_smartpca']
    unittest.main()
