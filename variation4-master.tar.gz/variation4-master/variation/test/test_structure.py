
import unittest
from StringIO import StringIO

from pandas import DataFrame

from variation.inout.genetic import (load_codominant_genetic_csv,
                                     load_dominant_genetic_csv,
                                     load_markers_map)
from variation.inout.dataframe import load_dataframe_csv
from variation.matrixwithmeta import (CLASSIFICATION_COL, FLOAT,
                                      MatrixWithMeta)
from variation.analyses.structure import (create_genotype_file,
                                          get_default_params,
                                          create_param_files, do_structure,
                                          read_structure_result,
                                          do_structure_for_ks,
                                          read_structure_results,
                                          sort_rows_by_similarity,
                                          sort_individual_classification)
from variation.utils import TemporaryDir

# pylint: disable=R0201
# pylint: disable=R0904


class StructureTest(unittest.TestCase):
    'It tests the Structure analysis'
    def test_codominant_struc_infile(self):
        'Structure analysis in codominant data'

        genotypes = 'indi1,indi2,indi3,indi4,indi5\n'
        genotypes += 'marker1,,S,C,C,C\n'
        genotypes += 'marker2,A,A,T,T,A\n'
        genotypes += 'marker3,G,G,C,C,C\n'
        genotypes += 'marker4,A,A,T,T,T\n'
        genotypes_fhand = StringIO(genotypes)
        splitter = 'iupac_allele_splitter'
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=False,
                                                allele_splitter=splitter)
        fhand, params = create_genotype_file(genotypes)
        assert params['MARKERNAMES'] == 1
        assert params['LABEL'] == 1
        assert params['ONEROWPERIND'] == 1
        assert params['POPDATA'] == 0
        assert params['LOCDATA'] == 0
        assert params['PHENOTYPE'] == 0
        assert params['EXTRACOLS'] == 0
        assert params['RECESSIVEALLELES'] == 0
        assert params['MAPDISTANCES'] == 0
        assert params['LINKAGE'] == 0
        expected = 'marker1 marker2 marker3 marker4\nindi1 -9 -9 3 3 1 1 3 3'
        assert expected in open(fhand.name).read()

        # with population data
        indis = 'population,gender\n'
        indis += 'indi5,pop1,M\n'
        indis += 'indi2,pop1,F\n'
        indis += 'indi3,pop2,F\n'
        indis += 'indi4,pop2,F\n'
        indis += 'indi1,pop2,F\n'
        indis = StringIO(indis)
        indis = load_dataframe_csv(indis,
                                   meta={CLASSIFICATION_COL: 'population'})
        fhand, params = create_genotype_file(genotypes, individuals=indis)
        assert params['POPDATA'] == 1
        assert params['EXTRACOLS'] == 1
        expected = 'marker1 marker2 marker3 marker4\nindi1 0 pop2 -9 -9 3 3 1 '
        assert expected in open(fhand.name).read()

        # with a marker map
        markers = 'chrom,location\n'
        markers += 'marker1,1,3.0\n'
        markers += 'marker2,2,13.0\n'
        markers += 'marker3,1,5.0\n'
        markers += 'marker4,2,16.0\n'
        markers += 'marker5,1,16.0\n'
        markers = StringIO(markers)
        markers = load_markers_map(markers, molecule_col='chrom',
                                   location_col='location')
        fhand, params = create_genotype_file(genotypes, individuals=indis,
                                             markers_map=markers)
        assert params['MAPDISTANCES'] == 1
        assert params['LINKAGE'] == 1
        expected = 'marker1 marker3 marker2 marker4\n-1 2 -1 3\nindi1 0 pop2 -'
        assert expected in open(fhand.name).read()

    def test_dominant_struct_infile(self):
        'Structure analysis in dominant data'
        data = '''acc\taflp1\taflp2
acc1\t1\t1
acc2\t0\t0
'''
        fhand = StringIO(data)
        genotypes = load_dominant_genetic_csv(fhand, individuals_in_rows=True,
                                              index_col=0, sep=None)
        fhand, params = create_genotype_file(genotypes)
        assert params['MARKERNAMES'] == 1
        assert params['LABEL'] == 1
        assert params['ONEROWPERIND'] == 1
        assert params['POPDATA'] == 0
        assert params['LOCDATA'] == 0
        assert params['PHENOTYPE'] == 0
        assert params['EXTRACOLS'] == 0
        assert params['RECESSIVEALLELES'] == 1
        assert params['MAPDISTANCES'] == 0
        assert params['LINKAGE'] == 0
        expected = 'aflp1 aflp2\n0 0\nacc1 1 1 1 1\nacc2 0 0 0 0'
        assert expected in open(fhand.name).read()

    def test_do_structure(self):
        'It tests that we can do an structure analysis'
        genotypes = 'indi1,indi2,indi3,indi_long_name4,indi_long_name5\n'
        genotypes += 'marker1,,S,C,C,C\n'
        genotypes += 'marker2,A,A,T,T,A\n'
        genotypes += 'marker3,G,G,C,C,C\n'
        genotypes += 'marker4,A,A,T,T,T\n'
        genotypes += 'marker5,A,A,T,T,T\n'
        genotypes += 'marker6,G,G,G,C,C\n'
        genotypes += 'marker7,G,G,G,C,C\n'
        genotypes_fhand = StringIO(genotypes)
        splitter = 'iupac_allele_splitter'
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=False,
                                                allele_splitter=splitter)

        mainparams, extraparams = get_default_params()
        geno_fhand, mainparams = create_genotype_file(genotypes,
                                                      params=mainparams)
        mainparams_fhand, extraparams_fhand = create_param_files(mainparams,
                                                                 extraparams)
        out_fhand = do_structure(k=2, genotype_fhand=geno_fhand,
                                 mainparams_fhand=mainparams_fhand,
                                 extraparams_fhand=extraparams_fhand)
        assert 'Inferred Clusters' in open(out_fhand.name).read()
        try:
            read_structure_result(open(out_fhand.name))
            self.fail('RuntimeError expected')
        except RuntimeError:
            pass
        result = read_structure_result(open(out_fhand.name),
                                       genotype_fhand=geno_fhand)
        indi_names = ['indi1', 'indi2', 'indi3', 'indi_long_name4',
                      'indi_long_name5']
        pop_class = result['population_classification']
        assert pop_class.data.shape == (1, 2)
        assert pop_class.kind == FLOAT
        indi_class = result['individual_classification']
        assert indi_class.data.shape == (5, 2)
        assert indi_class.kind == FLOAT
        assert all(indi_class.data.index == indi_names)
        assert 'ln_prob' in result

        # with population data
        indis = 'population,gender\n'
        indis += 'indi_long_name5,pop1,M\n'
        indis += 'indi2,pop1,F\n'
        indis += 'indi3,pop2,F\n'
        indis += 'indi_long_name4,pop2,F\n'
        indis += 'indi1,pop2,F\n'
        indis = StringIO(indis)
        indis = load_dataframe_csv(indis,
                                   meta={CLASSIFICATION_COL: 'population'})
        mainparams, extraparams = get_default_params()
        geno_fhand, mainparams = create_genotype_file(genotypes,
                                                      individuals=indis)
        mainparams_fhand, extraparams_fhand = create_param_files(mainparams,
                                                                 extraparams)
        out_fhand = do_structure(k=2, genotype_fhand=geno_fhand,
                                 mainparams_fhand=mainparams_fhand,
                                 extraparams_fhand=extraparams_fhand)
        result = read_structure_result(open(out_fhand.name),
                                       open(geno_fhand.name))
        pop_class = result['population_classification']
        assert pop_class.data.shape == (2, 2)
        assert list(sorted(pop_class.data.index)) == ['pop1', 'pop2']
        indi_class = result['individual_classification']
        assert indi_class.data.shape == (5, 2)
        assert all(indi_class.data.index == indi_names)

    def test_do_structure_for_ks(self):
        'It tests that we can do an structure analysis'
        genotypes = 'indi1,indi2,indi3,indi4,indi5\n'
        genotypes += 'marker1,,S,C,C,C\n'
        genotypes += 'marker2,A,A,T,T,A\n'
        genotypes += 'marker3,G,G,C,C,C\n'
        genotypes += 'marker4,A,A,T,T,T\n'
        genotypes += 'marker5,A,A,T,T,T\n'
        genotypes += 'marker6,G,G,G,C,C\n'
        genotypes += 'marker7,G,G,G,C,C\n'
        genotypes_fhand = StringIO(genotypes)
        splitter = 'iupac_allele_splitter'
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=False,
                                                allele_splitter=splitter)

        directory = TemporaryDir(prefix='temp_struct')
        mainparams, extraparams = get_default_params()
        geno_fhand, mainparams = create_genotype_file(genotypes,
                                                      params=mainparams)
        mainparams_fhand, extraparams_fhand = create_param_files(mainparams,
                                                                 extraparams)
        try:
            do_structure_for_ks(2, 3, genotype_fhand=geno_fhand,
                                directory=directory.name,
                                mainparams_fhand=mainparams_fhand,
                                extraparams_fhand=extraparams_fhand)
            results = read_structure_results(directory.name)            
            assert results['ks'] == [2, 3]
            assert len(results['ln_probs']) == 2
        finally:
            directory.close()

    def test_classification_sorting(self):
        'It sorts the individual classification'
        columns = ['ances_pop_1', 'ances_pop_2']
        indis = ['indi1', 'indi3', 'indi4', 'indi5', 'indi2']
        indi_class = [[0.980, 0.020], [0.080, 0.920],
                      [0.017, 0.983], [0.029, 0.971], [0.981, 0.019]]
        indi_class = DataFrame(indi_class, index=indis, columns=columns)
        indi_class = MatrixWithMeta(indi_class)
        expected = ['indi2', 'indi1', 'indi4', 'indi5', 'indi3']
        sorted_indis = sort_rows_by_similarity(indi_class).data.index.values
        assert all(sorted_indis == expected)

        indis = ['indi1', 'indi2', 'indi3', 'indi4', 'indi5', 'indi6']
        indi_class = [[0.6, 0.4], [0.2, 0.8], [0.9, 0.1], [0.3, 0.7],
                      [0.8, 0.2], [0.1, 0.9]]
        indi_class = DataFrame(indi_class, index=indis, columns=columns)
        indi_class = MatrixWithMeta(indi_class)
        indi_class = sort_rows_by_similarity(indi_class)
        expected = ['indi3', 'indi5', 'indi1', 'indi6', 'indi2', 'indi4']
        assert expected == list(indi_class.data.index.values)

        #import tempfile
        #fhand = tempfile.NamedTemporaryFile(suffix='.svg')
        #from variation.plot import stacked_bars
        #stacked_bars(indi_class.data, fhand)
        #raw_input(fhand.name)

        # sorting with the prior populations
        indis = ['indi1', 'indi3', 'indi4', 'indi5', 'indi2']
        indi_class = [[0.980, 0.020], [0.080, 0.920],
                      [0.017, 0.983], [0.029, 0.971], [0.981, 0.019]]
        indi_class = DataFrame(indi_class, index=indis, columns=columns)
        indi_class = MatrixWithMeta(indi_class)
        indis = 'population,gender\n'
        indis += 'indi5,pop1,M\n'
        indis += 'indi2,pop1,F\n'
        indis += 'indi3,pop2,F\n'
        indis += 'indi4,pop2,F\n'
        indis += 'indi1,pop2,F\n'
        indis = StringIO(indis)
        indis = load_dataframe_csv(indis,
                                   meta={CLASSIFICATION_COL: 'population'})
        pop_class = [[0.980, 0.020], [0.029, 0.971]]
        pops = ['pop1', 'pop2']
        pop_class = DataFrame(pop_class, index=['pop1', 'pop2'])
        pop_class = MatrixWithMeta(pop_class)
        indi_class = sort_individual_classification(indi_class, indis, pops)
        expected = ['indi2', 'indi5', 'indi1', 'indi4', 'indi3']
        assert all(indi_class.data.index.values == expected)

if __name__ == "__main__":
    #import sys; sys.argv = ['', 'StructureTest.test_do_structure_for_ks']
    unittest.main()
