'''
Created on 02/03/2012

@author: jose
'''

import unittest
from StringIO import StringIO

import numpy
from pandas import DataFrame

from variation.matrixwithmeta import (MatrixWithMeta, DISTANCE,
                                      CLASSIFICATION_COL, GENDER_COL)
from variation.analyses.multivariate import (do_pcoa, do_pca, do_smartpca,
                                             prepare_smartpca_outliers,
                                             prepare_smartpca_sex_chrom)
from variation.inout.genetic import (load_codominant_genetic_csv,
                                     load_markers_map)
from variation.inout.dataframe import load_dataframe_csv
from variation.analyses.smartpca import _create_marker_file, _create_indi_file

# pylint: disable=R0201
# pylint: disable=R0904


class PcoaTest(unittest.TestCase):
    'It tests the Principal Component analysis'
    def test_pcoa(self):
        'It does a principal component analysis'

        dists = [[0.00000, 3.16228, 3.16228, 7.07107, 7.07107],
                 [3.16228, 0.00000, 4.47214, 4.47214, 6.32456],
                 [3.16228, 4.47214, 0.00000, 6.32456, 4.47214],
                 [7.07107, 4.47214, 6.32456, 0.00000, 4.47214],
                 [7.07107, 6.32456, 4.47214, 4.47214, 0.00000]]
        names = ['item_{:d}'.format(i) for i in range(len(dists))]
        matrix = DataFrame(dists, index=names, columns=names)
        matrix = MatrixWithMeta(matrix)
        matrix.kind = DISTANCE

        pcoa = do_pcoa(matrix)
        percentages = pcoa['var_percentages']
        assert len(percentages.data) == len(dists)
        assert pcoa['projections'].data.columns[0] == 'pcoa-1'

        points = pcoa['projections'].data
        expected = [[3.57770879, 0., 0.00198154, 0., 0.00000003],
               [1.34164221, -2.23606963, -0.00148615, 0.00128285, 0.00000003],
               [1.34164221, 2.23606963, -0.00148615, -0.00128285, 0.00000003],
               [-3.13049661, -2.23606963, 0.00049538, -0.00128285, 0.00000003],
               [-3.13049661, 2.23606963, 0.00049538, 0.00128285, 0.00000003]]
        assert numpy.allclose(numpy.abs(points), numpy.abs(expected))
        item_names = pcoa['projections'].data.index
        assert all(item_names == names)

        expected = [36.0000259, 20.0000296, 0.00000883, 0.00000658, -0.]
        expected = [e / sum(expected) * 100 for e in expected]
        assert numpy.allclose(pcoa['var_percentages'].data, expected)


class PcaTest(unittest.TestCase):
    'It tests the Principal Component Analysis'
    def test_pca(self):
        'It does a Principal Component Analysis'

        x_vals = [2.5, 0.5, 2.2, 1.9, 3.1, 2.3, 2, 1, 1.5, 1.1]
        y_vals = [2.4, 0.7, 2.9, 2.2, 3.0, 2.7, 1.6, 1.1, 1.6, 0.9]
        row_names = ['item_{:d}'.format(i) for i in range(len(x_vals))]
        matrix = DataFrame({'x': x_vals, 'y': y_vals}, index=row_names)
        matrix = MatrixWithMeta(matrix)
        pca = do_pca(matrix)

        projections = pca['projections'].data
        proj_expected = [[-0.82797019, 0.17511531],
                         [1.77758033, -0.14285723],
                         [-0.99219749, -0.38437499],
                         [-0.27421042, -0.13041721],
                         [-1.67580142, 0.20949846],
                         [-0.9129491, -0.17528244],
                         [0.09910944, 0.3498247],
                         [1.14457216, 0.04641726],
                         [0.43804614, -0.01776463],
                         [1.22382056, 0.16267529]]

        assert numpy.allclose(numpy.abs(projections), numpy.abs(proj_expected))

        princomps = pca['princomps'].data
        princomps_expected = [[-0.677873, -0.735179],
                              [0.735179, -0.677873]]
        assert numpy.allclose(numpy.abs(princomps),
                              numpy.abs(princomps_expected))

        percentages = pca['var_percentages'].data
        perc_expected = [96.318131, 3.681869]
        assert numpy.allclose(numpy.abs(percentages), numpy.abs(perc_expected))


class SmartPCATest(unittest.TestCase):
    'It tests the smartpca with genotypes'

    def test_smartpca(self):
        'We do an smartpca'
        genotypes = 'indi1,indi2,indi3\n'
        genotypes += 'marker1,A,M,C\n'
        genotypes += 'marker2,S,C,G\n'
        genotypes_fhand = StringIO(genotypes)
        splitter = 'iupac_allele_splitter'
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=False,
                                                allele_splitter=splitter)
        params = {'num_chromosomes': 22}
        pca1 = do_smartpca(genotypes=genotypes, params=params)
        perc_expcted = [75.0, 25.0]
        assert numpy.allclose(pca1['var_percentages'].data.values,
                              perc_expcted)

        # in columns
        genotypes = 'marker1,marker2\n'
        genotypes += 'indi1,A,S\n'
        genotypes += 'indi2,M,C\n'
        genotypes += 'indi3,C,G\n'
        genotypes_fhand = StringIO(genotypes)
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=True,
                                                allele_splitter=splitter)
        params = {'num_chromosomes': 12}
        pca2 = do_smartpca(genotypes=genotypes, params=params)
        assert numpy.allclose(pca1['projections'].data.values,
                              pca2['projections'].data.values)

        snps = 'chrom,position\n'
        snps += 'marker1,chrom1,15\n'
        snps += 'marker2,chrom1,20\n'
        snps += 'marker3,chrom2,30\n'
        snps = StringIO(snps)
        snps = load_markers_map(snps, molecule_col='chrom',
                                location_col='position')
        snps_fhand = _create_marker_file(snps, genotypes)
        content = open(snps_fhand.name).read()
        assert 'marker1 1          0.000000              15' in content
        snps_fhand.close()
        pca = do_smartpca(genotypes=genotypes, markers_map=snps)
        perc_expcted = [75.0, 25.0]
        assert numpy.allclose(pca['var_percentages'].data.values, perc_expcted)

        indis = 'population,gender\n'
        indis += 'indi1,pop1,M\n'
        indis += 'indi2,pop2,F\n'
        indis += 'indi3,pop3,F\n'
        indis += 'indi4,pop3,F\n'
        indis = StringIO(indis)
        indis = load_dataframe_csv(indis,
                                   meta={CLASSIFICATION_COL: 'population',
                                         GENDER_COL: 'gender'})
        indis_fhand = _create_indi_file(indis, genotypes)
        content = open(indis_fhand.name).read()
        assert 'indi1 M                 pop1' in content
        pca = do_smartpca(genotypes=genotypes, markers_map=snps,
                          individuals=indis)
        perc_expcted = [75.0, 25.0]
        assert numpy.allclose(pca['var_percentages'].data.values, perc_expcted)
        princomp_expected = [-0.4082, -0.7071, -0.4082, 0.7071, 0.8165, 0.0000]
        assert numpy.allclose(pca['projections'].data.values.flat,
                              princomp_expected)

        # This example is from the smartpca examples
        genotypes = 'ind1,ind2,ind3,ind4,ind5\n'
        genotypes += 'm1,AT,AT,AT,AA,AA\n'  # 11100
        genotypes += 'm2,AA,AT,TT,AT,TT\n'  # 01212
        genotypes += 'm3,TT,AT,AT,AA,AT\n'  # 21101
        genotypes += 'm4,AA,AA,AT,TT,TT\n'  # 00122
        genotypes += 'm5,TT,AT,AT,AA,AA\n'  # 21100
        genotypes += 'm6,AA,AA,AT,AT,AT\n'  # 00111
        genotypes += 'm7,TT,TT,AT,AT,AA\n'  # 22110
        genotypes_fhand = StringIO(genotypes)
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=False)
        pca = do_smartpca(genotypes=genotypes, params=params)
        expected = [[0.6493, 0.0942, -0.5834, -0.1706],
                    [0.3599, 0.0754, 0.5914, 0.5613],
                    [-0.0780, -0.6092, 0.3227, -0.5645],
                    [-0.3980, 0.7286, 0.1095, -0.3143],
                    [-0.5333, -0.2890, -0.4402, 0.4882]]
        # The last PCA varies between computers
        pca_projections = pca['projections'].data.ix[:, :-1]
        assert numpy.allclose(pca_projections.values, expected)

        # With many axes
        genotypes = 'm1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15\n'
        genotypes += 'i1,AT,AT,AT,AA,AA,AT,AT,AT,AA,AA,AT,AT,AT,AA,AA\n'
        genotypes += 'i2,AA,AT,TT,AT,TT,AA,AT,TT,AT,TT,AA,AT,TT,AT,TT\n'
        genotypes += 'i3,TT,AT,AT,AA,AT,TT,AT,AT,AA,AT,TT,AT,AT,AA,AT\n'
        genotypes += 'i4,AA,AA,AT,TT,TT,AA,AA,AT,TT,TT,AA,AA,AT,TT,TT\n'
        genotypes += 'i5,TT,AT,AT,AA,AA,TT,AT,AT,AA,AA,TT,AT,AT,AA,AA\n'
        genotypes += 'i6,AA,AA,AT,AT,AT,AA,AA,AT,AT,AT,AA,AA,AT,AT,AT\n'
        genotypes += 'i7,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes_fhand = StringIO(genotypes)
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=True)
        params = {'num_chromosomes': 22}
        pca = do_smartpca(genotypes=genotypes, max_princomps=10, params=params)
        per10 = pca['var_percentages']
        pca = do_smartpca(genotypes=genotypes, max_princomps=3, params=params)
        per3 = pca['var_percentages']
        assert numpy.allclose(per3.data, per10.data[:len(per3.data)])

    def test_outliers(self):
        'It removes the outliers'
        # With many axes
        genotypes = 'm1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15\n'
        genotypes += 'i1,AT,AT,AT,AA,AA,AT,AT,AT,AA,AA,AT,AT,AT,AA,AA\n'
        genotypes += 'i2,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i3,TA,TT,AT,AT,AA,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i4,TT,TA,AT,AT,AA,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i5,TT,TT,AA,AT,AA,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i6,TT,TT,AT,AA,AA,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i7,TT,TT,AT,AT,AT,TT,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i8,TT,TT,AT,AT,AA,TA,TT,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i9,TT,TT,AT,AT,AA,TT,TA,AT,AT,AA,TT,TT,AT,AT,AA\n'
        genotypes += 'i10,GG,GG,GG,GG,GG,GG,GG,GG,GG,GG,GG,GG,GG,GG,GG\n'
        genotypes_fhand = StringIO(genotypes)
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=True)
        params = prepare_smartpca_outliers(outliers_iterations=1,
                                           outliers_sigma=2.5)
        params['num_chromosomes'] = 22
        pca1 = do_smartpca(genotypes=genotypes, params=params)
        outliers = list(sorted(pca1['outlier_sigmas'].index))
        assert outliers

    def test_x_chrom(self):
        'We take into account the X chromosome'
        genotypes = 'indi1,indi2,indi3\n'
        genotypes += 'marker1,A,M,C\n'
        genotypes += 'marker2,S,C,G\n'
        genotypes += 'marker3,S,C,G\n'
        genotypes_fhand = StringIO(genotypes)
        splitter = 'iupac_allele_splitter'
        genotypes = load_codominant_genetic_csv(genotypes_fhand,
                                                individuals_in_rows=False,
                                                allele_splitter=splitter)

        snps = 'chrom,position\n'
        snps += 'marker1,chrom1,15\n'
        snps += 'marker2,chrom1,20\n'
        snps += 'marker3,chromX,30\n'
        snps = StringIO(snps)
        snps = load_markers_map(snps, molecule_col='chrom',
                                location_col='position',
                                sex_chromosomes=('chromX', 'chromY'))
        snps_fhand = _create_marker_file(snps, genotypes)
        content = open(snps_fhand.name).read()
        assert 'marker3 23' in content
        snps_fhand.close()
        params = {'num_chromosomes': 22}
        prepare_smartpca_sex_chrom(params, remove_x_markers=True)
        pca = do_smartpca(genotypes=genotypes, markers_map=snps, params=params)
        assert pca['deleted_markers_reasons'].values[0] == 'chrom-X'

        prepare_smartpca_sex_chrom(params, remove_x_markers=False)
        pca = do_smartpca(genotypes=genotypes, markers_map=snps, params=params)
        assert 'deleted_markers_reasons' not in pca

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'SmartPCATest.test_smartpca']
    unittest.main()
