
import unittest
from cStringIO import StringIO

from variation.analyses.geography import lat_to_deg, lon_to_deg, split_in_grids
from variation.inout.dataframe import load_dataframe_csv

# pylint: disable=R0201
# pylint: disable=R0904


class GeographyTest(unittest.TestCase):
    'Table class tests'
    def test_to_lon_lat(self):
        'It converts to latitude in degrees'
        assert lat_to_deg('60.0') == 60.0
        assert lat_to_deg('') is None
        assert lat_to_deg(' ') is None
        assert lat_to_deg('600000N') == 60.0
        assert lat_to_deg('6000--N') - 60.0083333333 < 0.0001
        assert lat_to_deg('-60.0') == -60.0
        assert lat_to_deg(60) == 60.0
        assert lat_to_deg(60.0) == 60.0
        assert lat_to_deg(None) is None
        assert lat_to_deg((60, 0, 0)) == 60.0

        assert lon_to_deg('0600000W') == -60.0


class GridTest(unittest.TestCase):
    def test_group_in_grids(self):
        gps = ''',x,y
p1,-2,2
p2,-0.5,1.5
p3,1.5,1.5
p4,-0.5,0.5
p5,0,1
p6,0.5,0.5
p7,-0.5,-0.5
p8,0,0
p9,0.5,-0.5
p10,1.96,-1.96'''
        gps = load_dataframe_csv(StringIO(gps), sep=',', index_col=0)
        grids = split_in_grids(gps, nbins=4, lon_col='x', lat_col='y')
        assert grids.x_min
        assert grids.bin_width - 0.999 < 0.01
        grids = {k: v['row_names'] for k, v in grids.viewitems()}
        expected = {(1, 2): ['p4'], (1, 3): ['p2'], (3, 3): ['p3'],
                    (3, 0): ['p10'], (2, 1): ['p8', 'p9'],
                    (2, 2): ['p5', 'p6'], (0, 3): ['p1'], (1, 1): ['p7']}
        assert grids == expected

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'TableTest.test_init']
    unittest.main()
