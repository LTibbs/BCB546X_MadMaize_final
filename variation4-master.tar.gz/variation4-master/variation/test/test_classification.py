'''
Created on 04/04/2012

@author: jose
'''
import unittest
from tempfile import NamedTemporaryFile

import numpy
from pandas import DataFrame

from variation.matrixwithmeta import MatrixWithMeta
from variation.analyses.classification import (do_gaussian_mixture,
                                               select_most_probable_class)
from variation.analyses.matrix_tools import dframe_append_columns
from variation.plot import (scatter_groups,
                            get_scatter_groups_from_matrix)

# pylint: disable=R0201
# pylint: disable=R0904


def plot_classification(xys, classification):
    'It draws a classification'
    # plot
    classification.name = 'class'
    matrix = dframe_append_columns(xys, [classification])
    matrix.columns = ['x', 'y', 'class']
    groups = get_scatter_groups_from_matrix(matrix, x_col='x', y_col='y',
                                            color_col='class')
    plot_fhand = NamedTemporaryFile(suffix='.svg')
    scatter_groups(groups, plot_fhand)
    return plot_fhand


class TestDirichletGaussian(unittest.TestCase):
    'It test the Dirichlet Process Gaussian Mixture Model based classification'
    def test_dirichlet_gaussian(self):
        'It does a dirichlet gaussian mixture model classification'

        n_samples = 300

        numpy.random.seed(0)
        gauss_distrib_params = numpy.array([[0., -0.7], [3.5, .7]])
        samples = numpy.r_[numpy.dot(numpy.random.randn(n_samples, 2),
                                     gauss_distrib_params),
                        numpy.random.randn(n_samples, 2) + numpy.array([3, 3])]
        row_names = ['row_{:3d}'.format(i) for i in range(samples.shape[0])]

        matrix = MatrixWithMeta(DataFrame(samples, index=row_names))
        classification = do_gaussian_mixture(matrix, 4)
        disc_class = select_most_probable_class(classification)

        plot_fhand = plot_classification(matrix.data, disc_class)
        #raw_input(plot_fhand.name)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_metadata']
    unittest.main()
