'''
Created on 19/04/2012

@author: jose
'''

import unittest

from variation.utils import run_wrapped_cmd, TemporaryDir

# pylint: disable=R0201
# pylint: disable=R0904


class WrapCmdTest(unittest.TestCase):
    'It tests that we can run a command wrapped in a script'
    def test_wrap_cmd(self):
        'We run a command inside an external script'
        cmd = ['pwd']
        temp_dir = TemporaryDir()
        process, stdout, stderr = run_wrapped_cmd(cmd, temp_dir.name)
        process.communicate()
        assert temp_dir.name in stdout.read()
        assert not stderr.read().strip()
        assert process.returncode == 0

        temp_dir.close()


if __name__ == "__main__":
    #import sys; sys.argv = ['', 'StructureTest.test_do_structure']
    unittest.main()
