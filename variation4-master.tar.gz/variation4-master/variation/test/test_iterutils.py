'''
Created on 20/08/2012

@author: jose
'''

import unittest

from pandas import Series

from variation.iterutils import rolling_window, count_contiguous_items


# pylint: disable=R0201
# pylint: disable=R0904


class RollingWindowTest(unittest.TestCase):
    'It tests the rolling window infrastructure'
    def test_rolling_window(self):
        'It generates rolling windows'
        orig_vector = Series([0, 2, 3, 4, 11, 12, 13],
                             index=[1, 2, 3, 4, 5, 6, 7])
        items = rolling_window(orig_vector, window_width=3)
        items = [((int(win[0]), int(win[1])), it) for win, it in  list(items)]
        assert items == [((0, 3), [1, 2]), ((3, 6), [3, 4]), ((9, 12), [5]),
                         ((12, 15), [6, 7])]

        # empty series
        orig_vector = Series([])
        items = rolling_window(orig_vector, window_width=3)
        assert not list(items)

        orig_vector = Series([0, 2, 3, 4, 13], index=[1, 2, 3, 4, 7])
        items = rolling_window(orig_vector, window_width=3)
        items = [((int(win[0]), int(win[1])), it) for win, it in  list(items)]
        assert items == [((0, 3), [1, 2]), ((3, 6), [3, 4]), ((12, 15), [7])]

        orig_vector = Series([1, 2, 3, 4, 7],
                             index=['m1', 'm2', 'm3', 'm4', 'm7'])
        items = rolling_window(orig_vector, window_width=2)
        items = [((int(win[0]), int(win[1])), it) for win, it in  list(items)]
        assert items == [((1, 3), ['m1', 'm2']), ((3, 5), ['m3', 'm4']),
                         ((7, 9), ['m7'])]

        orig_vector = Series([0, 2, 3, 4, 13], index=[1, 2, 3, 4, 7])
        items = rolling_window(orig_vector, window_width=3,
                               overlapping_windows=True)
        items = [((int(win[0]), int(win[1])), it) for win, it in  list(items)]
        assert items == [((0, 3), [1, 2]), ((1, 4), [2, 3, 4]),
                         ((3, 6), [3, 4]), ((10, 13), [7]), ((12, 15), [7])]


class CountCountiguousItems(unittest.TestCase):
    def test_count_countiguous(self):
        assert not list(count_contiguous_items([]))
        assert list(count_contiguous_items([1])) == [(1, 1)]
        assert list(count_contiguous_items([1, 1])) == [(1, 2)]
        assert list(count_contiguous_items([1, 1, 2])) == [(1, 2), (2, 1)]
        assert list(count_contiguous_items([1, 1, 2, 2])) == [(1, 2), (2, 2)]

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_load_dominant_genetic']
    unittest.main()
