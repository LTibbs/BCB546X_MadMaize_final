
import unittest
from StringIO import StringIO

from pandas import Series

from variation.inout.genetic import (load_codominant_genetic_csv,
                                     load_markers_map)
from variation.analyses.phase import (_write_genotype_input_file,
                                      create_input_phase_files,
                                      run_fast_phase,
                                      parse_fast_phase_results)
from variation.analyses.matrix_tools import transpose_genotypes
from variation.utils import TemporaryDir


class PhaseTest(unittest.TestCase):
    'It tests the phase software'

    def test_create_input_files(self):
        'It creates a phase input file for PHASE and fastaPHASE'
        genotypes_data = '''indi1,indi2,indi3,indi4,indi5
marker1,AA,AA,GG,GG,GA
marker2,CC,GG,CG,CC,GC
marker3,CT,CC,TT,CT,CT
marker4,GG,AA,,AG,GG
marker5,,AT,AT,AA,AA
marker6,AC,AA,AC,CC,AA
'''
        # with ordered data of a single chromosome
        physical_map_data = '''marker,chromosome,position
marker1,1,20
marker6,1,45
marker2,1,25
marker4,1,35
marker3,1,30
marker5,1,40
marker7,2,45
'''
        genotype_fhand = StringIO(genotypes_data)
        physical_map_fhand = StringIO(physical_map_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)
        genotypes = transpose_genotypes(genotypes)
        physical_map = load_markers_map(physical_map_fhand, index_col=0,
                                        molecule_col='chromosome',
                                        location_col='position', sep=',')

        input_file_fhand = StringIO()
        snps = _write_genotype_input_file(input_file_fhand,
                                          genotypes, physical_map,
                                          chromosome=1)
        assert snps == ['marker1', 'marker2', 'marker3', 'marker4', 'marker5',
                        'marker6']
        input_file_fhand.seek(0)
        assert '5' in input_file_fhand.readline()
        assert '6' in input_file_fhand.readline()
        assert 'P 20 25 30 35 40 45' in input_file_fhand.readline()
        assert 'SSSSSS' in input_file_fhand.readline()
        assert '#indi1' in input_file_fhand.readline()
        assert 'ACCG?A' in input_file_fhand.readline()
        assert 'ACTG?C' in input_file_fhand.readline()

        # when missing some markers
        physical_map_data = '''marker,chromosome,position
marker1,1,20
marker3,1,30
marker5,1,40
marker4,1,35
'''
        physical_map_fhand = StringIO(physical_map_data)
        physical_map = load_markers_map(physical_map_fhand, index_col=0,
                                    molecule_col='chromosome',
                                    location_col='position', sep=',')

        input_file_fhand = StringIO()
        snps = _write_genotype_input_file(input_file_fhand, genotypes,
                                          physical_map, 1)
        assert snps == ['marker1', 'marker3', 'marker4', 'marker5']
        input_file_fhand.seek(0)
        assert '5' in input_file_fhand.readline()
        assert '4' in input_file_fhand.readline()
        assert 'P 20 30 35 40' in input_file_fhand.readline()
        assert 'SSSS' in input_file_fhand.readline()
        assert '#indi1' in input_file_fhand.readline()
        assert 'ACG?' in input_file_fhand.readline()
        assert 'ATG?' in input_file_fhand.readline()

        temp_dir = TemporaryDir()
        try:
            result = create_input_phase_files(genotypes, physical_map,
                                              dir_path=temp_dir.name)
            out_fhands = result['genotype_fhands']
            assert result['chrom_snps'] == [['marker1', 'marker3', 'marker4',
                                             'marker5']]
            assert len(out_fhands) == 1
            assert '5\n4\nP 20 30 35 40\n' in open(out_fhands[0].name).read()
        finally:
            temp_dir.close()

        # Now with a classification
        pops = ['pop1', 'pop1', 'pop2', 'pop2', 'pop1', 'pop3']
        indis = ['indi1', 'indi2', 'indi3', 'indi4', 'indi5', 'indi6']
        classification = Series(pops, index=indis)

        temp_dir = TemporaryDir()
        try:
            result = create_input_phase_files(genotypes, physical_map,
                                                  dir_path=temp_dir.name,
                                     individual_classification=classification)
            out_fhands = result['genotype_fhands']
            assert len(out_fhands) == 1
            assert '5\n4\nP 20 30 35 40\n' in open(out_fhands[0].name).read()

            pop_fhand = result['population_fhand']
            assert open(pop_fhand.name).read() == '1 1 2 2 1'
        finally:
            temp_dir.close()

    def test_do_fastPhase(self):
        'It tests that we can do a fastPhase analysis'

        genotypes_data = '''indi1,indi2,indi3,indi4,indi5
marker1,AA,AA,GG,GG,GA
marker2,CC,GG,CG,CC,GC
marker3,CT,CC,TT,CT,CT
marker4,GG,AA,,AG,GG
marker5,,AT,AT,AA,AA
marker6,AC,AA,AC,CC,AA
'''

        physical_map_data = '''marker,chromosome,position
marker1,1,20
marker6,1,45
marker2,1,25
marker4,2,35
marker3,2,30
marker5,2,40
'''
        pops = ['pop1', 'pop1', 'pop2', 'pop2', 'pop1', 'pop3']
        indis = ['indi1', 'indi2', 'indi3', 'indi4', 'indi5', 'indi6']
        classification = Series(pops, index=indis)

        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)
        physical_map_fhand = StringIO(physical_map_data)
        physical_map = load_markers_map(physical_map_fhand, index_col=0,
                                        molecule_col='chromosome',
                                        location_col='position', sep=',')

        #run fastPhasta in default mode without classification
        temp_dir = TemporaryDir()
        try:
            run_fast_phase(genotypes, physical_map, temp_dir.name)
        finally:
            temp_dir.close()

        #run fastPhasta in default mode with population classification
        temp_dir = TemporaryDir()
        try:
            run_fast_phase(genotypes, physical_map, temp_dir.name,
                           individual_classification=classification)
        finally:
            temp_dir.close()

        #run fastPhasta with population classification and input parameters
        parameters = ['-H200', '-i']
        temp_dir = TemporaryDir()
        try:
            run_fast_phase(genotypes, physical_map, temp_dir.name,
                           individual_classification=classification,
                           parameters=parameters)
            # read the results
            results = parse_fast_phase_results(temp_dir.name)
            assert 'individual_haplotypes' in results
            assert 'switch_haplotypes' in results
        finally:
            temp_dir.close()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_load_dominant_genetic']
    unittest.main()
