'''
Created on 20/08/2012

@author: jose
'''

import unittest
from cStringIO import StringIO

from pandas import Series

from variation.inout.genetic import (load_codominant_genetic_csv,
                                     load_markers_map)
from variation.analyses.rolling import (apply_rolling, rolling_average,
                                        rolling_std, rolling_window_genotypes)

# pylint: disable=R0201
# pylint: disable=R0904


class RollingTest(unittest.TestCase):
    'It tests the rolling functions'
    def test_apply_rolling(self):
        'It applies functions in a rolling manner'
        vector = Series([0, 2, 3, 4, 11, 12, 13],
                        index=[1, 2, 3, 4, 5, 6, 7])
        result = apply_rolling(vector, func=sum, window_width=3)
        assert list(result) == [3, 7, 5, 13]
        assert list(result.index) == [1.5, 4.5, 10.5, 13.5]

        result = apply_rolling(vector, func=sum, window_width=3, min_items=2)
        assert list(result) == [3, 7, 13]
        assert list(result.index) == [1.5, 4.5, 13.5]

    def test_rolling_average(self):
        'It calculates a rolling mean'
        vector = Series([0, 2, 3, 4, 11, 12, 13],
                        index=[1, 2, 3, 4, 5, 6, 7])
        result = rolling_average(vector, window_width=3)
        assert list(result) == [1.5, 3.5, 5.0, 6.5]
        assert list(result.index) == [1.5, 4.5, 10.5, 13.5]

    def test_rolling_std_dev(self):
        'It calculates a rolling standard deviation'
        vector = Series([0, 2, 3, 4, 11, 12, 13],
                        index=[1, 2, 3, 4, 5, 6, 7])
        result = rolling_std(vector, window_width=3, min_items=2)
        assert list(result) == [0.5, 0.5, 0.5]
        assert list(result.index) == [1.5, 4.5, 13.5]


class RollingWindowGenotypeTest(unittest.TestCase):
    'It tests the generation of genotypes along a map'
    def test_rolling_win_genotypes(self):
        'It generates genotypes along a map'
        data = '''marker1,marker2,marker3,marker4,marker5,marker6
indi1,AA,CG,GG,,AA,TT
indi2,AA,CG,GG,CC,AA,TT
indi3,GG,AA,AC,CC,GG,AT
indi4,GG,AA,AC,CC,GG,AT
'''
        fhand = StringIO(data)
        genotypes = load_codominant_genetic_csv(fhand,
                                                individuals_in_rows=True)
        map_ = 'chr,location\n'
        map_ += 'marker1,chr1,1\n'
        map_ += 'marker2,chr2,3\n'
        map_ += 'marker3,,\n'
        map_ += 'marker7,chr3,2\n'
        map_ += 'marker8,chr3,3\n'
        map_ += 'marker9,chr3,5\n'
        map_ += 'marker4,chr1,2\n'
        map_ += 'marker5,chr2,1\n'
        map_ += 'marker6,chr1,3\n'
        map_fhand = StringIO(map_)
        map_ = load_markers_map(map_fhand, molecule_col='chr',
                                location_col='location')
        wins = list(rolling_window_genotypes(genotypes, window_width=2,
                                             marker_map=map_))
        wins = [(w[0][0], int(w[0][1]), list(w[1].data.columns)) for w in wins]

        assert wins == [('chr2', 1, ['marker5']),
                        ('chr2', 3, ['marker2']),
                        ('chr1', 1, ['marker1', 'marker4']),
                        ('chr1', 3, ['marker6'])]

        wins = list(rolling_window_genotypes(genotypes, window_width=2,
                                             overlapping_windows=True))
        wins = [(w[0][0], int(w[0][1]), list(w[1].data.columns)) for w in wins]

        assert wins == [('chrom', 0, ['marker1', 'marker2']),
                        ('chrom', 1, ['marker2', 'marker3']),
                        ('chrom', 2, ['marker3', 'marker4']),
                        ('chrom', 3, ['marker4', 'marker5']),
                        ('chrom', 4, ['marker5', 'marker6']),
                        ('chrom', 5, ['marker6'])]

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_load_dominant_genetic']
    unittest.main()
