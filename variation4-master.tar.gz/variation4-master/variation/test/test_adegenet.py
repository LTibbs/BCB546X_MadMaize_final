
import unittest

from StringIO import StringIO
from tempfile import NamedTemporaryFile
from pandas import Series

from variation.inout.genetic import load_codominant_genetic_csv
from variation.analyses.adegenet import create_file_snp_fomat


class TestAdegenet(unittest.TestCase):
    'It test functions to create input data for Adegenet (R package)'
    def test_create_file_snp_fomat(self):
        genotypes_data = '''indi1,indi2,indi3,indi4,indi5
marker1,AA,AA,GG,GG,GA
marker2,CC,GG,CG,CC,GC
marker3,CT,CC,TT,CT,CT
marker4,GG,AA,,AG,GG
marker5,,AT,AT,AA,AA
marker6,AC,AA,AC,CC,AA
'''
        pops = ['pop1', 'pop1', 'pop2', 'pop2', 'pop1', 'pop3']
        indis = ['indi1', 'indi2', 'indi3', 'indi5', 'indi4', 'indi6']
        classification = Series(pops, index=indis)

        genotype_fhand = StringIO(genotypes_data)
        genotypes = load_codominant_genetic_csv(genotype_fhand,
                                                individuals_in_rows=False)

        fhand = NamedTemporaryFile()
        create_file_snp_fomat(fhand, genotypes)
        fhand.seek(0)
        result = '''>>>> begin comments - do not remove this line <<<<
>>>> end comments - do not remove this line <<<<
>> ploidy
2
> indi1
0010-1
> indi2
020210
> indi3
212-11
> indi4
201102
> indi5
111000
'''
        assert result in fhand.read()
        fhand.close()

        #with individual classification
        fhand = NamedTemporaryFile(suffix='.snp')
        create_file_snp_fomat(fhand, genotypes, classification)
        fhand.seek(0)
        result = '''>>>> begin comments - do not remove this line <<<<
>>>> end comments - do not remove this line <<<<
>> ploidy
2
>> population
pop1 pop1 pop2 pop1 pop2
> indi1
0010-1
> indi2
020210
> indi3
212-11
> indi4
201102
> indi5
111000
'''
        assert result == fhand.read()
        fhand.close()


if __name__ == "__main__":
    unittest.main()