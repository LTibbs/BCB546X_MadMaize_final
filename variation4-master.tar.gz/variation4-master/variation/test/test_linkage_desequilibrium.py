
import unittest
from StringIO import StringIO

from variation.inout.genetic import (load_codominant_genetic_csv,
                                     load_markers_map)

from variation.analyses.linkage_desequilibrium import (esem_r, get_r,
                                                       calculate_unphased_LD)
from pandas.io.parsers import read_csv
from pandas.core.series import Series
from variation.inout.dataframe import load_dataframe_csv


class linkage_estimatorsTest(unittest.TestCase):
    '''It tests the functions of linkage_desequilibrium estimators: Rogers-Huff
    estimator and Excoffier-Slatkin estimator
    '''

    def test_Rogers_Huff_estimator(self):
        alleles_locus1 = [2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0,
                          1, 1]
        alleles_locus2 = [2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0, 1, 1, 2, 0,
                          1, 1]

        r = get_r(alleles_locus1, alleles_locus2)
        r_expected = 1.0
        assert r_expected == r

    def test_Excoffier_Slatkin_estimator(self):
        alleles_locus1 = [2, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 2, 2, 1,
                          2, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 2, 1, 1, 1, 1, 1,
                          0, 0, 0, 1, 0, 2, 0, 1, 1, 0, 1, 1, 0, 0]

        alleles_locus2 = [2, 1, 2, 2, 2, 2, 1, 2, 2, 2, 0, 2, 1, 2, 2, 2, 2, 1,
                          2, 1, 2, 1, 2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 2,
                          2, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 2, 1, 1]

        r = esem_r(alleles_locus1, alleles_locus2)
        r_expected = 0.374999919073

        assert abs(r - r_expected) < 0.001


class linkagedesequilibriumTest(unittest.TestCase):

    def test_calculate_unphased_LD(self):
        genotypes_data = '''indi1,indi2,indi3,indi4
marker1,AA,AG,,GG
marker2,CC,CG,CG,CC
marker3,CC,CT,CT,CT
marker4,GG,AA,AG,
marker5,AA,TT,AT,
marker6,AA,CC,AC,CC
'''
        physical_map_data = '''chromosome,position
marker1,1,2
marker2,1,7
marker3,2,5
marker4,1,4
marker5,2,6
marker6,2,2
'''
        genotypes = load_codominant_genetic_csv(StringIO(genotypes_data),
                                                individuals_in_rows=False)
        physical_map = load_markers_map(StringIO(physical_map_data),
                                        molecule_col='chromosome',
                                        location_col='position')
        LD_results = calculate_unphased_LD(genotypes, physical_map,
                                           within_chromosome=True,
                                           method='Rogers-Huff')
        assert  LD_results.loc['marker3-marker5', 'LD'] - 0.8660254 < 0.0001

        classification_data = '''group
indi1,group1
indi2,group2
indi3,group1
indi4,group2
'''
        genotypes = load_codominant_genetic_csv(StringIO(genotypes_data),
                                                individuals_in_rows=False)
        physical_map = load_markers_map(StringIO(physical_map_data),
                                        molecule_col='chromosome',
                                        location_col='position')
        classification = load_dataframe_csv(StringIO(classification_data)).data
        LD_results = calculate_unphased_LD(genotypes, physical_map,
                                          classification, method='Rogers-Huff')
        assert LD_results.loc['marker1-marker2', 'LD_group2'] == -1
        assert LD_results.loc['marker3-marker5', 'LD_group1'] == 1
        assert len(LD_results.columns) == 8


if __name__ == '__main__':
    unittest.main()
