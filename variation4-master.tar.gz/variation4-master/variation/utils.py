'''
Created on 08/03/2012

@author: jose
'''

import platform
from os.path import abspath, join, split, exists
import shutil
import tempfile
import sys
import subprocess


def get_binary_path(binary_name):
    '''It return the path to the proper binary. It looks on platform and
    architecture to decide it.

    Fails if there is not binary for that architecture
    '''
    system = platform.system().lower()
    if system == 'windows':
        binary_name += '.exe'
    arch = platform.architecture()[0]

    module_path = split(__file__)[0]
    third_party_path = join(module_path, 'third_party', 'bin')
    if not exists(third_party_path):
        msg = 'Third party bin directory not found, please fixme.'
        raise RuntimeError(msg)

    binary_path = abspath(join(third_party_path, system, arch, binary_name))

    if exists(binary_path):
        return binary_path
    elif arch == '64bit':
        arch = '32bit'
        binary_path = abspath(join(third_party_path, system, arch,
                                   binary_name))
        if exists(binary_path):
            return binary_path

    # At this point there is not available binary for the working platform
    msg = '{} not available for this platform: {}'.format(binary_name, system)
    raise RuntimeError(msg)


def check_finished_process(process, binary, stdout=None, stderr=None):
    'It checks that the given process finished OK, otherwise raises an Error'
    returncode = process.returncode
    if returncode == 0:
        return
    elif returncode is None:
        msg = 'The process for {:s} is still running with PID'
        msg = msg.format(binary, process.pid)
        raise RuntimeError(msg)
    if stdout is None:  # It was a Pipe?
        stdout = process.stdout
    else:
        stdout = open(stdout.name).read()

    if stderr is None:  # It was a Pipe?
        stderr = process.stderr
    else:
        stderr = open(stderr.name).read()
    msg = '{:s} had a problem running\n'.format(binary)
    if stdout:
        msg += 'stdout:\n{:s}\n'.format(stdout)
    if stderr:
        msg += 'stderr:\n{:s}\n'.format(stderr)
    raise RuntimeError(msg)


class TemporaryDir(object):
    '''This class creates temporary directories '''
    def __init__(self, suffix='', prefix='', directory=None):
        '''It initiates the class.'''
        self._name = tempfile.mkdtemp(suffix=suffix, prefix=prefix,
                                      dir=directory)

    def get_name(self):
        'Returns path to the dict'
        return self._name
    name = property(get_name)

    def close(self):
        '''It removes the temp dir'''
        if exists(self._name):
            shutil.rmtree(self._name)


def run_wrapped_cmd(cmd, working_dir):
    '''It runs the command inside a temporal directory.

    It changes the working directory to the temporal directory created before
    running the command.
    '''
    stdout = tempfile.NamedTemporaryFile(delete=False, dir=working_dir)
    stderr = tempfile.NamedTemporaryFile(delete=False, dir=working_dir)
    script_fhand = tempfile.NamedTemporaryFile(delete=False, dir=working_dir)
    script_fhand.write('import os\n')
    script_fhand.write('import sys\n')
    script_fhand.write('import subprocess\n')
    script_fhand.write('os.chdir("{:s}")\n'.format(working_dir))
    script_fhand.write('retcode = subprocess.call(' + repr(cmd))
    script_fhand.write(', stdout=open("{:s}", "w")'.format(stdout.name))
    script_fhand.write(', stderr=open("{:s}", "w")'.format(stderr.name))
    script_fhand.write(')\n')
    script_fhand.write('sys.exit(retcode)\n')
    script_fhand.flush()

    python = sys.executable
    script_stderr = tempfile.NamedTemporaryFile(delete=False, dir=working_dir)
    process = subprocess.Popen([python, script_fhand.name],
                               stderr=script_stderr)
    return process, open(stdout.name), open(stderr.name)
