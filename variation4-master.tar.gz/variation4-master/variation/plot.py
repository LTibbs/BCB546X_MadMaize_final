'''
Created on 05/03/2012

@author: jose
'''

from __future__ import division

import os.path
import colorsys
import operator

import numpy

from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.colors import colorConverter
from matplotlib.cm import get_cmap, ScalarMappable
import matplotlib.lines as mlines
import matplotlib
from mpl_toolkits.basemap import Basemap

from pandas import Series

from variation.matrixwithmeta import is_vector

VALID_MARKERS = ['o', 'd', '+', '^', 'p', 'x', '<', '>', 'v', 'h', 's', '*',
                 '1', '2', '3', '4', '8', '9', '&', '$', '-', 'w', 'z']
COLOR_CYCLE = ['#010202', '#EE2E2F', '#008C48', '#185AA9', '#F47D23',
               '#662C91', '#A21D21', '#B43894']
FIGURE_DPI = 600.0
FIGURE_SIZE = (15.0, 11.0)  # inches
HORIZONTAL_MARGINS = 0.05  # from 0 to 1
VERTICAL_MARGINS = 0.05
MARKER_SIZE = 20.0  # in points 1/72 inch
MARKER_SIZE2 = 150
MARKER_SIZE3 = 7.0
MARKER_LINE_WIDTH = 2.0
LINEWIDTH = 1.0
PATCH_LINEWIDTH = 0.5
PATCH_FACECOLOR = '#348ABD'
PATCH_EDGECOLOR = '#eeeeee'
ANTIALIASED = True
FACECOLOR = '#348ABD'
EDGECOLOR = '#eeeeee'
AXES_FACECOLOR = '#ffffff'  # '#eeeeee'
AXES_EDGECOLOR = '#bcbcbc'
AXES_LINEWIDTH = 1
AXES_GRID = False
AXES_MARGIN = 0.025
LEGEND_MARKER_SCALE = 0.65
LEGEND_FONT_SIZE = 17.0
LEGEND_SIZE = 3  # inches
LEGEND_CANVAS_PERCENT_SIZE = LEGEND_SIZE / FIGURE_SIZE[0] * 100
FONT_SIZE = 12.0
AXIS_LABELS_FONT_SIZE = 17.0
MONOSPACE_FAMILY = 'Ubuntu, Andale Mono, Nimbus Mono L, Courier New, Courier,'
MONOSPACE_FAMILY += 'Fixed, Terminal, monospace'

LONLAT_MARGIN = 0.1
BORDER_COLOR = '#929298'
BORDER_LINEWIDTH = 2.0
COASTLINE_COLOR = BORDER_COLOR
COASTLINE_LINEWIDTH = BORDER_LINEWIDTH
MAPBOUNDARY_COLOR = 'white'
MAPBOUNDARY_LINEWIDTH = 1.0
CONTINENT_COLOR = '#f6eee7'
OCEAN_COLOR = '#9cb5ce'
RIVER_COLOR = '#d9dce0'
RIVER_LINEWIDTH = 0  # 1.0
LAKE_COLOR = RIVER_COLOR


COLOR_PALLETE_HUE_LIMITS = 0.01, 0.99
COLOR_PALLETE_SATURATION_LIMITS = 1.0, 0.5
COLOR_PALLETE_MAX_HUES = 6
DEFAULT_CMAP = 'cool'

if True:
    matplotlib.rcParams['lines.linewidth'] = LINEWIDTH
    matplotlib.rcParams['lines.antialiased'] = ANTIALIASED
    matplotlib.rcParams['lines.markersize'] = MARKER_SIZE
    matplotlib.rcParams['lines.markeredgewidth'] = MARKER_LINE_WIDTH

    matplotlib.rcParams['patch.linewidth'] = PATCH_LINEWIDTH
    matplotlib.rcParams['patch.facecolor'] = PATCH_FACECOLOR
    #matplotlib.rcParams['patch.edgecolor'] = PATCH_EDGECOLOR
    matplotlib.rcParams['patch.antialiased'] = ANTIALIASED
    matplotlib.rcParams['font.family'] = 'monospace'
    matplotlib.rcParams['font.size'] = 8.0
    matplotlib.rcParams['font.monospace'] = MONOSPACE_FAMILY
    matplotlib.rcParams['axes.facecolor'] = AXES_FACECOLOR
    matplotlib.rcParams['axes.edgecolor'] = AXES_EDGECOLOR
    matplotlib.rcParams['axes.linewidth'] = AXES_LINEWIDTH
    matplotlib.rcParams['axes.grid'] = AXES_GRID
    matplotlib.rcParams['axes.titlesize'] = 'x-large'
    matplotlib.rcParams['axes.labelsize'] = 'large'
    matplotlib.rcParams['axes.labelcolor'] = '#555555'
    matplotlib.rcParams['axes.axisbelow'] = True
    # the following line is not compatible with some matplotlib versions
    # matplotlib.rcParams['axes.color_cycle'] = COLOR_CYCLE
    matplotlib.rcParams['xtick.major.size'] = 6
    matplotlib.rcParams['xtick.minor.size'] = 3
    matplotlib.rcParams['xtick.major.pad'] = 6
    matplotlib.rcParams['xtick.minor.pad'] = 6
    matplotlib.rcParams['xtick.color'] = '#555555'
    matplotlib.rcParams['xtick.direction'] = 'in'
    matplotlib.rcParams['ytick.major.size'] = 6
    matplotlib.rcParams['ytick.minor.size'] = 3
    matplotlib.rcParams['ytick.major.pad'] = 6
    matplotlib.rcParams['ytick.minor.pad'] = 6
    matplotlib.rcParams['ytick.color'] = '#555555'
    matplotlib.rcParams['ytick.direction'] = 'in'
    matplotlib.rcParams['legend.fancybox'] = True
    matplotlib.rcParams['font.size'] = FONT_SIZE


class MarkerMap(dict):
    '''A dict that returns valid markers to unset keys.

    This is the default MarkerMap, any dict with the possible classes for the
    markers as keys would do.
    This special dict provides one VALID_MARKER for every key asked.
    '''
    def __init__(self, *kargs, **kwargs):
        'It inits the mapper'
        super(MarkerMap, self).__init__(*kargs, **kwargs)

    def _get_valid_marker(self):
        'It returns a new valid marker'
        markers_used = len(self)
        return VALID_MARKERS[markers_used]

    def __getitem__(self, key):
        'It returns VALID_MARKERS for every key.'
        if key not in self:
            # we need a marker for this new key
            try:
                marker = self._get_valid_marker()
            except IndexError:
                msg = 'No marker for:' + str(key)
                raise KeyError(msg)
            self[key] = marker
        marker = super(MarkerMap, self).__getitem__(key)
        return marker


def html_to_rgb_color(color):
    'It returns a tuple (coded from 0 to 255) from an rgb hex color'

    if color.startswith('#'):
        color = color[1:]
    red = int(color[0:2], 16)
    green = int(color[2:4], 16)
    blue = int(color[4:6], 16)
    return red, green, blue


def _rgb_to_html_color(rgb_tuple):
    'It returns an rgb hex color from an rgb tuple (coded from 0 to 1)'
    rgb_tuple = tuple((rgb * 255 for rgb in rgb_tuple))
    rgb_hex = '#%02x%02x%02x' % rgb_tuple
    return rgb_hex


def create_color_palette(num_colors, hue_limits=COLOR_PALLETE_HUE_LIMITS,
                         saturation_limits=COLOR_PALLETE_SATURATION_LIMITS,
                         max_hues=COLOR_PALLETE_MAX_HUES):
    '''It returns a list of colors

    It creates a color palette trying to create as different colors as
    possible.
    The hues will range between the hue_limits. If more num_colors are asked
    than the max_hues given different saturation will be used.
    '''
    if num_colors <= len(COLOR_CYCLE):
        return COLOR_CYCLE[:num_colors]
    # http://en.wikipedia.org/wiki/HLS_color_space
    # HLS: Hue, Luminance, Saturation
    sat_limits = saturation_limits
    max_hue_slices = max_hues

    # Which are going to be the colors?
    indexes = {}
    hue_index = 0
    sat_index = 0
    max_hue = 0
    sats_used = set()
    # pylint: disable=W0612
    for index in range(num_colors):
        odd_sat_row = (sat_index) % 2
        real_hue = hue_index + 0.5 * odd_sat_row
        if real_hue not in indexes:
            indexes[real_hue] = []
        indexes[real_hue].append(sat_index)
        sats_used.add(sat_index)
        hue_index += 1
        if real_hue > max_hue:
            max_hue = real_hue
        if hue_index >= (max_hue_slices - odd_sat_row):
            hue_index = 0
            sat_index += 1

    # hue 0 == hue 1 so we have to remove a little delta to the hue
    used_hues = len(indexes)
    hue_limit1 = (hue_limits[1] - hue_limits[0]) * (used_hues - 1) / used_hues
    hue_limits = hue_limits[0], hue_limit1

    # normalize hue to hue limits
    if max_hue:
        hue_slope = (hue_limits[1] - hue_limits[0]) / max_hue
    if len(sats_used) > 1:
        sat_slope = (sat_limits[1] - sat_limits[0]) / max(sats_used)
    else:
        sat_slope = None
    nindexes = {}
    for hue, sats in indexes.items():
        if max_hue:
            nhue = hue * hue_slope + hue_limits[0]
        else:
            nhue = hue_limits[1]
        if sat_slope is None:
            nsats = [sat_limits[0]]
        else:
            nsats = [sat * sat_slope + sat_limits[0] for sat in sats]

        nindexes[nhue] = nsats
    indexes = nindexes

    # the ordering
    hues = indexes.keys()
    hues.sort()
    rgbs = []
    luminance = 0.5
    for hue in hues:
        sats = indexes[hue]
        for sat in sats:
            rgb = colorsys.hls_to_rgb(hue, luminance, sat)
            rgb_hex = _rgb_to_html_color(rgb)
            rgbs.append(rgb_hex)
    return rgbs


class ColorMap(dict):
    '''A dict that returns valid colors to unset keys.

    This is the default ColroMap, any dict with the possible classes for the
    colors as keys would do.
    This special dict provides one for every key asked.
    '''
    def __init__(self, *kargs, **kwargs):
        '''It inits the mapper

        It will accept num_colors to create color palettes.
        '''
        if 'num_colors' in kwargs:
            num_colors = kwargs['num_colors']
            del kwargs['num_colors']
        else:
            num_colors = None
        if (num_colors is not None and num_colors <= len(COLOR_CYCLE) or
           num_colors is None):
            self._color_cycle = COLOR_CYCLE
        else:
            self._color_cycle = create_color_palette(num_colors)
        super(ColorMap, self).__init__(*kargs, **kwargs)

    def _get_valid_color(self):
        'It returns a new valid marker'
        colors_used = len(self)
        return self._color_cycle[colors_used]

    def __getitem__(self, key):
        'It returns VALID_COLORs for every key.'
        if key not in self:
            # we need a marker for this new key
            try:
                marker = self._get_valid_color()
            except IndexError:
                msg = 'No color for: ' + key
                raise KeyError(msg)
            self[key] = marker
        color = super(ColorMap, self).__getitem__(key)
        return color


def _is_valid_color(color):
    'It returns True if the color would be recognized by matplotlib'
    try:
        colorConverter.to_rgb(color)
        return True
    except ValueError:
        return False


def get_scatter_groups_from_matrix(dframe, x_col, y_col, marker_col=None,
                                   marker_mapper=None, color_col=None,
                                   color_mapper=None, y_error_bars_col=None,
                                   y_error_bars_col_upper=None):
    '''It returns a list of series to be plotted.'''

    if ((color_mapper is None and color_col is not None) and
        (dframe[color_col].dtype != numpy.float64)):
        n_colors = len(set(dframe[color_col].values))
        color_map = ColorMap(num_colors=n_colors)
    else:
        color_map = color_mapper

    # Now we build one series for every marker and color combination
    cols_to_group_by = []
    if marker_col:
        cols_to_group_by.append(marker_col)
    if color_col and color_map is not None:
        cols_to_group_by.append(color_col)

    if cols_to_group_by:
        groups = dframe.groupby(cols_to_group_by).groups
    else:
        groups = {'series': dframe.index}

    row_names = list(dframe.index)

    if marker_mapper is None and marker_col is not None:
        marker_map = MarkerMap()
    else:
        marker_map = marker_mapper

    series = {}
    for series_key, rows in groups.viewitems():
        if len(cols_to_group_by) == 1:
            series_label = str(series_key)
        else:
            series_label = '_'.join(map(str, series_key))
        series_index = [row_names[row_names.index(i)] for i in rows]
        series[series_label] = {'label': series_label,
                                'x': dframe[x_col][rows],
                                'y': dframe[y_col][rows]}
        series[series_label]['x'].index = series_index
        series[series_label]['y'].index = series_index
        if marker_col is not None:
            marker = dframe.get_value(rows[0], marker_col)
            series[series_label]['marker'] = marker_map[marker]
        if color_col is not None:
            if color_map is not None:
                # the color is a single label, the same for all rows
                color = dframe.get_value(rows[0], color_col)
                color = color_map[color]
            else:
                # the colors are a vector of floats
                color = dframe[color_col][rows]
            series[series_label]['color'] = color
        if y_error_bars_col is not None:
            if y_error_bars_col_upper is None:
                error_bars = dframe[y_error_bars_col][rows]
            else:
                error_bars = (dframe[y_error_bars_col][rows],
                              dframe[y_error_bars_col_upper][rows])
            series[series_label]['y_error_bars'] = error_bars
    return list(series.viewvalues())


def scatter_groups(groups, fhand, labels=False, canvas=None, axes=None,
                   plot_lines=False, alpha=0.7, marker_size=MARKER_SIZE2,
                   xlabel=None, ylabel=None):
    '''Given a list of dicts (groups) of points to be plot it scatters them.

    Every dict (group) should have at least an x and and y key. They also
    can have a label, color and marker.
    '''
    if canvas is None or axes is None:
        canvas, axes = _get_canvas_and_axes()

    kwargs = {}
    if all([is_vector(group.get('color', None)) for group in groups]):
        max_, min_ = None, None
        for group in groups:
            color = group.get('color', None)
            gmax = max(color)
            gmin = min(color)
            if max_ is None or max_ < gmax:
                max_ = gmax
            if min_ is None or min_ > gmin:
                min_ = gmin
        kwargs['vmax'] = max_
        kwargs['vmin'] = min_
        cmap = get_cmap(DEFAULT_CMAP)
        kwargs['cmap'] = cmap

    for index, group in enumerate(groups):
        x_vals = group['x']
        y_vals = group['y']
        if 'label' in group:
            label = group['label']
        else:
            label = 'series_{:d}'.format(index)
        color = group.get('color', None)
        if color is None:
            color = COLOR_CYCLE[0]
        marker = group.get('marker', None)
        if marker is None:
            marker = VALID_MARKERS[0]
        kwargs['marker'] = marker
        kwargs['c'] = color
        kwargs['label'] = label
        kwargs['alpha'] = alpha

        if plot_lines:
            kwargs['ms'] = 0  # MARKER_SIZE3
            kwargs['mec'] = color
            kwargs['mfc'] = color
            kwargs['linewidth'] = 5
            axes.plot(x_vals, y_vals, **kwargs)
        else:
            kwargs['s'] = marker_size
            kwargs['edgecolors'] = color
            try:
                axes.scatter(x_vals, y_vals, **kwargs)
            except AssertionError:
                # There are errors with markers not supported
                print kwargs
                raise

        if 'y_error_bars' in group:
            axes.errorbar(x_vals, y_vals, yerr=group['y_error_bars'],
                          fmt=None, ecolor=color)

    if labels:
        for group in groups:
            x_vals = group['x']
            y_vals = group['y']
            labels = x_vals.index
            x_label_vals, y_label_vals = [], []
            for label in labels:
                x_label_vals.append(x_vals[label])
                y_label_vals.append(y_vals[label])
            _plot_labels(x_label_vals, y_label_vals, labels, axes)

    if xlabel:
        axes.set_xlabel(xlabel)
    if ylabel:
        axes.set_ylabel(ylabel)

    _add_legend(axes)
    canvas.print_figure(fhand, format=_get_format_from_fname(fhand.name))
    fhand.flush()


def _calcuate_lon_lat_limits(longitudes, latitudes):
    'Given a list of longitudes and latitudes it returns the limits'
    not_none = lambda x: x is not None
    lon_max = max(longitudes)
    lon_min = min(filter(not_none, longitudes))
    lat_max = max(latitudes)
    lat_min = min(filter(not_none, latitudes))

    # some margin 10%
    incr = abs(lat_max - lat_min) * LONLAT_MARGIN
    # incr = 0
    lat_max += incr
    lat_min -= incr
    incr = abs(lon_max - lon_min) * LONLAT_MARGIN
    lon_max += incr
    lon_min -= incr

    if lat_min < -90:
        lat_min = -90
    if lat_max > 90:
        lat_max = 90
    if lon_min < -180:
        lon_min = -180
    if lon_max > 180:
        lon_max = 180

    return lon_min, lon_max, lat_min, lat_max


def _create_basemap_instance(axes, limits, satellite=False,
                             background_image=None):
    'It returns a basemap instance'
    lon_min, lon_max, lat_min, lat_max = limits

    projection = 'merc'
    resolution = 'l'  # crude
    # resolution = 'h' #high
    map_ = Basemap(projection=projection, resolution=resolution,
                   llcrnrlon=lon_min, llcrnrlat=lat_min,
                   urcrnrlon=lon_max, urcrnrlat=lat_max)
    if satellite:
        map_.bluemarble(ax=axes)
    elif background_image is not None:
        if background_image is not None:
            map_.warpimage(image=background_image, ax=axes)
            map_.drawmapboundary(color=MAPBOUNDARY_COLOR,
                                 linewidth=MAPBOUNDARY_LINEWIDTH,
                                 fill_color=OCEAN_COLOR,
                                 zorder=0, ax=axes)
            if BORDER_LINEWIDTH:
                map_.drawcountries(linewidth=BORDER_LINEWIDTH,
                                   color=BORDER_COLOR,
                                   zorder=1, ax=axes)
    else:

        # draw coastlines
        if COASTLINE_COLOR is not None:
            map_.drawcoastlines(linewidth=COASTLINE_LINEWIDTH,
                               color=COASTLINE_COLOR,
                               zorder=0, ax=axes)
        # draw a boundary around the map, fill the background.
        # this background will end up being the ocean color, since
        # the continents will be drawn on top.
        map_.drawmapboundary(color=MAPBOUNDARY_COLOR,
                            linewidth=MAPBOUNDARY_LINEWIDTH,
                            fill_color=OCEAN_COLOR,
                            zorder=0, ax=axes)
        # fill continents, set lake color same as ocean color.
        map_.fillcontinents(color=CONTINENT_COLOR, lake_color=LAKE_COLOR,
                           zorder=0, ax=axes)
        # draw the country borders
        if BORDER_LINEWIDTH:
            map_.drawcountries(linewidth=BORDER_LINEWIDTH, color=BORDER_COLOR,
                              zorder=1, ax=axes)
        if RIVER_LINEWIDTH:
            map_.drawrivers(linewidth=RIVER_LINEWIDTH, color=RIVER_COLOR,
                           zorder=1, ax=axes)
    return map_


def geographic_map(groups, fhand, labels=False, satellite=False,
                   background_image=None, limits=None, alpha=None,
                   marker_size=None):
    '''It draws a geographic map

    Every dict (group) should have at least an x (longitude) and and
    y (latitude)key. They also can have a label, color and marker.
    limits should be a tuple of (lon-min, lon-max, lat-min, lat-max)
    '''
    canvas, axes = _get_canvas_and_axes()

    # delimit the geographic region of interest
    if not limits:
        lons = [x for g in groups for x in g['x']]
        lats = [y for g in groups for y in g['y']]
        limits = _calcuate_lon_lat_limits(lons, lats)
    map_ = _create_basemap_instance(axes, limits, satellite=satellite,
                                    background_image=background_image)

    # we map lon lat to x,y
    mapped_groups = []
    for group in groups:
        mapped_group = group.copy()
        index = mapped_group['x'].index
        x_vals, y_vals = map_(mapped_group['x'], mapped_group['y'])
        mapped_group['x'] = Series(x_vals, index=index)
        mapped_group['y'] = Series(y_vals, index=index)
        mapped_groups.append(mapped_group)

    kwargs = {'labels': labels, 'canvas': canvas, 'axes': axes}
    if alpha:
        kwargs['alpha'] = alpha
    if marker_size:
        kwargs['marker_size'] = marker_size
    scatter_groups(mapped_groups, fhand, **kwargs )


def scatter_series(x_values, y_values, fhand, marker=VALID_MARKERS[0],
                   color=COLOR_CYCLE[0], labels=False, strict=True,
                   **scatter_kwargs):
    '''Given two series it plots an scatter plot.

    It will check the indexes of both series to make sure that the labels
    match.
    '''
    common_items = list(set(x_values.index).intersection(y_values.index))
    if strict:
        n_common = len(common_items)
        if n_common != len(x_values):
            msg = 'The indexes of the x and y values do not have the same '
            msg += 'items. E.g.: '
            diff = set(x_values.index).symmetric_difference(y_values.index)
            diff = list(diff)[:3]
            msg += ', '.join(diff)
            raise ValueError(msg)
    x_vals, y_vals = [], []
    for item in common_items:
        x_vals.append(x_values[item])
        y_vals.append(y_values[item])
    canvas, axes = _get_canvas_and_axes()

    kwargs = {'marker': marker, 's': MARKER_SIZE2}
    kwargs.update(scatter_kwargs)

    cmap = get_cmap(DEFAULT_CMAP)
    kwargs['cmap'] = cmap

    kwargs['c'] = color

    if isinstance(x_vals, Series):
        x_vals = x_vals.data
    if isinstance(y_vals, Series):
        y_vals = y_vals.data
    axes.scatter(x_vals, y_vals, **kwargs)

    if labels:
        _plot_labels(x_vals, y_vals, common_items, axes)
    canvas.print_figure(fhand, format=_get_format_from_fname(fhand.name))
    fhand.flush()


def _plot_labels(x_vals, y_vals, labels, axes, label_position='left'):
    'It places the labels in the plot'

    ymin, ymax = axes.get_ylim()
    if label_position == 'left':
        xmin, xmax = axes.get_xlim()
        xdelta = (xmax - xmin) / 50
        ydelta = -(ymax - ymin) / 200
    elif label_position == 'bottom':
        xdelta = 0
        ydelta = -(ymax - ymin) / 100
    for x_val, y_val, label in zip(x_vals, y_vals, labels):
        axes.text(x_val + xdelta, y_val + ydelta, label)


def _get_format_from_fname(fname):
    'It returns the extension as the format for the file'
    return os.path.splitext(fname)[1][1:]


def histogram(data, fhand, range_=None):
    'It draws a histogram of a pandas Series into a file'
    canvas, axes = _get_canvas_and_axes()

    axes.hist(data.values, range=range_)

    canvas.print_figure(fhand, format=_get_format_from_fname(fhand.name))
    fhand.flush()


def stacked_histogram(data, fhand, range_=None, normed=False, label=None):
    'It draws a histogram of a list of pandas Series into a file'
    canvas, axes = _get_canvas_and_axes()

    axes.hist(data, range=range_, normed=normed, label=label)
    if label is not None:
        axes.legend()
    canvas.print_figure(fhand, format=_get_format_from_fname(fhand.name))
    fhand.flush()


def _get_canvas_and_axes(figure_size=FIGURE_SIZE, left=0.1, right=0.9, top=0.9,
                         bottom=0.1):
    'It returns a matplotlib canvas and axes instance'
    fig = Figure(figsize=figure_size)
    canvas = FigureCanvas(fig)
    axes = fig.add_subplot(111)
    fig.subplots_adjust(left=left, right=right, top=top, bottom=bottom)

    return canvas, axes


def _calculate_group_tags_and_lines(classification, item_width):
    'It returns the group labels and the x locations for them'
    prior_klass = None
    min_index = None
    labels = []
    line_locs = []
    item_loc_left = lambda x: item_width * (x - 0.5)
    item_loc_right = lambda x: item_width * (x + 0.5)
    for index, klass in enumerate(classification):
        if min_index is None:
            min_index = index
        if klass != prior_klass:
            if prior_klass is not None:
                labels.append(prior_klass)
                line_locs.append((item_loc_left(min_index),
                                   item_loc_right(index - 1)))
                min_index = index
        prior_klass = klass
    else:
        labels.append(klass)
        line_locs.append((item_loc_left(min_index),
                           item_loc_right(index)))

    # where do we put the labels
    label_locs = [(i[0] + i[1]) / 2 for i in line_locs]
    line_locs = [i[1] + item_width / 2 for i in line_locs]
    return labels, label_locs, line_locs


def _draw_vertical_lines(y_min, y_max, x_locs, axes):
    'It draws a list of vertical lines'
    linewidth = 4
    color = 'black'
    lines = []
    for x_loc in x_locs:
        line = mlines.Line2D((x_loc, x_loc), (y_min, y_max),
                             linewidth=linewidth, color=color)
        lines.append(line)
        axes.add_line(line)
    return lines


def _write_texts(texts, xlocs, ylocs, axes):
    'It writes the given texts in the axes'
    mlib_items = []
    for index, text in enumerate(texts):
        mlib_items.append(axes.text(xlocs[index], ylocs[index], text,
                                    # horizontalalignment='center',
                                    fontsize=AXIS_LABELS_FONT_SIZE))
    return mlib_items


def _add_legend(axes):
    'It adds the legend to the plot'
    box = axes.get_position()
    size_without_legend = box.width * (100 - LEGEND_CANVAS_PERCENT_SIZE) / 100
    axes.set_position([box.x0, box.y0, size_without_legend, box.height])

    handles, labels = axes.get_legend_handles_labels()
    if not handles:
        return

    # sort by the labels
    # pylint: disable=W0142
    handel_lables = sorted(zip(handles, labels), key=operator.itemgetter(1))
    handles, labels = zip(*handel_lables)

    legend = axes.legend(handles, labels, bbox_to_anchor=(1.05, 1), loc=2,
                         borderaxespad=0., prop={'size': LEGEND_FONT_SIZE},
                         fancybox=True, numpoints=1)
    return legend


def stacked_bars(matrix, fhand, bar_colors=None, classification=None,
                 y_error_bars_lower=None, y_error_bars_upper=None):
    '''It draws stacked columns.

    Every matrix row will became a stacked column in the chart.
    The classification should be a list or Series with the classification
    (e. g. the population of origin) for every matrix row. This classification
    will be used to write labels above the plot and to divide the columns with
    line by rows belonging to the same classification class.
    '''
    # The classification could be a dict with the row names as keys, but
    # I fell that it is more correct to use list-like objects for it because
    # there is no dicts usually in the plotting APIs.

    bar_width = 1
    nrows, ncols = matrix.shape

    # figure size
    bars_in_std_size = 20
    axes_left = 0.1
    axes_right = 0.9
    axes_top = 0.9
    axes_bottom = 0.1
    fig_x_size = (axes_right - axes_left) * FIGURE_SIZE[0] / bars_in_std_size * nrows + LEGEND_SIZE
    fig_size = (fig_x_size, FIGURE_SIZE[1])
    canvas, axes = _get_canvas_and_axes(figure_size=fig_size, left=axes_left,
                                        right=axes_right, top=axes_top,
                                        bottom=axes_bottom)

    if bar_colors is None:
        bar_colors = create_color_palette(ncols)

    bar_locs = range(0, nrows)
    cum_heights = numpy.zeros(nrows)
    for col_index, (col_name, column) in enumerate(matrix.iteritems()):
        color = bar_colors[col_index] if bar_colors is not None else None
        values = column.values
        args = (bar_locs, values)
        kwargs = {'color': color, 'bottom': cum_heights,
                  'width': bar_width, 'label': col_name}
        if y_error_bars_lower is not None:
            errors_lower = y_error_bars_lower[col_name]
            errors_upper = y_error_bars_upper[col_name]
            kwargs['yerr'] = [errors_lower, errors_upper]
            kwargs['ecolor'] = 'grey'
        axes.bar(*args, **kwargs)
        cum_heights += values

    # axes limits
    min_x = 0
    max_x = bar_width * nrows
    axes.set_xlim(min_x, max_x)
    min_y = 0
    max_y = cum_heights.max()
    axes.set_ylim(min_y, max_y)
    min_y, max_y = axes.get_ylim()

    # the classification lines and texts
    if classification is not None:
        (groups,
         label_locs,
         line_locs) = _calculate_group_tags_and_lines(classification, 1)
        line_locs = line_locs[:-1]  # the last one is nor required
        _draw_vertical_lines(0, max_y, line_locs, axes)
        y_text_loc = (max_y - min_y) / 25 + max_y
        class_texts = _write_texts(groups, xlocs=label_locs,
                                   ylocs=[y_text_loc] * len(groups),
                                   axes=axes)
    else:
        class_texts = []

    # bar labels
    axes.set_xticks([l + bar_width * 0.4 for l in bar_locs])
    labels = axes.set_xticklabels([str(l) + '  ' for l in matrix.index.values],
                                  fontsize=AXIS_LABELS_FONT_SIZE)
    for label in labels:
        label.set_rotation('vertical')

    legend = _add_legend(axes)
    extra_artits = [legend]
    extra_artits.extend(class_texts)
    canvas.print_figure(fhand, format=_get_format_from_fname(fhand.name),
                        bbox_inches='tight', bbox_extra_artists=extra_artits)
    fhand.flush()


def plot_matrix(matrix, fhand, color_bar=True, vertical_labels=False,
                colormap_name=None):

    if colormap_name is not None:
        colormap = get_cmap(colormap_name)
    else:
        colormap = None

    canvas, axes = _get_canvas_and_axes()
    nrows, ncols = matrix.shape
    axes.set_aspect('auto')
    axes.pcolormesh(numpy.array(range(ncols + 1)),
                    numpy.array(range(nrows + 1)),
                    matrix.as_matrix(), cmap=colormap)

    axes.set_xticks([loc + 0.5 for loc in range(ncols)])
    labels = axes.set_xticklabels(list(matrix.columns))

    if vertical_labels:
        for label in labels:
            label.set_rotation('horizontal')

    axes.set_yticks([loc + 0.5 for loc in range(nrows)])
    axes.set_yticklabels(list(matrix.index))

    if color_bar:
        color_axes = matplotlib.colorbar.make_axes(axes)[0]
        matplotlib.colorbar.ColorbarBase(color_axes, cmap=colormap)

    canvas.print_figure(fhand, format=_get_format_from_fname(fhand.name))
